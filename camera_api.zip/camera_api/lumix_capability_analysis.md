# LUMIX 相机能力表解析（lumix_capability.xml）

> 来源：`cam.cgi?mode=getinfo&type=capability` 返回的能力声明，由 DC-S5 相机向 app 通告协议版本、命令列表、功能开关和媒体处理方式。本报告覆盖文件中出现的每一个元素，值全部原样保留。

## 基本信息

| 元素 | 值 | 说明 |
| --- | --- | --- |
| result | `ok` | 请求结果状态 |
| comm_proto_ver | `10.0` | 通信协议版本 |
| productinfo/modelname | `S5` | 相机型号 |
| productinfo/appname | `LUMIX_Sync` | 配套应用名 |

## camcmdlist（相机命令列表）

共 6 个 `camcmd` 值，对应 HTTP 命令 `cam.cgi?mode=camcmd&type=<value>`：

| camcmd 值 | 说明 |
| --- | --- |
| `tele-normal` | 慢速变焦拉近（长焦方向） |
| `tele-fast` | 快速变焦拉近（长焦方向） |
| `wide-normal` | 慢速变焦拉远（广角方向） |
| `wide-fast` | 快速变焦拉远（广角方向） |
| `poweroff` | 关机 |
| `4kphoto_marking` | 4K 照片标记 |

## camspeclist（功能开关标志）

共 17 个 `camspec` 标志，每个门控一个功能：

| camspec 标志 | 门控的功能 |
| --- | --- |
| `touch_command_auto` | 自动触摸命令 |
| `oneshot_af_enable` | 单次自动对焦（One Shot AF） |
| `setting_play_sort_mode_enable` | 播放排序模式设置 |
| `af_size_change_pinch` | 捏合手势改变自动对焦区域大小 |
| `long_expo_disp_B` | 长时间曝光显示（B 门） |
| `geotag_disable` | 地理标记（geotag）禁用 |
| `peaking_flag_use_enable` | 峰值对焦标记使用 |
| `menu_notify_enable` | 菜单通知 |
| `copy_assist_enable` | 复制辅助 |
| `rating_enable` | 照片评分（rating） |
| `slotnum_2` | 双存储卡槽（第 2 卡槽） |
| `mult_del_enable` | 多选删除 |
| `raw_send_enable` | RAW 文件发送 |
| `movie_shot_disable` | 视频拍摄禁用 |
| `touch_af_button_3` | 触摸对焦按钮（3 档/第 3 按钮） |
| `browse_x_filter_rating_enable` | 浏览时按评分过滤 |
| `preview_thumbnail_flag_enable` | 预览缩略图标志 |

## 对焦放大范围（asst_disp 系列）

各对焦放大模式的 `disp_mag` 与 `pinp_mag` 缩放倍率范围（min/max）：

| 元素 | 类型 | min | max |
| --- | --- | --- | --- |
| `asst_disp` | disp_mag | `300` | `2000` |
| `asst_disp` | pinp_mag | `300` | `600` |
| `asst_disp_pinpoint` | disp_mag | `300` | `1000` |
| `asst_disp_pinpoint` | pinp_mag | `300` | `600` |
| `asst_disp_digitalscope` | disp_mag | `300` | `1000` |
| `asst_disp_digitalscope` | pinp_mag | `300` | `600` |
| `crop_disp` | disp_mag | `100` | `400` |

（`crop_disp` 无 `pinp_mag` 子元素。）

## media（存储介质）

| 属性 | 值 |
| --- | --- |
| slot1 | `sd` |
| slot2 | `sd` |

即两个卡槽均为 SD 卡。

## stopmotiontset（延时视频设置）

属性：`model="S5"`、`version="1.0"`、`date="20200117"`。

### videoquality 列表

每个 quality 下的 framerate 列表：

**4K/30p**（value=`mp4_30p_100mbps_4k`）

| name | value |
| --- | --- |
| `30fps` | `30` |
| `15fps` | `15` |
| `10fps` | `10` |
| `7.5fps` | `7.5` |
| `6fps` | `6` |
| `3fps` | `3` |
| `1fps` | `1` |

**4K/24p**（value=`mp4_24p_100mbps_4k`）

| name | value |
| --- | --- |
| `24fps` | `24` |
| `12fps` | `12` |
| `8fps` | `8` |
| `6fps` | `6` |
| `4.8fps` | `4.8` |
| `2.4fps` | `2.4` |
| `1fps` | `1` |

**FHD/60p**（value=`mp4_60p_28mbps`）

| name | value |
| --- | --- |
| `60fps` | `60` |
| `30fps` | `30` |
| `15fps` | `15` |
| `10fps` | `10` |
| `7.5fps` | `7.5` |
| `6fps` | `6` |
| `3fps` | `3` |
| `1fps` | `1` |

**FHD/30p**（value=`mp4_30p_20mbps`）

| name | value |
| --- | --- |
| `30fps` | `30` |
| `15fps` | `15` |
| `10fps` | `10` |
| `7.5fps` | `7.5` |
| `6fps` | `6` |
| `3fps` | `3` |
| `1fps` | `1` |

## contents_action_info（内容类型与允许动作）

属性：`model="S5"`、`version="1.0"`、`date="20200408"`。

容器级动作：

| 元素 | action type | enable |
| --- | --- | --- |
| `container` | `delete` | `no` |

各 `content` 类型（`mime_type` + `panasonic_com_pn`）及允许的动作（`playback` / `copy_to_sp` / `upload` / `3box` / `delete`），`playback` 附 `player`：

| mime_type | panasonic_com_pn | playback | copy_to_sp | upload | 3box | delete | player |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `image/jpeg` | `CAM_ORG` | yes | yes | yes | no | yes | `standard` |
| `application/octet-stream` | `CAM_MPO_JPG` | yes | yes | yes | no | yes | `standard` |
| `application/octet-stream` | `CAM_MPO` | yes | no | no | no | yes | `standard` |
| `application/octet-stream` | `CAM_RAW_JPG` | yes | yes | yes | no | yes | `standard` |
| `application/octet-stream` | `CAM_RAW` | yes | no | no | no | yes | `standard` |
| `application/octet-stream` | `CAM_HSP` | no | no | no | no | yes | `-` |
| `application/octet-stream` | `CAM_HSP_JPG,CAM_HSP_RAW_JPG` | yes | yes | yes | no | yes | `standard` |
| `application/octet-stream` | `CAM_HSP_RAW` | yes | no | no | no | yes | `standard` |
| `application/octet-stream` | `CAM_FOCUS_SELECT_MP4` | no | no | no | no | yes | `-` |
| `application/octet-stream` | `CAM_AVC_MP4_LPCM_ORG,CAM_AVC_MP4_XK_ORG` | yes | no | no | no | yes | `liveview` |
| `application/octet-stream` | `CAM_AVC_MP4_4K_ORG` | yes | yes | no | no | yes | `liveview` |
| `application/octet-stream` | `CAM_AVC_MP4_ORG` | yes | yes | yes | no | yes | `liveview` |
| `application/octet-stream` | `CAM_AVC_TS_HP_ORG` | yes | no | no | no | yes | `liveview` |
| `application/octet-stream` | `CAM_AVC_MOV_ORG` | yes | no | no | no | yes | `liveview` |

补充细节（原样保留）：

- 照片类（JPG/MPO/RAW 等）的 `playback` 动作带 `panasonic_com_pn="CAM_LRGTN"` 且 `player="standard"`。
- `CAM_HSP` 与 `CAM_FOCUS_SELECT_MP4` 的 `playback enable="no"`，`player="-"`（无播放器），其中 `CAM_HSP` 仍带 `panasonic_com_pn="CAM_LRGTN"`，`CAM_FOCUS_SELECT_MP4` 无 `panasonic_com_pn` 属性。
- 视频类（`CAM_AVC_*`）的 `playback` 动作用 `player="liveview" player_func="type1"`，且无 `panasonic_com_pn` 属性。

## autouploaddirinfo（自动上传目录树）

属性：`model="S5"`、`version="1.0"`、`date="20200408"`。

目录结构：

```
autouploaddirlist
└── dir id="dir_id_sd"
        type="media"
        detail="sd"
        title_id="title_sd"
    └── dir id="dir_id_sd_auto_upload"
            type="format"
            detail="all"
            object_id="dir_id_sd_auto_upload"
```

## 小结

这份能力表是 app 的功能门控 + 媒体类型映射的依据：

- `comm_proto_ver` 与 `result` 确定协议兼容与请求成功与否；
- `camcmdlist` 告知 app 可下发的相机控制命令（变焦、关机、4K 照片标记）；
- `camspeclist` 通过 17 个开关决定 app 暴露哪些功能（评分、RAW 发送、双卡槽、删除、地理标记等）；
- `asst_disp` 系列与 `crop_disp` 给出对焦放大/裁剪显示的倍率范围，供 UI 缩放条使用；
- `media` 声明卡槽类型；
- `stopmotiontset` 提供延时视频可选的画质与帧率；
- `contents_action_info` 将每种媒体内容类型（mime_type + panasonic_com_pn）映射到允许的动作（回放/复制/上传/3box/删除）及播放器类型，是浏览与传输功能的依据；
- `autouploaddirinfo` 描述自动上传的目标目录树。

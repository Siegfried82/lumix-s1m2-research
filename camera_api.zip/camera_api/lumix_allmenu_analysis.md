# LUMIX allmenu 菜单树与可设置命令表

> 数据来源：`camera_api/lumix_allmenu.xml`（松下 DC-S5，`cam.cgi?mode=getinfo&type=allmenu` 返回的完整菜单树）。
> 本文由脚本逐条解析生成，所有标识符（`id` / `title_id` / `func_type` / `cmd_type` / `cmd_value` / `cmd_value2`）一律原样保留，标题与说明用中文。

## 一、总览

- 文件：`camera_api/lumix_allmenu.xml`（共 4851 行，美化多行 XML）
- `menuset` 头：`model="S5"` `version="2.0"` `date="20201027"`
- 根结构：`<camrply><result>ok</result><menuset …>`
- `<item>` 总数：740；其中 `cmd_mode="setsetting"`（可设置项）666 个，无 `cmd_mode`（纯显示/容器项）74 个
- 不同 `cmd_type` 数量：47
- `titlelist` 语言：en, ja, de, fr, it, es, zh-TW, zh-CN, nl, ru, ko（`en` 为 default，本文“显示标题”取英文）

### 各菜单区 item 数

| 区 | item 数 | 其中可设置项 | 纯显示/容器项 |
|---|---|---|---|
| `home_menu` | 0 | 0 | 0 |
| `play_menu` | 0 | 0 | 0 |
| `record_top` | 206 | 189 | 17 |
| `record_qmenu` | 125 | 114 | 11 |
| `record_menu` | 398 | 356 | 42 |
| `record_tab` | 6 | 4 | 2 |
| `record_tab2` | 5 | 3 | 2 |

> 注：任务简报中提及“6 个顶层区”，实际 `<menuset>` 下共有 7 个菜单区（`home_menu`、`play_menu` 为空容器）+ 1 个 `titlelist` 标题表；`record_tab2` 也真实存在。

## 二、菜单树结构（按文件顺序）

> 缩进表示嵌套层级；`<group>` 表示选项组，`<menu>` 表示子菜单。
> 行格式：`id — title_id [func_type]`（容器）或 `id — title_id [cmd_type=cmd_value[/cmd_value2]]`（可设置叶子）。
### `home_menu`

（空：无 `<item>`）

### `play_menu`

（空：无 `<item>`）

### `record_top`

- `<menu>`
  - `menu_item_id_f_and_ss` — `title_f_and_ss` `[sp_embeded_f_and_ss]` — “Aperture/Shutter Speed”
  - `menu_item_id_aperture` — `title_aperture` `[sp_embeded_aperture]` — “Aperture”
  - `menu_item_id_shutter_speed` — `title_shutter_speed` `[sp_embeded_shutter_speed]` — “Shutter Speed”
  - `menu_item_id_program_shift` — `title_program_shift` `[sp_embeded_program_shift]` — “Program Shift”
  - `menu_item_id_f` — `title_f` `[sp_embeded_f]` — “F”
  - `menu_item_id_ss` — `title_ss` `[sp_embeded_ss]` — “SS”
  - `menu_item_id_f_and_ss_angle` — `title_f_and_ss_angle` `[sp_embeded_f_and_ss_angle]` — “F/SS(Angle)”
    - `<group>`
      - `menu_item_id_f_and_ss_angle_11` — `title_f_and_ss_angle_11` `[shtrspeed_angle=11]` — “11°”
      - `menu_item_id_f_and_ss_angle_15` — `title_f_and_ss_angle_15` `[shtrspeed_angle=15]` — “15°”
      - `menu_item_id_f_and_ss_angle_23` — `title_f_and_ss_angle_23` `[shtrspeed_angle=23]` — “23°”
      - `menu_item_id_f_and_ss_angle_30` — `title_f_and_ss_angle_30` `[shtrspeed_angle=30]` — “30°”
      - `menu_item_id_f_and_ss_angle_45` — `title_f_and_ss_angle_45` `[shtrspeed_angle=45]` — “45°”
      - `menu_item_id_f_and_ss_angle_60` — `title_f_and_ss_angle_60` `[shtrspeed_angle=60]` — “60°”
      - `menu_item_id_f_and_ss_angle_72` — `title_f_and_ss_angle_72` `[shtrspeed_angle=72]` — “72°”
      - `menu_item_id_f_and_ss_angle_75` — `title_f_and_ss_angle_75` `[shtrspeed_angle=75]` — “75°”
      - `menu_item_id_f_and_ss_angle_86` — `title_f_and_ss_angle_86` `[shtrspeed_angle=86]` — “86°”
      - `menu_item_id_f_and_ss_angle_90` — `title_f_and_ss_angle_90` `[shtrspeed_angle=90]` — “90°”
      - `menu_item_id_f_and_ss_angle_108` — `title_f_and_ss_angle_108` `[shtrspeed_angle=108]` — “108°”
      - `menu_item_id_f_and_ss_angle_120` — `title_f_and_ss_angle_120` `[shtrspeed_angle=120]` — “120°”
      - `menu_item_id_f_and_ss_angle_144` — `title_f_and_ss_angle_144` `[shtrspeed_angle=144]` — “144°”
      - `menu_item_id_f_and_ss_angle_150` — `title_f_and_ss_angle_150` `[shtrspeed_angle=150]` — “150°”
      - `menu_item_id_f_and_ss_angle_172.8` — `title_f_and_ss_angle_172.8` `[shtrspeed_angle=172.8]` — “172.8°”
      - `menu_item_id_f_and_ss_angle_180` — `title_f_and_ss_angle_180` `[shtrspeed_angle=180]` — “180°”
      - `menu_item_id_f_and_ss_angle_216` — `title_f_and_ss_angle_216` `[shtrspeed_angle=216]` — “216°”
      - `menu_item_id_f_and_ss_angle_240` — `title_f_and_ss_angle_240` `[shtrspeed_angle=240]` — “240°”
      - `menu_item_id_f_and_ss_angle_288` — `title_f_and_ss_angle_288` `[shtrspeed_angle=288]` — “288°”
      - `menu_item_id_f_and_ss_angle_300` — `title_f_and_ss_angle_300` `[shtrspeed_angle=300]` — “300°”
      - `menu_item_id_f_and_ss_angle_346` — `title_f_and_ss_angle_346` `[shtrspeed_angle=346]` — “346°”
      - `menu_item_id_f_and_ss_angle_358` — `title_f_and_ss_angle_358` `[shtrspeed_angle=358]` — “358°”
  - `menu_item_id_ss_angle` — `title_ss_angle` `[sp_embeded_ss_angle]` — “SS(Angle)”
    - `<group>`
      - `menu_item_id_ss_angle_11` — `title_ss_angle_11` `[shtrspeed_angle=11]` — “11°”
      - `menu_item_id_ss_angle_15` — `title_ss_angle_15` `[shtrspeed_angle=15]` — “15°”
      - `menu_item_id_ss_angle_23` — `title_ss_angle_23` `[shtrspeed_angle=23]` — “23°”
      - `menu_item_id_ss_angle_30` — `title_ss_angle_30` `[shtrspeed_angle=30]` — “30°”
      - `menu_item_id_ss_angle_45` — `title_ss_angle_45` `[shtrspeed_angle=45]` — “45°”
      - `menu_item_id_ss_angle_60` — `title_ss_angle_60` `[shtrspeed_angle=60]` — “60°”
      - `menu_item_id_ss_angle_72` — `title_ss_angle_72` `[shtrspeed_angle=72]` — “72°”
      - `menu_item_id_ss_angle_75` — `title_ss_angle_75` `[shtrspeed_angle=75]` — “75°”
      - `menu_item_id_ss_angle_86` — `title_ss_angle_86` `[shtrspeed_angle=86]` — “86°”
      - `menu_item_id_ss_angle_90` — `title_ss_angle_90` `[shtrspeed_angle=90]` — “90°”
      - `menu_item_id_ss_angle_108` — `title_ss_angle_108` `[shtrspeed_angle=108]` — “108°”
      - `menu_item_id_ss_angle_120` — `title_ss_angle_120` `[shtrspeed_angle=120]` — “120°”
      - `menu_item_id_ss_angle_144` — `title_ss_angle_144` `[shtrspeed_angle=144]` — “144°”
      - `menu_item_id_ss_angle_150` — `title_ss_angle_150` `[shtrspeed_angle=150]` — “150°”
      - `menu_item_id_ss_angle_172.8` — `title_ss_angle_172.8` `[shtrspeed_angle=172.8]` — “172.8°”
      - `menu_item_id_ss_angle_180` — `title_ss_angle_180` `[shtrspeed_angle=180]` — “180°”
      - `menu_item_id_ss_angle_216` — `title_ss_angle_216` `[shtrspeed_angle=216]` — “216°”
      - `menu_item_id_ss_angle_240` — `title_ss_angle_240` `[shtrspeed_angle=240]` — “240°”
      - `menu_item_id_ss_angle_288` — `title_ss_angle_288` `[shtrspeed_angle=288]` — “288°”
      - `menu_item_id_ss_angle_300` — `title_ss_angle_300` `[shtrspeed_angle=300]` — “300°”
      - `menu_item_id_ss_angle_346` — `title_ss_angle_346` `[shtrspeed_angle=346]` — “346°”
      - `menu_item_id_ss_angle_358` — `title_ss_angle_358` `[shtrspeed_angle=358]` — “358°”
  - `menu_item_id_f_and_ss_sync` — `title_f_and_ss_sync` `[sp_embeded_f_and_ss_sync]` — “F/SS(sync)”
  - `menu_item_id_ss_sync` — `title_ss_sync` `[sp_embeded_ss_sync]` — “SS(sync)”
  - `menu_item_id_f_and_ss_angle_sync` — `title_f_and_ss_angle_sync` `[sp_embeded_f_and_ss_angle_sync]` — “F/SS(AngleSync)”
  - `menu_item_id_ss_angle_sync` — `title_ss_angle_sync` `[sp_embeded_ss_angle_sync]` — “SS(AngleSync)”
  - `menu_item_id_exposure3` — `title_exposure3` `[sp_embeded_exposure3]` — “Exposure Comp.”
    - `<group>`
      - `menu_item_id_exposure_m5` — `title_exposure_m5` `[exposure=-5]` — “-5”
      - `menu_item_id_exposure_m14_3` — `title_exposure_m14_3` `[exposure=-14/3]` — “-4 2/3”
      - `menu_item_id_exposure_m13_3` — `title_exposure_m13_3` `[exposure=-13/3]` — “-4 1/3”
      - `menu_item_id_exposure_m4` — `title_exposure_m4` `[exposure=-4]` — “-4”
      - `menu_item_id_exposure_m11_3` — `title_exposure_m11_3` `[exposure=-11/3]` — “-3 2/3”
      - `menu_item_id_exposure_m10_3` — `title_exposure_m10_3` `[exposure=-10/3]` — “-3 1/3”
      - `menu_item_id_exposure_m3` — `title_exposure_m3` `[exposure=-3]` — “-3”
      - `menu_item_id_exposure_m8_3` — `title_exposure_m8_3` `[exposure=-8/3]` — “-2 2/3”
      - `menu_item_id_exposure_m7_3` — `title_exposure_m7_3` `[exposure=-7/3]` — “-2 1/3”
      - `menu_item_id_exposure_m2` — `title_exposure_m2` `[exposure=-2]` — “-2”
      - `menu_item_id_exposure_m5_3` — `title_exposure_m5_3` `[exposure=-5/3]` — “-1 2/3”
      - `menu_item_id_exposure_m4_3` — `title_exposure_m4_3` `[exposure=-4/3]` — “-1 1/3”
      - `menu_item_id_exposure_m1` — `title_exposure_m1` `[exposure=-1]` — “-1”
      - `menu_item_id_exposure_m2_3` — `title_exposure_m2_3` `[exposure=-2/3]` — “-2/3”
      - `menu_item_id_exposure_m1_3` — `title_exposure_m1_3` `[exposure=-1/3]` — “-1/3”
      - `menu_item_id_exposure_0` — `title_exposure_0` `[exposure=0]` — “0”
      - `menu_item_id_exposure_p1_3` — `title_exposure_p1_3` `[exposure=1/3]` — “+1/3”
      - `menu_item_id_exposure_p2_3` — `title_exposure_p2_3` `[exposure=2/3]` — “+2/3”
      - `menu_item_id_exposure_p1` — `title_exposure_p1` `[exposure=1]` — “+1”
      - `menu_item_id_exposure_p4_3` — `title_exposure_p4_3` `[exposure=4/3]` — “+1 1/3”
      - `menu_item_id_exposure_p5_3` — `title_exposure_p5_3` `[exposure=5/3]` — “+1 2/3”
      - `menu_item_id_exposure_p2` — `title_exposure_p2` `[exposure=2]` — “+2”
      - `menu_item_id_exposure_p7_3` — `title_exposure_p7_3` `[exposure=7/3]` — “+2 1/3”
      - `menu_item_id_exposure_p8_3` — `title_exposure_p8_3` `[exposure=8/3]` — “+2 2/3”
      - `menu_item_id_exposure_p3` — `title_exposure_p3` `[exposure=3]` — “+3”
      - `menu_item_id_exposure_p10_3` — `title_exposure_p10_3` `[exposure=10/3]` — “+3 1/3”
      - `menu_item_id_exposure_p11_3` — `title_exposure_p11_3` `[exposure=11/3]` — “+3 2/3”
      - `menu_item_id_exposure_p12_3` — `title_exposure_p12_3` `[exposure=4]` — “+4”
      - `menu_item_id_exposure_p13_3` — `title_exposure_p13_3` `[exposure=13/3]` — “+4 1/3”
      - `menu_item_id_exposure_p14_3` — `title_exposure_p14_3` `[exposure=14/3]` — “+4 2/3”
      - `menu_item_id_exposure_p15_3` — `title_exposure_p15_3` `[exposure=5]` — “+5”
  - `menu_item_id_exposure3_step` — `title_exposure3_step` `[sp_embeded_exposure3_step]` — “Step”
    - `<group>`
      - `menu_item_id_exposure3_step_off` — `title_exposure3_step_off` `[bracket=off]` — “Off”
      - `menu_item_id_exposure3_step_3shot_1/3ev` — `title_exposure3_step_3shot_1/3ev` `[bracket_exposure_step=3shot_1/3ev]` — “3・1/3”
      - `menu_item_id_exposure3_step_3shot_2/3ev` — `title_exposure3_step_3shot_2/3ev` `[bracket_exposure_step=3shot_2/3ev]` — “3・2/3”
      - `menu_item_id_exposure3_step_3shot_1ev` — `title_exposure3_step_3shot_1ev` `[bracket_exposure_step=3shot_1ev]` — “3・1”
      - `menu_item_id_exposure3_step_5shot_1/3ev` — `title_exposure3_step_5shot_1/3ev` `[bracket_exposure_step=5shot_1/3ev]` — “5・1/3”
      - `menu_item_id_exposure3_step_5shot_2/3ev` — `title_exposure3_step_5shot_2/3ev` `[bracket_exposure_step=5shot_2/3ev]` — “5・2/3”
      - `menu_item_id_exposure3_step_5shot_1ev` — `title_exposure3_step_5shot_1ev` `[bracket_exposure_step=5shot_1ev]` — “5・1”
      - `menu_item_id_exposure3_step_7shot_1/3ev` — `title_exposure3_step_7shot_1/3ev` `[bracket_exposure_step=7shot_1/3ev]` — “7・1/3”
      - `menu_item_id_exposure3_step_7shot_2/3ev` — `title_exposure3_step_7shot_2/3ev` `[bracket_exposure_step=7shot_2/3ev]` — “7・2/3”
      - `menu_item_id_exposure3_step_7shot_1ev` — `title_exposure3_step_7shot_1ev` `[bracket_exposure_step=7shot_1ev]` — “7・1”
  - `menu_item_id_sensitivity` — `title_sensitivity` `[sp_embeded_sensitivity]` — “Sensitivity”
    - `<group>`
      - `menu_item_id_sensitivity_auto` — `title_sensitivity_auto` `[iso=auto]` — “AUTO”
      - `menu_item_id_sensitivity_L50` — `title_sensitivity_L50` `[iso=50]` — “L.50”
      - `menu_item_id_sensitivity_L64` — `title_sensitivity_L64` `[iso=64]` — “L.64”
      - `menu_item_id_sensitivity_L80` — `title_sensitivity_L80` `[iso=80]` — “L.80”
      - `menu_item_id_sensitivity_100` — `title_sensitivity_100` `[iso=100]` — “100”
      - `menu_item_id_sensitivity_L100` — `title_sensitivity_L100` `[iso=100]` — “L.100”
      - `menu_item_id_sensitivity_125` — `title_sensitivity_125` `[iso=125]` — “125”
      - `menu_item_id_sensitivity_L125` — `title_sensitivity_L125` `[iso=125]` — “L.125”
      - `menu_item_id_sensitivity_160` — `title_sensitivity_160` `[iso=160]` — “160”
      - `menu_item_id_sensitivity_L160` — `title_sensitivity_L160` `[iso=160]` — “L.160”
      - `menu_item_id_sensitivity_200` — `title_sensitivity_200` `[iso=200]` — “200”
      - `menu_item_id_sensitivity_250` — `title_sensitivity_250` `[iso=250]` — “250”
      - `menu_item_id_sensitivity_320` — `title_sensitivity_320` `[iso=320]` — “320”
      - `menu_item_id_sensitivity_L320` — `title_sensitivity_L320` `[iso=320]` — “L.320”
      - `menu_item_id_sensitivity_400` — `title_sensitivity_400` `[iso=400]` — “400”
      - `menu_item_id_sensitivity_L400` — `title_sensitivity_L400` `[iso=400]` — “L.400”
      - `menu_item_id_sensitivity_500` — `title_sensitivity_500` `[iso=500]` — “500”
      - `menu_item_id_sensitivity_L500` — `title_sensitivity_L500` `[iso=500]` — “L.500”
      - `menu_item_id_sensitivity_640` — `title_sensitivity_640` `[iso=640]` — “640”
      - `menu_item_id_sensitivity_800` — `title_sensitivity_800` `[iso=800]` — “800”
      - `menu_item_id_sensitivity_1000` — `title_sensitivity_1000` `[iso=1000]` — “1000”
      - `menu_item_id_sensitivity_1250` — `title_sensitivity_1250` `[iso=1250]` — “1250”
      - `menu_item_id_sensitivity_1600` — `title_sensitivity_1600` `[iso=1600]` — “1600”
      - `menu_item_id_sensitivity_2000` — `title_sensitivity_2000` `[iso=2000]` — “2000”
      - `menu_item_id_sensitivity_2500` — `title_sensitivity_2500` `[iso=2500]` — “2500”
      - `menu_item_id_sensitivity_3200` — `title_sensitivity_3200` `[iso=3200]` — “3200”
      - `menu_item_id_sensitivity_4000` — `title_sensitivity_4000` `[iso=4000]` — “4000”
      - `menu_item_id_sensitivity_5000` — `title_sensitivity_5000` `[iso=5000]` — “5000”
      - `menu_item_id_sensitivity_6400` — `title_sensitivity_6400` `[iso=6400]` — “6400”
      - `menu_item_id_sensitivity_8000` — `title_sensitivity_8000` `[iso=8000]` — “8000”
      - `menu_item_id_sensitivity_10000` — `title_sensitivity_10000` `[iso=10000]` — “10000”
      - `menu_item_id_sensitivity_12800` — `title_sensitivity_12800` `[iso=12800]` — “12800”
      - `menu_item_id_sensitivity_16000` — `title_sensitivity_16000` `[iso=16000]` — “16000”
      - `menu_item_id_sensitivity_20000` — `title_sensitivity_20000` `[iso=20000]` — “20000”
      - `menu_item_id_sensitivity_25600` — `title_sensitivity_25600` `[iso=25600]` — “25600”
      - `menu_item_id_sensitivity_32000` — `title_sensitivity_32000` `[iso=32000]` — “32000”
      - `menu_item_id_sensitivity_40000` — `title_sensitivity_40000` `[iso=40000]` — “40000”
      - `menu_item_id_sensitivity_51200` — `title_sensitivity_51200` `[iso=51200]` — “51200”
      - `menu_item_id_sensitivity_H64000` — `title_sensitivity_H64000` `[iso=64000]` — “H.64000”
      - `menu_item_id_sensitivity_H80000` — `title_sensitivity_H80000` `[iso=80000]` — “H.80000”
      - `menu_item_id_sensitivity_H102400` — `title_sensitivity_H102400` `[iso=102400]` — “H.102400”
      - `menu_item_id_sensitivity_H128000` — `title_sensitivity_H128000` `[iso=128000]` — “H.128000”
      - `menu_item_id_sensitivity_H160000` — `title_sensitivity_H160000` `[iso=160000]` — “H.160000”
      - `menu_item_id_sensitivity_H204800` — `title_sensitivity_H204800` `[iso=204800]` — “H.204800”
  - `menu_item_id_sensitivity_db` — `title_sensitivity_db` `[sp_embeded_sensitivity_db]` — “dB”
    - `<group>`
      - `menu_item_id_sensitivity_db_auto` — `title_sensitivity_db_auto` `[sensitivity_db=auto]` — “AUTO”
      - `menu_item_id_sensitivity_db_Lm6` — `title_sensitivity_db_Lm6` `[sensitivity_db=-6]` — “L.-6dB”
      - `menu_item_id_sensitivity_db_Lm4` — `title_sensitivity_db_Lm4` `[sensitivity_db=-4]` — “L.-4dB”
      - `menu_item_id_sensitivity_db_Lm2` — `title_sensitivity_db_Lm2` `[sensitivity_db=-2]` — “L.-2dB”
      - `menu_item_id_sensitivity_db_0` — `title_sensitivity_db_0` `[sensitivity_db=0]` — “0dB”
      - `menu_item_id_sensitivity_db_2` — `title_sensitivity_db_2` `[sensitivity_db=2]` — “2dB”
      - `menu_item_id_sensitivity_db_4` — `title_sensitivity_db_4` `[sensitivity_db=4]` — “4dB”
      - `menu_item_id_sensitivity_db_6` — `title_sensitivity_db_6` `[sensitivity_db=6]` — “6dB”
      - `menu_item_id_sensitivity_db_8` — `title_sensitivity_db_8` `[sensitivity_db=8]` — “8dB”
      - `menu_item_id_sensitivity_db_10` — `title_sensitivity_db_10` `[sensitivity_db=10]` — “10dB”
      - `menu_item_id_sensitivity_db_12` — `title_sensitivity_db_12` `[sensitivity_db=12]` — “12dB”
      - `menu_item_id_sensitivity_db_14` — `title_sensitivity_db_14` `[sensitivity_db=14]` — “14dB”
      - `menu_item_id_sensitivity_db_16` — `title_sensitivity_db_16` `[sensitivity_db=16]` — “16dB”
      - `menu_item_id_sensitivity_db_18` — `title_sensitivity_db_18` `[sensitivity_db=18]` — “18dB”
      - `menu_item_id_sensitivity_db_20` — `title_sensitivity_db_20` `[sensitivity_db=20]` — “20dB”
      - `menu_item_id_sensitivity_db_22` — `title_sensitivity_db_22` `[sensitivity_db=22]` — “22dB”
      - `menu_item_id_sensitivity_db_24` — `title_sensitivity_db_24` `[sensitivity_db=24]` — “24dB”
      - `menu_item_id_sensitivity_db_26` — `title_sensitivity_db_26` `[sensitivity_db=26]` — “26dB”
      - `menu_item_id_sensitivity_db_28` — `title_sensitivity_db_28` `[sensitivity_db=28]` — “28dB”
      - `menu_item_id_sensitivity_db_30` — `title_sensitivity_db_30` `[sensitivity_db=30]` — “30dB”
      - `menu_item_id_sensitivity_db_32` — `title_sensitivity_db_32` `[sensitivity_db=32]` — “32dB”
      - `menu_item_id_sensitivity_db_34` — `title_sensitivity_db_34` `[sensitivity_db=34]` — “34dB”
      - `menu_item_id_sensitivity_db_36` — `title_sensitivity_db_36` `[sensitivity_db=36]` — “36dB”
      - `menu_item_id_sensitivity_db_38` — `title_sensitivity_db_38` `[sensitivity_db=38]` — “38dB”
      - `menu_item_id_sensitivity_db_40` — `title_sensitivity_db_40` `[sensitivity_db=40]` — “40dB”
      - `menu_item_id_sensitivity_db_42` — `title_sensitivity_db_42` `[sensitivity_db=42]` — “42dB”
      - `menu_item_id_sensitivity_db_44` — `title_sensitivity_db_44` `[sensitivity_db=44]` — “44dB”
      - `menu_item_id_sensitivity_db_H44` — `title_sensitivity_db_H44` `[sensitivity_db=44]` — “H.44dB”
      - `menu_item_id_sensitivity_db_46` — `title_sensitivity_db_46` `[sensitivity_db=46]` — “46dB”
      - `menu_item_id_sensitivity_db_H46` — `title_sensitivity_db_H46` `[sensitivity_db=46]` — “H.46dB”
      - `menu_item_id_sensitivity_db_48` — `title_sensitivity_db_48` `[sensitivity_db=48]` — “48dB”
      - `menu_item_id_sensitivity_db_H48` — `title_sensitivity_db_H48` `[sensitivity_db=48]` — “H.48dB”
      - `menu_item_id_sensitivity_db_50` — `title_sensitivity_db_50` `[sensitivity_db=50]` — “50dB”
      - `menu_item_id_sensitivity_db_H50` — `title_sensitivity_db_H50` `[sensitivity_db=50]` — “H.50dB”
      - `menu_item_id_sensitivity_db_52` — `title_sensitivity_db_52` `[sensitivity_db=52]` — “52dB”
      - `menu_item_id_sensitivity_db_H52` — `title_sensitivity_db_H52` `[sensitivity_db=52]` — “H.52dB”
      - `menu_item_id_sensitivity_db_54` — `title_sensitivity_db_54` `[sensitivity_db=54]` — “54dB”
      - `menu_item_id_sensitivity_db_H54` — `title_sensitivity_db_H54` `[sensitivity_db=54]` — “H.54dB”
      - `menu_item_id_sensitivity_db_H56` — `title_sensitivity_db_H56` `[sensitivity_db=56]` — “H.56dB”
      - `menu_item_id_sensitivity_db_H58` — `title_sensitivity_db_H58` `[sensitivity_db=58]` — “H.58dB”
      - `menu_item_id_sensitivity_db_H60` — `title_sensitivity_db_H60` `[sensitivity_db=60]` — “H.60dB”
      - `menu_item_id_sensitivity_db_H62` — `title_sensitivity_db_H62` `[sensitivity_db=62]` — “H.62dB”
      - `menu_item_id_sensitivity_db_H64` — `title_sensitivity_db_H64` `[sensitivity_db=64]` — “H.64dB”
      - `menu_item_id_sensitivity_db_H66` — `title_sensitivity_db_H66` `[sensitivity_db=66]` — “H.66dB”
  - `menu_item_id_whitebalance` — `title_whitebalance` `[sp_embeded_whitebalance]` — “White Balance”
    - `<group>`
      - `menu_item_id_whitebalance_auto` — `title_whitebalance_auto` `[whitebalance=auto]` — “Auto White Balance”
      - `menu_item_id_whitebalance_auto_cool` — `title_whitebalance_auto_cool` `[whitebalance=auto_cool]` — “AWB(Cool)”
      - `menu_item_id_whitebalance_auto_warm` — `title_whitebalance_auto_warm` `[whitebalance=auto_warm]` — “AWB(Warm)”
      - `menu_item_id_whitebalance_daylight` — `title_whitebalance_daylight` `[whitebalance=daylight]` — “Daylight”
      - `menu_item_id_whitebalance_cloudy` — `title_whitebalance_cloudy` `[whitebalance=cloudy]` — “Cloudy”
      - `menu_item_id_whitebalance_shade` — `title_whitebalance_shade` `[whitebalance=shade]` — “Shade”
      - `menu_item_id_whitebalance_halogen` — `title_whitebalance_halogen` `[whitebalance=halogen]` — “Incandescent”
      - `menu_item_id_whitebalance_flash` — `title_whitebalance_flash` `[whitebalance=flash]` — “Flash”
      - `menu_item_id_whitebalance_white_set1` — `title_whitebalance_white_set1` `[whitebalance=white_set1]` — “White Set 1”
      - `menu_item_id_whitebalance_white_set2` — `title_whitebalance_white_set2` `[whitebalance=white_set2]` — “White Set 2”
      - `menu_item_id_whitebalance_white_set3` — `title_whitebalance_white_set3` `[whitebalance=white_set3]` — “White Set 3”
      - `menu_item_id_whitebalance_white_set4` — `title_whitebalance_white_set4` `[whitebalance=white_set4]` — “White Set 4”
      - `menu_item_id_whitebalance_color_temp1` — `title_whitebalance_color_temp1` `[whitebalance=color_temp1/__value__]` — “Color Temperature 1”
      - `menu_item_id_whitebalance_color_temp2` — `title_whitebalance_color_temp2` `[whitebalance=color_temp2/__value__]` — “Color Temperature 2”
      - `menu_item_id_whitebalance_color_temp3` — `title_whitebalance_color_temp3` `[whitebalance=color_temp3/__value__]` — “Color Temperature 3”
      - `menu_item_id_whitebalance_color_temp4` — `title_whitebalance_color_temp4` `[whitebalance=color_temp4/__value__]` — “Color Temperature 4”

### `record_qmenu`

- `<menu>`
  - `menu_item_id_ph_sty` — `title_ph_sty` `[select]` — “Photo Style”
    - `<group>`
      - `menu_item_id_ph_sty_standard` — `title_ph_sty_standard` `[photostyle=standard/__value__]` — “Standard”
      - `menu_item_id_ph_sty_vivid` — `title_ph_sty_vivid` `[photostyle=vivid/__value__]` — “Vivid”
      - `menu_item_id_ph_sty_natural` — `title_ph_sty_natural` `[photostyle=natural/__value__]` — “Natural”
      - `menu_item_id_ph_sty_l_cla_neo` — `title_ph_sty_l_cla_neo` `[photostyle=l_cla_neo/__value__]` — “L.ClassicNeo”
      - `menu_item_id_ph_sty_flat` — `title_ph_sty_flat` `[photostyle=flat/__value__]` — “Flat”
      - `menu_item_id_ph_sty_scenery` — `title_ph_sty_scenery` `[photostyle=scenery/__value__]` — “Landscape”
      - `menu_item_id_ph_sty_portrait` — `title_ph_sty_portrait` `[photostyle=portrait/__value__]` — “Portrait”
      - `menu_item_id_ph_sty_bw` — `title_ph_sty_bw` `[photostyle=bw/__value__]` — “Monochrome”
      - `menu_item_id_ph_sty_l_bw` — `title_ph_sty_l_bw` `[photostyle=l_bw/__value__]` — “L.Monochrome”
      - `menu_item_id_ph_sty_l_bw_d` — `title_ph_sty_l_bw_d` `[photostyle=l_bw_d/__value__]` — “L.Monochrome D”
      - `menu_item_id_ph_sty_l_bw_s` — `title_ph_sty_l_bw_s` `[photostyle=l_bw_s/__value__]` — “L.Monochrome S”
      - `menu_item_id_ph_sty_cinelike_d2` — `title_ph_sty_cinelike_d2` `[photostyle=cinelike_d2/__value__]` — “Cinelike D2”
      - `menu_item_id_ph_sty_cinelike_v2` — `title_ph_sty_cinelike_v2` `[photostyle=cinelike_v2/__value__]` — “Cinelike V2”
      - `menu_item_id_ph_sty_709like` — `title_ph_sty_709like` `[photostyle=709like/__value__]` — “Like709”
      - `menu_item_id_ph_sty_vlog` — `title_ph_sty_vlog` `[photostyle=vlog/__value__]` — “V-Log”
      - `menu_item_id_ph_sty_hlg_standard` — `title_ph_sty_hlg_standard` `[photostyle=hlg_standard/__value__]` — “Standard(HLG)”
      - `menu_item_id_ph_sty_hlg_bw` — `title_ph_sty_hlg_bw` `[photostyle=hlg_bw/__value__]` — “Monochrome(HLG)”
      - `menu_item_id_ph_sty_hlg` — `title_ph_sty_hlg` `[photostyle=hlg/__value__]` — “Like2100(HLG)”
      - `menu_item_id_ph_sty_custom1` — `title_ph_sty_custom1` `[photostyle=custom1/__value__]` — “MY PHOTO STYLE 1”
      - `menu_item_id_ph_sty_custom2` — `title_ph_sty_custom2` `[photostyle=custom2/__value__]` — “MY PHOTO STYLE 2”
      - `menu_item_id_ph_sty_custom3` — `title_ph_sty_custom3` `[photostyle=custom3/__value__]` — “MY PHOTO STYLE 3”
      - `menu_item_id_ph_sty_custom4` — `title_ph_sty_custom4` `[photostyle=custom4/__value__]` — “MY PHOTO STYLE 4”
      - `menu_item_id_ph_sty_custom5` — `title_ph_sty_custom5` `[photostyle=custom5/__value__]` — “MY PHOTO STYLE 5”
      - `menu_item_id_ph_sty_custom6` — `title_ph_sty_custom6` `[photostyle=custom6/__value__]` — “MY PHOTO STYLE 6”
      - `menu_item_id_ph_sty_custom7` — `title_ph_sty_custom7` `[photostyle=custom7/__value__]` — “MY PHOTO STYLE 7”
      - `menu_item_id_ph_sty_custom8` — `title_ph_sty_custom8` `[photostyle=custom8/__value__]` — “MY PHOTO STYLE 8”
      - `menu_item_id_ph_sty_custom9` — `title_ph_sty_custom9` `[photostyle=custom9/__value__]` — “MY PHOTO STYLE 9”
      - `menu_item_id_ph_sty_custom10` — `title_ph_sty_custom10` `[photostyle=custom10/__value__]` — “MY PHOTO STYLE 10”
  - `menu_item_id_ph_sty_saturation` — `title_ph_sty_saturation` `[sp_embeded_ph_sty_saturation]` — “Saturation”
    - `<group>`
  - `menu_item_id_whitebalance` — `title_whitebalance` `[select]` — “White Balance”
    - `<group>`
      - `menu_item_id_whitebalance_auto` — `title_whitebalance_auto` `[whitebalance=auto]` — “Auto White Balance”
      - `menu_item_id_whitebalance_auto_cool` — `title_whitebalance_auto_cool` `[whitebalance=auto_cool]` — “AWB(Cool)”
      - `menu_item_id_whitebalance_auto_warm` — `title_whitebalance_auto_warm` `[whitebalance=auto_warm]` — “AWB(Warm)”
      - `menu_item_id_whitebalance_daylight` — `title_whitebalance_daylight` `[whitebalance=daylight]` — “Daylight”
      - `menu_item_id_whitebalance_cloudy` — `title_whitebalance_cloudy` `[whitebalance=cloudy]` — “Cloudy”
      - `menu_item_id_whitebalance_shade` — `title_whitebalance_shade` `[whitebalance=shade]` — “Shade”
      - `menu_item_id_whitebalance_halogen` — `title_whitebalance_halogen` `[whitebalance=halogen]` — “Incandescent”
      - `menu_item_id_whitebalance_flash` — `title_whitebalance_flash` `[whitebalance=flash]` — “Flash”
      - `menu_item_id_whitebalance_white_set1` — `title_whitebalance_white_set1` `[whitebalance=white_set1]` — “White Set 1”
      - `menu_item_id_whitebalance_white_set2` — `title_whitebalance_white_set2` `[whitebalance=white_set2]` — “White Set 2”
      - `menu_item_id_whitebalance_white_set3` — `title_whitebalance_white_set3` `[whitebalance=white_set3]` — “White Set 3”
      - `menu_item_id_whitebalance_white_set4` — `title_whitebalance_white_set4` `[whitebalance=white_set4]` — “White Set 4”
      - `menu_item_id_whitebalance_color_temp1` — `title_whitebalance_color_temp1` `[whitebalance=color_temp1/__value__]` — “Color Temperature 1”
      - `menu_item_id_whitebalance_color_temp2` — `title_whitebalance_color_temp2` `[whitebalance=color_temp2/__value__]` — “Color Temperature 2”
      - `menu_item_id_whitebalance_color_temp3` — `title_whitebalance_color_temp3` `[whitebalance=color_temp3/__value__]` — “Color Temperature 3”
      - `menu_item_id_whitebalance_color_temp4` — `title_whitebalance_color_temp4` `[whitebalance=color_temp4/__value__]` — “Color Temperature 4”
  - `menu_item_id_ph_sty_contrast` — `title_ph_sty_contrast` `[sp_embeded_ph_sty_contrast]` — “Contrast”
    - `<group>`
  - `menu_item_id_ph_sty_highlight` — `title_ph_sty_highlight` `[sp_embeded_ph_sty_highlight]` — “Highlight”
    - `<group>`
  - `menu_item_id_ph_sty_shadow` — `title_ph_sty_shadow` `[sp_embeded_ph_sty_shadow]` — “Shadow”
    - `<group>`
  - `menu_item_id_ph_sty_sharpness` — `title_ph_sty_sharpness` `[sp_embeded_ph_sty_sharpness]` — “Sharpness”
    - `<group>`
  - `menu_item_id_ph_sty_noise_reduction` — `title_ph_sty_noise_reduction` `[sp_embeded_ph_sty_noise_reduction]` — “Noise Reduction”
    - `<group>`
  - `menu_item_id_1shoot` — `title_1shoot` `[drivemode=normal]` — “Single”
  - `menu_item_id_burst_1` — `title_burst_speed_1` `[select]` — “Burst Shot 1 Setting”
    - `<group>`
      - `menu_item_id_burst_1_6k4k_photo` — `title_burst_6k4k_photo` `[drivemode=burst_1/6k4k_photo]` — “6K/4K PHOTO”
      - `menu_item_id_burst_1_h` — `title_burst_h` `[drivemode=burst_1/h]` — “H”
      - `menu_item_id_burst_1_m` — `title_burst_m` `[drivemode=burst_1/m]` — “M”
      - `menu_item_id_burst_1_l` — `title_burst_l` `[drivemode=burst_1/l]` — “L”
  - `menu_item_id_burst_2` — `title_burst_speed_2` `[select]` — “Burst Shot 2 Setting”
    - `<group>`
      - `menu_item_id_burst_2_6k4k_photo` — `title_burst_6k4k_photo` `[drivemode=burst_2/6k4k_photo]` — “6K/4K PHOTO”
      - `menu_item_id_burst_2_h` — `title_burst_h` `[drivemode=burst_2/h]` — “H”
      - `menu_item_id_burst_2_m` — `title_burst_m` `[drivemode=burst_2/m]` — “M”
      - `menu_item_id_burst_2_l` — `title_burst_l` `[drivemode=burst_2/l]` — “L”
  - `menu_item_id_stopmotion_interval` — `title_stopmotion_interval` `[drivemode=stopmotion_interval]` — “Time Lapse/Animation”
  - `menu_item_id_selftimer` — `title_selftimer` `[select]` — “Self Timer”
    - `<group>`
      - `menu_item_id_selftimer_10sec` — `title_selftimer_10sec` `[drivemode=selftimer/10sec]` — “10sec.”
      - `menu_item_id_selftimer_10sec3shot` — `title_selftimer_10sec3shot` `[drivemode=selftimer/10sec3shot]` — “10s / 3pictures”
      - `menu_item_id_selftimer_2sec` — `title_selftimer_2sec` `[drivemode=selftimer/2sec]` — “2sec.”
  - `menu_item_id_asprat` — `title_asprat` `[select]` — “Aspect Ratio”
    - `<group>`
      - `menu_item_id_asprat_4:3` — `title_asprat_4:3` `[aspectratio=4:3]` — “4:3”
      - `menu_item_id_asprat_3:2` — `title_asprat_3:2` `[aspectratio=3:2]` — “3:2”
      - `menu_item_id_asprat_16:9` — `title_asprat_16:9` `[aspectratio=16:9]` — “16:9”
      - `menu_item_id_asprat_1:1` — `title_asprat_1:1` `[aspectratio=1:1]` — “1:1”
      - `menu_item_id_asprat_65:24` — `title_asprat_65:24` `[aspectratio=65:24]` — “65:24”
      - `menu_item_id_asprat_2:1` — `title_asprat_2:1` `[aspectratio=2:1]` — “2:1”
  - `menu_item_id_lightmet` — `title_lightmet` `[select]` — “Metering Mode”
    - `<group>`
      - `menu_item_id_lightmet_multi` — `title_lightmet_multi` `[lightmetering=multi]` — “Multi Metering”
      - `menu_item_id_lightmet_center` — `title_lightmet_center` `[lightmetering=center]` — “Center Weighted”
      - `menu_item_id_lightmet_spot` — `title_lightmet_spot` `[lightmetering=spot]` — “Spot”
      - `menu_item_id_lightmet_highlight` — `title_lightmet_highlight` `[lightmetering=highlight]` — “Highlight Weighted”
  - `menu_item_id_v_quality` — `title_v_quality_qmenu` `[select]` — “Motion Pic. Rec Quality”
    - `<group>`
      - `menu_item_id_v_quality_mp4_60p_100mbps_4k_10bit` — `title_v_quality_mp4_60p_100mbps_4k_10bit_q` `[videoquality=mp4_60p_100mbps_4k_10bit]` — “3840x2160,60p”
      - `menu_item_id_v_quality_mp4_50p_100mbps_4k_10bit` — `title_v_quality_mp4_50p_100mbps_4k_10bit_q` `[videoquality=mp4_50p_100mbps_4k_10bit]` — “3840x2160,50p”
      - `menu_item_id_v_quality_mp4_30p_100mbps_4k` — `title_v_quality_mp4_30p_100mbps_4k_q` `[videoquality=mp4_30p_100mbps_4k]` — “3840x2160,30p”
      - `menu_item_id_v_quality_mp4_25p_100mbps_4k` — `title_v_quality_mp4_25p_100mbps_4k_q` `[videoquality=mp4_25p_100mbps_4k]` — “3840x2160,25p”
      - `menu_item_id_v_quality_mp4_30p_72mbps_4k_10bit` — `title_v_quality_mp4_30p_72mbps_4k_10bit_q` `[videoquality=mp4_30p_72mbps_4k_10bit]` — “3840x2160,30p”
      - `menu_item_id_v_quality_mp4_25p_72mbps_4k_10bit` — `title_v_quality_mp4_25p_72mbps_4k_10bit_q` `[videoquality=mp4_25p_72mbps_4k_10bit]` — “3840x2160,25p”
      - `menu_item_id_v_quality_mp4_24p_100mbps_4k` — `title_v_quality_mp4_24p_100mbps_4k_q` `[videoquality=mp4_24p_100mbps_4k]` — “3840x2160,24p”
      - `menu_item_id_v_quality_mp4_24p_72mbps_4k_10bit` — `title_v_quality_mp4_24p_72mbps_4k_10bit_q` `[videoquality=mp4_24p_72mbps_4k_10bit]` — “3840x2160,24p”
      - `menu_item_id_v_quality_mp4_60p_28mbps` — `title_v_quality_mp4_60p_28mbps_q` `[videoquality=mp4_60p_28mbps]` — “1920x1080,60p”
      - `menu_item_id_v_quality_mp4_50p_28mbps` — `title_v_quality_mp4_50p_28mbps_q` `[videoquality=mp4_50p_28mbps]` — “1920x1080,50p”
      - `menu_item_id_v_quality_mp4_30p_20mbps` — `title_v_quality_mp4_30p_20mbps_q` `[videoquality=mp4_30p_20mbps]` — “1920x1080,30p”
      - `menu_item_id_v_quality_mp4_25p_20mbps` — `title_v_quality_mp4_25p_20mbps_q` `[videoquality=mp4_25p_20mbps]` — “1920x1080,25p”
      - `menu_item_id_v_quality_mp4_24p_24mbps` — `title_v_quality_mp4_24p_24mbps_q` `[videoquality=mp4_24p_24mbps]` — “1920x1080,24p”
      - `menu_item_id_v_quality_mov_30p_200mbps_5_9k_10bit` — `title_v_quality_mov_30p_200mbps_5_9k_10bit_q` `[videoquality=mov_30p_200mbps_5_9k_10bit]` — “5888x3312,30p,420/10bit”
      - `menu_item_id_v_quality_mov_25p_200mbps_5_9k_10bit` — `title_v_quality_mov_25p_200mbps_5_9k_10bit_q` `[videoquality=mov_25p_200mbps_5_9k_10bit]` — “5888x3312,25p,420/10bit”
      - `menu_item_id_v_quality_mov_24p_200mbps_5_9k_10bit` — `title_v_quality_mov_24p_200mbps_5_9k_10bit_q` `[videoquality=mov_24p_200mbps_5_9k_10bit]` — “5888x3312,24p,420/10bit”
      - `menu_item_id_v_quality_mov_60p_150mbps_c4k` — `title_v_quality_mov_60p_150mbps_c4k_q` `[videoquality=mov_60p_150mbps_c4k]` — “4096x2160,60p,420/8bit”
      - `menu_item_id_v_quality_mov_50p_150mbps_c4k` — `title_v_quality_mov_50p_150mbps_c4k_q` `[videoquality=mov_50p_150mbps_c4k]` — “4096x2160,50p,420/8bit”
      - `menu_item_id_v_quality_mov_30p_150mbps_c4k_10bit` — `title_v_quality_mov_30p_150mbps_c4k_10bit_q` `[videoquality=mov_30p_150mbps_c4k_10bit]` — “4096x2160,30p,422/10bit”
      - `menu_item_id_v_quality_mov_30p_100mbps_c4k` — `title_v_quality_mov_30p_100mbps_c4k_q` `[videoquality=mov_30p_100mbps_c4k]` — “4096x2160,30p,420/8bit”
      - `menu_item_id_v_quality_mov_25p_150mbps_c4k_10bit` — `title_v_quality_mov_25p_150mbps_c4k_10bit_q` `[videoquality=mov_25p_150mbps_c4k_10bit]` — “4096x2160,25p,422/10bit”
      - `menu_item_id_v_quality_mov_25p_100mbps_c4k` — `title_v_quality_mov_25p_100mbps_c4k_q` `[videoquality=mov_25p_100mbps_c4k]` — “4096x2160,25p,420/8bit”
      - `menu_item_id_v_quality_mov_24p_150mbps_c4k_10bit` — `title_v_quality_mov_24p_150mbps_c4k_10bit_q` `[videoquality=mov_24p_150mbps_c4k_10bit]` — “4096x2160,24p,422/10bit”
      - `menu_item_id_v_quality_mov_24p_100mbps_c4k` — `title_v_quality_mov_24p_100mbps_c4k_q` `[videoquality=mov_24p_100mbps_c4k]` — “4096x2160,24p,420/8bit”
      - `menu_item_id_v_quality_mov_60p_200mbps_4k_10bit` — `title_v_quality_mov_60p_200mbps_4k_10bit_q` `[videoquality=mov_60p_200mbps_4k_10bit]` — “3840x2160,60p,420/10bit”
      - `menu_item_id_v_quality_mov_60p_150mbps_4k` — `title_v_quality_mov_60p_150mbps_4k_q` `[videoquality=mov_60p_150mbps_4k]` — “3840x2160,60p,420/8bit”
      - `menu_item_id_v_quality_mov_50p_200mbps_4k_10bit` — `title_v_quality_mov_50p_200mbps_4k_10bit_q` `[videoquality=mov_50p_200mbps_4k_10bit]` — “3840x2160,50p,420/10bit”
      - `menu_item_id_v_quality_mov_50p_150mbps_4k` — `title_v_quality_mov_50p_150mbps_4k_q` `[videoquality=mov_50p_150mbps_4k]` — “3840x2160,50p,420/8bit”
      - `menu_item_id_v_quality_mov_30p_150mbps_4k_10bit` — `title_v_quality_mov_30p_150mbps_4k_10bit_q` `[videoquality=mov_30p_150mbps_4k_10bit]` — “3840x2160,30p,422/10bit”
      - `menu_item_id_v_quality_mov_30p_100mbps_4k` — `title_v_quality_mov_30p_100mbps_4k_q` `[videoquality=mov_30p_100mbps_4k]` — “3840x2160,30p,420/8bit”
      - `menu_item_id_v_quality_mov_25p_150mbps_4k_10bit` — `title_v_quality_mov_25p_150mbps_4k_10bit_q` `[videoquality=mov_25p_150mbps_4k_10bit]` — “3840x2160,25p,422/10bit”
      - `menu_item_id_v_quality_mov_25p_100mbps_4k` — `title_v_quality_mov_25p_100mbps_4k_q` `[videoquality=mov_25p_100mbps_4k]` — “3840x2160,25p,420/8bit”
      - `menu_item_id_v_quality_mov_24p_150mbps_4k_10bit` — `title_v_quality_mov_24p_150mbps_4k_10bit_q` `[videoquality=mov_24p_150mbps_4k_10bit]` — “3840x2160,24p,422/10bit”
      - `menu_item_id_v_quality_mov_24p_100mbps_4k` — `title_v_quality_mov_24p_100mbps_4k_q` `[videoquality=mov_24p_100mbps_4k]` — “3840x2160,24p,420/8bit”
      - `menu_item_id_v_quality_mov_60p_100mbps_10bit` — `title_v_quality_mov_60p_100mbps_10bit_q` `[videoquality=mov_60p_100mbps_10bit]` — “1920x1080,60p,422/10bit”
      - `menu_item_id_v_quality_mov_60p_100mbps` — `title_v_quality_mov_60p_100mbps_q` `[videoquality=mov_60p_100mbps]` — “1920x1080,60p,420/8bit”
      - `menu_item_id_v_quality_mov_50p_100mbps_10bit` — `title_v_quality_mov_50p_100mbps_10bit_q` `[videoquality=mov_50p_100mbps_10bit]` — “1920x1080,50p,422/10bit”
      - `menu_item_id_v_quality_mov_50p_100mbps` — `title_v_quality_mov_50p_100mbps_q` `[videoquality=mov_50p_100mbps]` — “1920x1080,50p,420/8bit”
      - `menu_item_id_v_quality_mov_30p_100mbps_10bit` — `title_v_quality_mov_30p_100mbps_10bit_q` `[videoquality=mov_30p_100mbps_10bit]` — “1920x1080,30p,422/10bit”
      - `menu_item_id_v_quality_mov_30p_100mbps` — `title_v_quality_mov_30p_100mbps_q` `[videoquality=mov_30p_100mbps]` — “1920x1080,30p,420/8bit”
      - `menu_item_id_v_quality_mov_25p_100mbps_10bit` — `title_v_quality_mov_25p_100mbps_10bit_q` `[videoquality=mov_25p_100mbps_10bit]` — “1920x1080,25p,422/10bit”
      - `menu_item_id_v_quality_mov_25p_100mbps` — `title_v_quality_mov_25p_100mbps_q` `[videoquality=mov_25p_100mbps]` — “1920x1080,25p,420/8bit”
      - `menu_item_id_v_quality_mov_24p_100mbps_10bit` — `title_v_quality_mov_24p_100mbps_10bit_q` `[videoquality=mov_24p_100mbps_10bit]` — “1920x1080,24p,422/10bit”
      - `menu_item_id_v_quality_mov_24p_100mbps` — `title_v_quality_mov_24p_100mbps_q` `[videoquality=mov_24p_100mbps]` — “1920x1080,24p,420/8bit”

### `record_menu`

- `<menu>`
  - `menu_item_id_ph_sty` — `title_ph_sty` `[sp_embeded_ph_sty11]` — “Photo Style”
    - `<group>`
      - `menu_item_id_ph_sty_standard` — `title_ph_sty_standard` `[photostyle=standard/__value__]` — “Standard”
      - `menu_item_id_ph_sty_vivid` — `title_ph_sty_vivid` `[photostyle=vivid/__value__]` — “Vivid”
      - `menu_item_id_ph_sty_natural` — `title_ph_sty_natural` `[photostyle=natural/__value__]` — “Natural”
      - `menu_item_id_ph_sty_l_cla_neo` — `title_ph_sty_l_cla_neo` `[photostyle=l_cla_neo/__value__]` — “L.ClassicNeo”
      - `menu_item_id_ph_sty_flat` — `title_ph_sty_flat` `[photostyle=flat/__value__]` — “Flat”
      - `menu_item_id_ph_sty_scenery` — `title_ph_sty_scenery` `[photostyle=scenery/__value__]` — “Landscape”
      - `menu_item_id_ph_sty_portrait` — `title_ph_sty_portrait` `[photostyle=portrait/__value__]` — “Portrait”
      - `menu_item_id_ph_sty_bw` — `title_ph_sty_bw` `[photostyle=bw/__value__]` — “Monochrome”
      - `menu_item_id_ph_sty_l_bw` — `title_ph_sty_l_bw` `[photostyle=l_bw/__value__]` — “L.Monochrome”
      - `menu_item_id_ph_sty_l_bw_d` — `title_ph_sty_l_bw_d` `[photostyle=l_bw_d/__value__]` — “L.Monochrome D”
      - `menu_item_id_ph_sty_l_bw_s` — `title_ph_sty_l_bw_s` `[photostyle=l_bw_s/__value__]` — “L.Monochrome S”
      - `menu_item_id_ph_sty_cinelike_d2` — `title_ph_sty_cinelike_d2` `[photostyle=cinelike_d2/__value__]` — “Cinelike D2”
      - `menu_item_id_ph_sty_cinelike_v2` — `title_ph_sty_cinelike_v2` `[photostyle=cinelike_v2/__value__]` — “Cinelike V2”
      - `menu_item_id_ph_sty_709like` — `title_ph_sty_709like` `[photostyle=709like/__value__]` — “Like709”
      - `menu_item_id_ph_sty_vlog` — `title_ph_sty_vlog` `[photostyle=vlog/__value__]` — “V-Log”
      - `menu_item_id_ph_sty_hlg_standard` — `title_ph_sty_hlg_standard` `[photostyle=hlg_standard/__value__]` — “Standard(HLG)”
      - `menu_item_id_ph_sty_hlg_bw` — `title_ph_sty_hlg_bw` `[photostyle=hlg_bw/__value__]` — “Monochrome(HLG)”
      - `menu_item_id_ph_sty_hlg` — `title_ph_sty_hlg` `[photostyle=hlg/__value__]` — “Like2100(HLG)”
      - `menu_item_id_ph_sty_custom1` — `title_ph_sty_custom1` `[photostyle=custom1/__value__]` — “MY PHOTO STYLE 1”
      - `menu_item_id_ph_sty_custom2` — `title_ph_sty_custom2` `[photostyle=custom2/__value__]` — “MY PHOTO STYLE 2”
      - `menu_item_id_ph_sty_custom3` — `title_ph_sty_custom3` `[photostyle=custom3/__value__]` — “MY PHOTO STYLE 3”
      - `menu_item_id_ph_sty_custom4` — `title_ph_sty_custom4` `[photostyle=custom4/__value__]` — “MY PHOTO STYLE 4”
      - `menu_item_id_ph_sty_custom5` — `title_ph_sty_custom5` `[photostyle=custom5/__value__]` — “MY PHOTO STYLE 5”
      - `menu_item_id_ph_sty_custom6` — `title_ph_sty_custom6` `[photostyle=custom6/__value__]` — “MY PHOTO STYLE 6”
      - `menu_item_id_ph_sty_custom7` — `title_ph_sty_custom7` `[photostyle=custom7/__value__]` — “MY PHOTO STYLE 7”
      - `menu_item_id_ph_sty_custom8` — `title_ph_sty_custom8` `[photostyle=custom8/__value__]` — “MY PHOTO STYLE 8”
      - `menu_item_id_ph_sty_custom9` — `title_ph_sty_custom9` `[photostyle=custom9/__value__]` — “MY PHOTO STYLE 9”
      - `menu_item_id_ph_sty_custom10` — `title_ph_sty_custom10` `[photostyle=custom10/__value__]` — “MY PHOTO STYLE 10”
  - `menu_item_id_ph_sty_customs` — `title_ph_sty` `[sp_embeded_ph_sty_customs]` — “Photo Style”
    - `<group>`
      - `menu_item_id_ph_sty_customs_standard` — `title_ph_sty_standard` `[photostyle=__value__/standard]` — “Standard”
      - `menu_item_id_ph_sty_customs_vivid` — `title_ph_sty_vivid` `[photostyle=__value__/vivid]` — “Vivid”
      - `menu_item_id_ph_sty_customs_natural` — `title_ph_sty_natural` `[photostyle=__value__/natural]` — “Natural”
      - `menu_item_id_ph_sty_customs_l_cla_neo` — `title_ph_sty_l_cla_neo` `[photostyle=__value__/l_cla_neo]` — “L.ClassicNeo”
      - `menu_item_id_ph_sty_customs_flat` — `title_ph_sty_flat` `[photostyle=__value__/flat]` — “Flat”
      - `menu_item_id_ph_sty_customs_scenery` — `title_ph_sty_scenery` `[photostyle=__value__/scenery]` — “Landscape”
      - `menu_item_id_ph_sty_customs_portrait` — `title_ph_sty_portrait` `[photostyle=__value__/portrait]` — “Portrait”
      - `menu_item_id_ph_sty_customs_bw` — `title_ph_sty_bw` `[photostyle=__value__/bw]` — “Monochrome”
      - `menu_item_id_ph_sty_customs_l_bw` — `title_ph_sty_l_bw` `[photostyle=__value__/l_bw]` — “L.Monochrome”
      - `menu_item_id_ph_sty_customs_l_bw_d` — `title_ph_sty_l_bw_d` `[photostyle=__value__/l_bw_d]` — “L.Monochrome D”
      - `menu_item_id_ph_sty_customs_l_bw_s` — `title_ph_sty_l_bw_s` `[photostyle=__value__/l_bw_s]` — “L.Monochrome S”
      - `menu_item_id_ph_sty_customs_cinelike_d2` — `title_ph_sty_cinelike_d2` `[photostyle=__value__/cinelike_d2]` — “Cinelike D2”
      - `menu_item_id_ph_sty_customs_cinelike_v2` — `title_ph_sty_cinelike_v2` `[photostyle=__value__/cinelike_v2]` — “Cinelike V2”
      - `menu_item_id_ph_sty_customs_709like` — `title_ph_sty_709like` `[photostyle=__value__/709like]` — “Like709”
      - `menu_item_id_ph_sty_customs_vlog` — `title_ph_sty_vlog` `[photostyle=__value__/vlog]` — “V-Log”
      - `menu_item_id_ph_sty_customs_hlg_standard` — `title_ph_sty_hlg_standard` `[photostyle=__value__/hlg_standard]` — “Standard(HLG)”
      - `menu_item_id_ph_sty_customs_hlg_bw` — `title_ph_sty_hlg_bw` `[photostyle=__value__/hlg_bw]` — “Monochrome(HLG)”
      - `menu_item_id_ph_sty_customs_hlg` — `title_ph_sty_hlg` `[photostyle=__value__/hlg]` — “Like2100(HLG)”
  - `menu_item_id_lightmet` — `title_lightmet` `[select]` — “Metering Mode”
    - `<group>`
      - `menu_item_id_lightmet_multi` — `title_lightmet_multi` `[lightmetering=multi]` — “Multi Metering”
      - `menu_item_id_lightmet_center` — `title_lightmet_center` `[lightmetering=center]` — “Center Weighted”
      - `menu_item_id_lightmet_spot` — `title_lightmet_spot` `[lightmetering=spot]` — “Spot”
      - `menu_item_id_lightmet_highlight` — `title_lightmet_highlight` `[lightmetering=highlight]` — “Highlight Weighted”
  - `menu_item_id_asprat` — `title_asprat` `[select]` — “Aspect Ratio”
    - `<group>`
      - `menu_item_id_asprat_4:3` — `title_asprat_4:3` `[aspectratio=4:3]` — “4:3”
      - `menu_item_id_asprat_3:2` — `title_asprat_3:2` `[aspectratio=3:2]` — “3:2”
      - `menu_item_id_asprat_16:9` — `title_asprat_16:9` `[aspectratio=16:9]` — “16:9”
      - `menu_item_id_asprat_1:1` — `title_asprat_1:1` `[aspectratio=1:1]` — “1:1”
      - `menu_item_id_asprat_65:24` — `title_asprat_65:24` `[aspectratio=65:24]` — “65:24”
      - `menu_item_id_asprat_2:1` — `title_asprat_2:1` `[aspectratio=2:1]` — “2:1”
  - `menu_item_id_quality` — `title_quality` `[select]` — “Picture Quality”
    - `<group>`
      - `menu_item_id_quality_fine` — `title_quality_fine` `[quality=fine]` — “Fine”
      - `menu_item_id_quality_standard` — `title_quality_standard` `[quality=standard]` — “Standard”
      - `menu_item_id_quality_raw_fine` — `title_quality_raw_fine` `[quality=raw_fine]` — “RAW+Fine”
      - `menu_item_id_quality_raw_standard` — `title_quality_raw_standard` `[quality=raw_standard]` — “RAW+Standard”
      - `menu_item_id_quality_raw` — `title_quality_raw` `[quality=raw]` — “RAW”
  - `menu_item_id_pctsiz` — `title_pctsiz` `[select]` — “Picture Size”
    - `<group>`
      - `menu_item_id_pictsize_L21.5m` — `title_pictsize_L21.5m` `[pictsize=21.5m]` — “L 21.5M”
      - `menu_item_id_pictsize_L24m` — `title_pictsize_L24m` `[pictsize=24m]` — “L 24M”
      - `menu_item_id_pictsize_L20m` — `title_pictsize_L20m` `[pictsize=20m]` — “L 20M”
      - `menu_item_id_pictsize_L16m` — `title_pictsize_L16m` `[pictsize=16m]` — “L 16M”
      - `menu_item_id_pictsize_L13m` — `title_pictsize_L13m` `[pictsize=13m]` — “L 13M”
      - `menu_item_id_pictsize_L18m` — `title_pictsize_L18m` `[pictsize=18m]` — “L 18M”
      - `menu_item_id_pictsize_L9.5m` — `title_pictsize_L9.5m` `[pictsize=9.5m]` — “L 9.5M”
      - `menu_item_id_pictsize_L10.5m` — `title_pictsize_L10.5m` `[pictsize=10.5m]` — “L 10.5M”
      - `menu_item_id_pictsize_L9m` — `title_pictsize_L9m` `[pictsize=9m]` — “L 9M”
      - `menu_item_id_pictsize_L7m` — `title_pictsize_L7m` `[pictsize=7m]` — “L 7M”
      - `menu_item_id_pictsize_M10.5m` — `title_pictsize_M10.5m` `[pictsize=10.5m]` — “M 10.5M”
      - `menu_item_id_pictsize_M12m` — `title_pictsize_M12m` `[pictsize=12m]` — “M 12M”
      - `menu_item_id_pictsize_M10m` — `title_pictsize_M10m` `[pictsize=10m]` — “M 10M”
      - `menu_item_id_pictsize_M8m` — `title_pictsize_M8m` `[pictsize=8m]` — “M 8M”
      - `menu_item_id_pictsize_exM10.5m` — `title_pictsize_exM10.5m` `[pictsize=10.5m]` — “EX M 10.5M”
      - `menu_item_id_pictsize_exM12m` — `title_pictsize_exM12m` `[pictsize=12m]` — “EX M 12M”
      - `menu_item_id_pictsize_exM10m` — `title_pictsize_exM10m` `[pictsize=10m]` — “EX M 10M”
      - `menu_item_id_pictsize_exM8m` — `title_pictsize_exM8m` `[pictsize=8m]` — “EX M 8M”
      - `menu_item_id_pictsize_M5m` — `title_pictsize_M5m` `[pictsize=5m]` — “M 5M”
      - `menu_item_id_pictsize_M5.5m` — `title_pictsize_M5.5m` `[pictsize=5.5m]` — “M 5.5M”
      - `menu_item_id_pictsize_M4.5m` — `title_pictsize_M4.5m` `[pictsize=4.5m]` — “M 4.5M”
      - `menu_item_id_pictsize_M3.5m` — `title_pictsize_M3.5m` `[pictsize=3.5m]` — “M 3.5M”
      - `menu_item_id_pictsize_exM5m` — `title_pictsize_exM5m` `[pictsize=5m]` — “EX M 5M”
      - `menu_item_id_pictsize_exM5.5m` — `title_pictsize_exM5.5m` `[pictsize=5.5m]` — “EX M 5.5M”
      - `menu_item_id_pictsize_exM4.5m` — `title_pictsize_exM4.5m` `[pictsize=4.5m]` — “EX M 4.5M”
      - `menu_item_id_pictsize_exM3.5m` — `title_pictsize_exM3.5m` `[pictsize=3.5m]` — “EX M 3.5M”
      - `menu_item_id_pictsize_S5.5m` — `title_pictsize_S5.5m` `[pictsize=5.5m]` — “S 5.5M”
      - `menu_item_id_pictsize_S6m` — `title_pictsize_S6m` `[pictsize=6m]` — “S 6M”
      - `menu_item_id_pictsize_S5m` — `title_pictsize_S5m` `[pictsize=5m]` — “S 5M”
      - `menu_item_id_pictsize_S4m` — `title_pictsize_S4m` `[pictsize=4m]` — “S 4M”
      - `menu_item_id_pictsize_exS5.5m` — `title_pictsize_exS5.5m` `[pictsize=5.5m]` — “EX S 5.5M”
      - `menu_item_id_pictsize_exS6m` — `title_pictsize_exS6m` `[pictsize=6m]` — “EX S 6M”
      - `menu_item_id_pictsize_exS5m` — `title_pictsize_exS5m` `[pictsize=5m]` — “EX S 5M”
      - `menu_item_id_pictsize_exS4m` — `title_pictsize_exS4m` `[pictsize=4m]` — “EX S 4M”
      - `menu_item_id_pictsize_S2.5m` — `title_pictsize_S2.5m` `[pictsize=2.5m]` — “S 2.5M”
      - `menu_item_id_pictsize_S3m` — `title_pictsize_S3m` `[pictsize=3m]` — “S 3M”
      - `menu_item_id_pictsize_S2m` — `title_pictsize_S2m` `[pictsize=2m]` — “S 2M”
      - `menu_item_id_pictsize_exS2.5m` — `title_pictsize_exS2.5m` `[pictsize=2.5m]` — “EX S 2.5M”
      - `menu_item_id_pictsize_exS3m` — `title_pictsize_exS3m` `[pictsize=3m]` — “EX S 3M”
      - `menu_item_id_pictsize_exS2m` — `title_pictsize_exS2m` `[pictsize=2m]` — “EX S 2M”
  - `menu_item_id_hlg_photo` — `title_hlg_photo` `[select]` — “HLG Photo”
    - `<group>`
      - `menu_item_id_hlg_photo_full` — `title_hlg_photo_full` `[hlg=full]` — “Full-Res.”
      - `menu_item_id_hlg_photo_4k` — `title_hlg_photo_4k` `[hlg=4k]` — “4K-Res.”
      - `menu_item_id_hlg_photo_off` — `title_hlg_photo_off` `[hlg=off]` — “Off”
  - `menu_item_id_hrs` — `title_hrs` `[submenu]` — “High Resolution Mode”
    - `<menu>`
      - `menu_item_id_hrs_start` — `title_hrs_start` `[sp_embeded_hrs_start]` — “Start”
      - `menu_item_id_hrs_pictsize` — `title_hrs_pictsize` `[select]` — “Picture Size”
        - `<group>`
          - `menu_item_id_hrs_pictsize_xl_4_3` — `title_hrs_pictsize_xl_4_3_85m` `[hrs_pictsize=xl]` — “XL 85M”
          - `menu_item_id_hrs_pictsize_ll_4_3` — `title_hrs_pictsize_ll_4_3_42_5m` `[hrs_pictsize=ll]` — “LL 42.5M”
          - `menu_item_id_hrs_pictsize_xl_3_2` — `title_hrs_pictsize_xl_3_2_96m` `[hrs_pictsize=xl]` — “XL 96M”
          - `menu_item_id_hrs_pictsize_ll_3_2` — `title_hrs_pictsize_ll_3_2_48m` `[hrs_pictsize=ll]` — “LL 48M”
          - `menu_item_id_hrs_pictsize_xl_16_9` — `title_hrs_pictsize_xl_16_9_81m` `[hrs_pictsize=xl]` — “XL 81M”
          - `menu_item_id_hrs_pictsize_ll_16_9` — `title_hrs_pictsize_ll_16_9_40_5m` `[hrs_pictsize=ll]` — “LL 40.5M”
          - `menu_item_id_hrs_pictsize_xl_1_1` — `title_hrs_pictsize_xl_1_1_64m` `[hrs_pictsize=xl]` — “XL 64M”
          - `menu_item_id_hrs_pictsize_ll_1_1` — `title_hrs_pictsize_ll_1_1_32m` `[hrs_pictsize=ll]` — “LL 32M”
      - `menu_item_id_hrs_quality` — `title_hrs_quality` `[select]` — “Picture Quality”
        - `<group>`
          - `menu_item_id_hrs_quality_fine` — `title_hrs_quality_fine` `[hrs_quality=fine]` — “Fine”
          - `menu_item_id_hrs_quality_raw_fine` — `title_hrs_quality_raw_fine` `[hrs_quality=raw_fine]` — “RAW+Fine”
          - `menu_item_id_hrs_quality_raw` — `title_hrs_quality_raw` `[hrs_quality=raw]` — “RAW”
          - `menu_item_id_hrs_quality_auto` — `title_hrs_quality_auto` `[hrs_quality=auto]` — “Combined”
      - `menu_item_id_hrs_simul_rec` — `title_hrs_simul_rec` `[on_off]` — “Simul Record Normal Shot”
      - `menu_item_id_hrs_wait_time` — `title_hrs_wait_time` `[select]` — “Shutter Delay”
        - `<group>`
          - `menu_item_id_hrs_wait_time_30` — `title_hrs_wait_time_30` `[hrs_wait_time=30]` — “30 SEC”
          - `menu_item_id_hrs_wait_time_15` — `title_hrs_wait_time_15` `[hrs_wait_time=15]` — “15 SEC”
          - `menu_item_id_hrs_wait_time_8` — `title_hrs_wait_time_8` `[hrs_wait_time=8]` — “8 SEC”
          - `menu_item_id_hrs_wait_time_4` — `title_hrs_wait_time_4` `[hrs_wait_time=4]` — “4 SEC”
          - `menu_item_id_hrs_wait_time_2` — `title_hrs_wait_time_2` `[hrs_wait_time=2]` — “2 SEC”
          - `menu_item_id_hrs_wait_time_1` — `title_hrs_wait_time_1` `[hrs_wait_time=1]` — “1 SEC”
          - `menu_item_id_hrs_wait_time_1/2` — `title_hrs_wait_time_1/2` `[hrs_wait_time=1/2]` — “1/2 SEC”
          - `menu_item_id_hrs_wait_time_1/4` — `title_hrs_wait_time_1/4` `[hrs_wait_time=1/4]` — “1/4 SEC”
          - `menu_item_id_hrs_wait_time_1/8` — `title_hrs_wait_time_1/8` `[hrs_wait_time=1/8]` — “1/8 SEC”
          - `menu_item_id_hrs_wait_time_off` — `title_hrs_wait_time_off` `[hrs_wait_time=off]` — “Off”
      - `menu_item_id_hrs_is_mode` — `title_hrs_is_mode` `[select]` — “Motion Blur Processing”
        - `<group>`
          - `menu_item_id_hrs_is_mode_mode1` — `title_hrs_is_mode_mode1` `[hrs_is_mode=mode1]` — “MODE1”
          - `menu_item_id_hrs_is_mode_mode2` — `title_hrs_is_mode_mode2` `[hrs_is_mode=mode2]` — “MODE2”
  - `menu_item_id_filter_set` — `title_filter_set` `[sp_embeded_filter_set]` — “Filter Settings”
    - `<group>`
      - `menu_item_id_filter_set_noeffect` — `title_filter_set_noeffect` `[filter_setting=noeffect]` — “No Effect”
      - `menu_item_id_filter_set_pop` — `title_crtv_ctrl_pop` `[filter_setting=pop]` — “Expressive”
      - `menu_item_id_filter_set_retro` — `title_crtv_ctrl_retro` `[filter_setting=retro]` — “Retro”
      - `menu_item_id_filter_set_old_days` — `title_crtv_ctrl_old_days` `[filter_setting=old_days]` — “Old Days”
      - `menu_item_id_filter_set_high_key` — `title_crtv_ctrl_high_key` `[filter_setting=high_key]` — “High Key”
      - `menu_item_id_filter_set_low_key` — `title_crtv_ctrl_low_key` `[filter_setting=low_key]` — “Low Key”
      - `menu_item_id_filter_set_sepia` — `title_crtv_ctrl_sepia` `[filter_setting=sepia]` — “Sepia”
      - `menu_item_id_filter_set_monochro` — `title_crtv_ctrl_monochro` `[filter_setting=monochro]` — “Monochrome”
      - `menu_item_id_filter_set_dynamic_monochro` — `title_crtv_ctrl_dynamic_monochro` `[filter_setting=dynamic_monochro]` — “Dynamic Monochrome”
      - `menu_item_id_filter_set_rough_monochro` — `title_crtv_ctrl_rough_monochro` `[filter_setting=rough_monochro]` — “Rough Monochrome”
      - `menu_item_id_filter_set_silky_monochro` — `title_crtv_ctrl_silky_monochro` `[filter_setting=silky_monochro]` — “Silky Monochrome”
      - `menu_item_id_filter_set_impressive_art` — `title_crtv_ctrl_impressive_art` `[filter_setting=impressive_art]` — “Impressive Art”
      - `menu_item_id_filter_set_high_dynamic` — `title_crtv_ctrl_high_dynamic` `[filter_setting=high_dynamic]` — “High Dynamic”
      - `menu_item_id_filter_set_cross_proc` — `title_crtv_ctrl_cross_proc` `[filter_setting=cross_proc]` — “Cross Process”
      - `menu_item_id_filter_set_toy_photo` — `title_crtv_ctrl_toy_photo` `[filter_setting=toy_photo]` — “Toy Effect”
      - `menu_item_id_filter_set_toy_pop` — `title_crtv_ctrl_toy_pop` `[filter_setting=toy_pop]` — “Toy Pop”
      - `menu_item_id_filter_set_bleach_bypass` — `title_crtv_ctrl_bleach_bypass` `[filter_setting=bleach_bypass]` — “Bleach Bypass”
      - `menu_item_id_filter_set_diorama` — `title_crtv_ctrl_diorama` `[filter_setting=diorama]` — “Miniature Effect”
      - `menu_item_id_filter_set_soft_focus` — `title_crtv_ctrl_soft_focus` `[filter_setting=soft_focus]` — “Soft Focus”
      - `menu_item_id_filter_set_fantasy` — `title_crtv_ctrl_fantasy` `[filter_setting=fantasy]` — “Fantasy”
      - `menu_item_id_filter_set_cross_filter` — `title_crtv_ctrl_cross_filter` `[filter_setting=cross_filter]` — “Star Filter”
      - `menu_item_id_filter_set_one_point_color` — `title_crtv_ctrl_one_point_color` `[filter_setting=one_point_color]` — “One Point Color”
      - `menu_item_id_filter_set_sunshine` — `title_crtv_ctrl_sunshine` `[filter_setting=sunshine]` — “Sunshine”
  - `menu_item_id_focusmode` — `title_focusmode` `[select]` — “Focus Mode”
    - `<group>`
      - `menu_item_id_focusmode_afs` — `title_focusmode_afs` `[focusmode=afs]` — “AFS”
      - `menu_item_id_focusmode_afc` — `title_focusmode_afc` `[focusmode=afc]` — “AFC”
      - `menu_item_id_focusmode_mf` — `title_focusmode_mf` `[focusmode=mf]` — “MF”
  - `menu_item_id_afmode` — `title_afmode` `[sp_embeded_afmode]` — “AF Mode”
    - `<group>`
      - `menu_item_id_afmode_auto_recognize_animal_off` — `title_afmode_auto_recognize_animal_off` `[afmode=auto_recognize/animal_off]` — “Human Detect AF”
      - `menu_item_id_afmode_auto_recognize_animal_on` — `title_afmode_auto_recognize_animal_on` `[afmode=auto_recognize/animal_on]` — “Human/Animal Detect AF”
      - `menu_item_id_afmode_aftracking` — `title_afmode_aftracking` `[afmode=aftracking]` — “Tracking”
      - `menu_item_id_afmode_225area_detail_225area` — `title_afmode_225area_detail_225area` `[afmode=225area_detail/225area]` — “225-Area”
      - `menu_item_id_afmode_225area_detail_225area_afc` — `title_afmode_225area_detail_225area_afc` `[afmode=225area_detail/225area_afc]` — “225-Area (AFC Starting-pt.)”
      - `menu_item_id_afmode_v_h_horizontal` — `title_afmode_v_h_horizontal` `[afmode=v_h/horizontal]` — “Zone (Horz.)”
      - `menu_item_id_afmode_v_h_vertical` — `title_afmode_v_h_vertical` `[afmode=v_h/vertical]` — “Zone (Vert.)”
      - `menu_item_id_afmode_square` — `title_afmode_square` `[afmode=square]` — “Zone (Square)”
      - `menu_item_id_afmode_oval` — `title_afmode_oval` `[afmode=oval]` — “Zone (Oval)”
      - `menu_item_id_afmode_1area_asst` — `title_afmode_1area_asst` `[afmode=1area_asst/auto_off]` — “1-Area+”
      - `menu_item_id_afmode_1area_asst_auto` — `title_afmode_1area_asst_auto` `[afmode=1area_asst/auto]` — “1-Area+(Human Detection)”
      - `menu_item_id_afmode_1area_asst_auto_anml` — `title_afmode_1area_asst_auto_anml` `[afmode=1area_asst/auto_anml]` — “1-Area+(Human/Animal Detect)”
      - `menu_item_id_afmode_1area` — `title_afmode_1area` `[afmode=1area/auto_off]` — “1-Area”
      - `menu_item_id_afmode_1area_auto` — `title_afmode_1area_auto` `[afmode=1area/auto]` — “1-Area(Human Detection)”
      - `menu_item_id_afmode_1area_auto_anml` — `title_afmode_1area_auto_anml` `[afmode=1area/auto_anml]` — “1-Area(Human/Animal Detect)”
      - `menu_item_id_afmode_pinpoint` — `title_afmode_pinpoint` `[afmode=pinpoint]` — “Pinpoint”
      - `menu_item_id_afmode_custom_1` — `title_afmode_custom_1` `[afmode=custom_1]` — “Custom1”
      - `menu_item_id_afmode_custom_2` — `title_afmode_custom_2` `[afmode=custom_2]` — “Custom2”
      - `menu_item_id_afmode_custom_3` — `title_afmode_custom_3` `[afmode=custom_3]` — “Custom3”
  - `menu_item_id_flash` — `title_flash` `[select]` — “Flash Mode”
    - `<group>`
      - `menu_item_id_flash_iauto` — `title_flash_iauto` `[flash=iauto]` — “iAuto”
      - `menu_item_id_flash_forcedflashon` — `title_flash_forcedflashon` `[flash=forcedflashon]` — “Forced Flash On”
      - `menu_item_id_flash_forced_on_redeye` — `title_flash_forced_on_redeye` `[flash=forced_on_redeye]` — “Forced On/Red-Eye”
      - `menu_item_id_flash_slowsync` — `title_flash_slowsync` `[flash=slowsync]` — “Slow Sync.”
      - `menu_item_id_flash_slowsyncredeye` — `title_flash_slowsyncredeye` `[flash=slowsyncredeye]` — “Slow Sync./Red-Eye”
      - `menu_item_id_flash_forcedflashoff` — `title_flash_forcedflashoff` `[flash=forcedflashoff]` — “Forced Flash Off”
  - `menu_item_id_drivemode` — `title_drivemode` `[select]` — “Drive Mode”
    - `<group>`
      - `menu_item_id_drivemode_1shoot` — `title_drivemode_1shoot` `[drivemode=normal]` — “Single”
      - `menu_item_id_drivemode_burst_1` — `title_drivemode_burst_1` `[drivemode=burst_1]` — “Burst Shot 1”
      - `menu_item_id_drivemode_burst_2` — `title_drivemode_burst_2` `[drivemode=burst_2]` — “Burst Shot 2”
      - `menu_item_id_drivemode_stopmotion_interval` — `title_drivemode_stopmotion_interval` `[drivemode=stopmotion_interval]` — “Time Lapse/Animation”
      - `menu_item_id_drivemode_selftimer` — `title_drivemode_selftimer` `[drivemode=selftimer]` — “Self Timer”
  - `menu_item_id_bracket` — `title_bracket` `[submenu]` — “Bracketing”
    - `<menu>`
      - `menu_item_id_bracket_type` — `title_bracket_type` `[select]` — “Bracketing Type”
        - `<group>`
          - `menu_item_id_bracket_exposure` — `title_bracket_exposure` `[bracket=exposure]` — “Exposure”
          - `menu_item_id_bracket_focal` — `title_bracket_focal` `[bracket=focal]` — “Aperture Value”
          - `menu_item_id_bracket_focus` — `title_bracket_focus` `[bracket=focus]` — “Focus”
          - `menu_item_id_bracket_wb` — `title_bracket_wb` `[bracket=wb]` — “WB (fine-tuning)”
          - `menu_item_id_bracket_wb_k` — `title_bracket_wb_k` `[bracket=wb_k]` — “WB (color temperature)”
          - `menu_item_id_bracket_aspect` — `title_bracket_aspect` `[bracket=aspect]` — “Aspect Ratio”
          - `menu_item_id_bracket_off` — `title_bracket_off` `[bracket=off]` — “Off”
      - `menu_item_id_bracket_exposure_step` — `title_bracket_exposure_step` `[select]` — “Step”
        - `<group>`
          - `menu_item_id_bracket_exposure_step_3shot_1/3ev` — `title_bracket_exposure_step_3shot_1/3ev` `[bracket_exposure_step=3shot_1/3ev]` — “3・1/3”
          - `menu_item_id_bracket_exposure_step_3shot_2/3ev` — `title_bracket_exposure_step_3shot_2/3ev` `[bracket_exposure_step=3shot_2/3ev]` — “3・2/3”
          - `menu_item_id_bracket_exposure_step_3shot_1ev` — `title_bracket_exposure_step_3shot_1ev` `[bracket_exposure_step=3shot_1ev]` — “3・1”
          - `menu_item_id_bracket_exposure_step_5shot_1/3ev` — `title_bracket_exposure_step_5shot_1/3ev` `[bracket_exposure_step=5shot_1/3ev]` — “5・1/3”
          - `menu_item_id_bracket_exposure_step_5shot_2/3ev` — `title_bracket_exposure_step_5shot_2/3ev` `[bracket_exposure_step=5shot_2/3ev]` — “5・2/3”
          - `menu_item_id_bracket_exposure_step_5shot_1ev` — `title_bracket_exposure_step_5shot_1ev` `[bracket_exposure_step=5shot_1ev]` — “5・1”
          - `menu_item_id_bracket_exposure_step_7shot_1/3ev` — `title_bracket_exposure_step_7shot_1/3ev` `[bracket_exposure_step=7shot_1/3ev]` — “7・1/3”
          - `menu_item_id_bracket_exposure_step_7shot_2/3ev` — `title_bracket_exposure_step_7shot_2/3ev` `[bracket_exposure_step=7shot_2/3ev]` — “7・2/3”
          - `menu_item_id_bracket_exposure_step_7shot_1ev` — `title_bracket_exposure_step_7shot_1ev` `[bracket_exposure_step=7shot_1ev]` — “7・1”
      - `menu_item_id_bracket_exposure_sequence` — `title_bracket_exposure_sequence` `[select]` — “Sequence”
        - `<group>`
          - `menu_item_id_bracket_exposure_sequence_center` — `title_bracket_exposure_sequence_center` `[bracket_exposure_sequence=center]` — “0/-/+”
          - `menu_item_id_bracket_exposure_sequence_asc` — `title_bracket_exposure_sequence_asc` `[bracket_exposure_sequence=asc]` — “-/0/+”
      - `menu_item_id_bracket_exposure_shoot_type` — `title_bracket_exposure_shoot_type` `[select]` — “Single Shot Setting”
        - `<group>`
          - `menu_item_id_bracket_exposure_shoot_type_single` — `title_bracket_exposure_shoot_type_single` `[bracket_exposure_shoot_type=single]` — “ONE BY ONE”
          - `menu_item_id_bracket_exposure_shoot_type_burst` — `title_bracket_exposure_shoot_type_burst` `[bracket_exposure_shoot_type=burst]` — “ONE TAP”
      - `menu_item_id_bracket_focal_shoot_num` — `title_bracket_focal_shoot_num` `[select]` — “Shot Count”
        - `<group>`
          - `menu_item_id_bracket_focal_shoot_num_3` — `title_bracket_focal_shoot_num_3` `[bracket_focal_shoot_num=3]` — “3”
          - `menu_item_id_bracket_focal_shoot_num_5` — `title_bracket_focal_shoot_num_5` `[bracket_focal_shoot_num=5]` — “5”
          - `menu_item_id_bracket_focal_shoot_num_all` — `title_bracket_focal_shoot_num_all` `[bracket_focal_shoot_num=all]` — “ALL”
      - `menu_item_id_bracket_focus_step` — `title_bracket_focus_step` `[select]` — “Step”
        - `<group>`
          - `menu_item_id_bracket_focus_step_1` — `title_bracket_focus_step_1` `[bracket_focus_step=1]` — “+1”
          - `menu_item_id_bracket_focus_step_2` — `title_bracket_focus_step_2` `[bracket_focus_step=2]` — “+2”
          - `menu_item_id_bracket_focus_step_3` — `title_bracket_focus_step_3` `[bracket_focus_step=3]` — “+3”
          - `menu_item_id_bracket_focus_step_4` — `title_bracket_focus_step_4` `[bracket_focus_step=4]` — “+4”
          - `menu_item_id_bracket_focus_step_5` — `title_bracket_focus_step_5` `[bracket_focus_step=5]` — “+5”
          - `menu_item_id_bracket_focus_step_6` — `title_bracket_focus_step_6` `[bracket_focus_step=6]` — “+6”
          - `menu_item_id_bracket_focus_step_7` — `title_bracket_focus_step_7` `[bracket_focus_step=7]` — “+7”
          - `menu_item_id_bracket_focus_step_8` — `title_bracket_focus_step_8` `[bracket_focus_step=8]` — “+8”
          - `menu_item_id_bracket_focus_step_9` — `title_bracket_focus_step_9` `[bracket_focus_step=9]` — “+9”
          - `menu_item_id_bracket_focus_step_10` — `title_bracket_focus_step_10` `[bracket_focus_step=10]` — “+10”
      - `menu_item_id_bracket_focus_shoot_num` — `title_bracket_focus_shoot_num` `[sp_embeded_bracket_focus_shoot_num]` — “Shot Count”
      - `menu_item_id_bracket_focus_sequence` — `title_bracket_focus_sequence` `[select]` — “Sequence”
        - `<group>`
          - `menu_item_id_bracket_focus_sequence_center` — `title_bracket_focus_sequence_center` `[bracket_focus_sequence=center]` — “0/-/+”
          - `menu_item_id_bracket_focus_sequence_asc` — `title_bracket_focus_sequence_asc` `[bracket_focus_sequence=asc]` — “0/+”
  - `menu_item_id_burst_1` — `title_burst_speed_1` `[select]` — “Burst Shot 1 Setting”
    - `<group>`
      - `menu_item_id_burst_1_6k4k_photo` — `title_burst_6k4k_photo` `[drivemode=burst_1/6k4k_photo]` — “6K/4K PHOTO”
      - `menu_item_id_burst_1_h` — `title_burst_h` `[drivemode=burst_1/h]` — “H”
      - `menu_item_id_burst_1_m` — `title_burst_m` `[drivemode=burst_1/m]` — “M”
      - `menu_item_id_burst_1_l` — `title_burst_l` `[drivemode=burst_1/l]` — “L”
  - `menu_item_id_burst_2` — `title_burst_speed_2` `[select]` — “Burst Shot 2 Setting”
    - `<group>`
      - `menu_item_id_burst_2_6k4k_photo` — `title_burst_6k4k_photo` `[drivemode=burst_2/6k4k_photo]` — “6K/4K PHOTO”
      - `menu_item_id_burst_2_h` — `title_burst_h` `[drivemode=burst_2/h]` — “H”
      - `menu_item_id_burst_2_m` — `title_burst_m` `[drivemode=burst_2/m]` — “M”
      - `menu_item_id_burst_2_l` — `title_burst_l` `[drivemode=burst_2/l]` — “L”
  - `menu_item_id_stopmotion_interval` — `title_stopmotion_interval` `[submenu]` — “Time Lapse/Animation”
    - `<menu>`
      - `menu_item_id_stopmotion_interval_shoot_type` — `title_stopmotion_interval_shoot_type` `[select]` — “Mode”
        - `<group>`
          - `menu_item_id_stopmotion_interval_interval` — `title_stopmotion_interval_interval` `[drivemode=stopmotion_interval/interval]` — “Time Lapse Shot”
          - `menu_item_id_stopmotion_interval_stop_motion` — `title_stopmotion_interval_stop_motion` `[drivemode=stopmotion_interval/stop_motion]` — “Animation”
      - `menu_item_id_interval_set_interval` — `title_interval_set_interval` `[on_off]` — “Shooting Interval Setting”
      - `menu_item_id_interval_start_time` — `title_interval_start_time` `[submenu]` — “Start Time”
        - `<menu>`
          - `menu_item_id_interval_start_time_immediate` — `title_interval_start_time_immediate` `[interval_start_time=-1]` — “Now”
          - `menu_item_id_interval_start_time_set` — `title_interval_start_time_set` `[sp_embeded_interval_start_time_set]` — “Start Time Set”
      - `menu_item_id_interval_shoot_num` — `title_interval_shoot_num` `[sp_embeded_interval_shoot_num]` — “Image Count”
      - `menu_item_id_interval_shoot_interval` — `title_interval_shoot_interval` `[sp_embeded_interval_shoot_interval]` — “Shooting Interval”
      - `menu_item_id_interval_expo_leveling` — `title_interval_expo_leveling` `[on_off]` — “Exposure Leveling”
  - `menu_item_id_lc` — `title_lc` `[submenu]` — “Live View Composite”
    - `<menu>`
      - `menu_item_id_lc_start` — `title_lc_start` `[sp_embeded_lc_start]` — “Start”
      - `menu_item_id_lc_shut_delay` — `title_lc_shut_delay` `[select]` — “Shutter Delay”
        - `<group>`
          - `menu_item_id_lc_shut_delay_8` — `title_lc_shut_delay_8` `[lc_shut_delay=8]` — “8 SEC”
          - `menu_item_id_lc_shut_delay_4` — `title_lc_shut_delay_4` `[lc_shut_delay=4]` — “4 SEC”
          - `menu_item_id_lc_shut_delay_2` — `title_lc_shut_delay_2` `[lc_shut_delay=2]` — “2 SEC”
          - `menu_item_id_lc_shut_delay_1` — `title_lc_shut_delay_1` `[lc_shut_delay=1]` — “1 SEC”
          - `menu_item_id_lc_shut_delay_off` — `title_lc_shut_delay_off` `[lc_shut_delay=off]` — “OFF”
  - `menu_item_id_selftimer` — `title_selftimer` `[select]` — “Self Timer”
    - `<group>`
      - `menu_item_id_selftimer_10sec` — `title_selftimer_10sec` `[drivemode=selftimer/10sec]` — “10sec.”
      - `menu_item_id_selftimer_10sec3shot` — `title_selftimer_10sec3shot` `[drivemode=selftimer/10sec3shot]` — “10s / 3pictures”
      - `menu_item_id_selftimer_2sec` — `title_selftimer_2sec` `[drivemode=selftimer/2sec]` — “2sec.”
  - `menu_item_id_6k4k_photo` — `title_6k4k_photo` `[submenu]` — “6K/4K PHOTO”
    - `<menu>`
      - `menu_item_id_6k4k_photo_pictsize_burstspeed` — `title_6k4k_photo_pictsize_burstspeed` `[select]` — “Picture Size / Burst Speed”
        - `<group>`
          - `menu_item_id_pictsize_burstspeed_6k_18m_30p` — `title_pictsize_burstspeed_6k_18m_30p` `[pictsize_burstspeed=6k_18m_30p]` — “6K 18M/30fps”
          - `menu_item_id_pictsize_burstspeed_6k_14m_30p` — `title_pictsize_burstspeed_6k_14m_30p` `[pictsize_burstspeed=6k_14m_30p]` — “6K 14M/30fps”
          - `menu_item_id_pictsize_burstspeed_6k_15m_30p` — `title_pictsize_burstspeed_6k_15m_30p` `[pictsize_burstspeed=6k_15m_30p]` — “6K 15M/30fps”
          - `menu_item_id_pictsize_burstspeed_4k_8m_60p` — `title_pictsize_burstspeed_4k_8m_60p` `[pictsize_burstspeed=4k_8m_60p]` — “4K 8M/60fps”
          - `menu_item_id_pictsize_burstspeed_ex_4k_8m_60p` — `title_pictsize_burstspeed_ex_4k_8m_60p` `[pictsize_burstspeed=ex_4k_8m_60p]` — “EX 4K 8M/60fps”
          - `menu_item_id_pictsize_burstspeed_4k_8m_30p` — `title_pictsize_burstspeed_4k_8m_30p` `[pictsize_burstspeed=4k_8m_30p]` — “4K 8M/30fps”
          - `menu_item_id_pictsize_burstspeed_ex_4k_8m_30p` — `title_pictsize_burstspeed_ex_4k_8m_30p` `[pictsize_burstspeed=ex_4k_8m_30p]` — “EX 4K 8M/30fps”
      - `menu_item_id_6k4k_photo_6k4k_photo` — `title_6k4k_photo_6k4k_photo` `[select]` — “Rec Method”
        - `<group>`
          - `menu_item_id_6k4k_photo_6k_burst` — `title_6k4k_photo_6k_burst` `[6k4k_photo=6k_burst]` — “6K Burst”
          - `menu_item_id_6k4k_photo_6k_start_stop` — `title_6k4k_photo_6k_start_stop` `[6k4k_photo=6k_start_stop]` — “6K Burst(S/S)”
          - `menu_item_id_6k4k_photo_6k_pre_burst` — `title_6k4k_photo_6k_pre_burst` `[6k4k_photo=6k_pre_burst]` — “6K Pre-Burst”
          - `menu_item_id_6k4k_photo_4k_burst` — `title_6k4k_photo_4k_burst` `[6k4k_photo=4k_burst]` — “4K Burst”
          - `menu_item_id_6k4k_photo_4k_start_stop` — `title_6k4k_photo_4k_start_stop` `[6k4k_photo=4k_start_stop]` — “4K Burst(S/S)”
          - `menu_item_id_6k4k_photo_4k_pre_burst` — `title_6k4k_photo_4k_pre_burst` `[6k4k_photo=4k_pre_burst]` — “4K Pre-Burst”
      - `menu_item_id_6k4k_photo_prerec` — `title_6k4k_photo_prerec` `[on_off]` — “Pre-Burst Recording”
  - `menu_item_id_focus_select` — `title_focus_select` `[select]` — “Post-Focus”
    - `<group>`
      - `menu_item_id_focus_select_6k_18m` — `title_focus_select_6k_18m` `[focusselect=6k_18m]` — “6K 18M”
      - `menu_item_id_focus_select_6k_14m` — `title_focus_select_6k_14m` `[focusselect=6k_14m]` — “6K 14M”
      - `menu_item_id_focus_select_6k_15m` — `title_focus_select_6k_15m` `[focusselect=6k_15m]` — “6K 15M”
      - `menu_item_id_focus_select_4k_8m` — `title_focus_select_4k_8m` `[focusselect=4k_8m]` — “4K 8M”
      - `menu_item_id_focus_select_ex_4k_8m` — `title_focus_select_ex_4k_8m` `[focusselect=ex_4k_8m]` — “EX 4K 8M”
      - `menu_item_id_focus_select_off` — `title_focus_select_off` `[focusselect=off]` — “Off”
  - `menu_item_id_v_quality` — `title_v_quality` `[select]` — “Rec Quality”
    - `<group>`
      - `menu_item_id_v_quality_mp4_60p_100mbps_4k_10bit` — `title_v_quality_mp4_60p_100mbps_4k_10bit` `[videoquality=mp4_60p_100mbps_4k_10bit]` — “MP4 3840x2160 60p 100Mbps 10bit AAC”
      - `menu_item_id_v_quality_mp4_50p_100mbps_4k_10bit` — `title_v_quality_mp4_50p_100mbps_4k_10bit` `[videoquality=mp4_50p_100mbps_4k_10bit]` — “MP4 3840x2160 50p 100Mbps 10bit AAC”
      - `menu_item_id_v_quality_mp4_30p_100mbps_4k` — `title_v_quality_mp4_30p_100mbps_4k` `[videoquality=mp4_30p_100mbps_4k]` — “MP4 3840x2160 30p 100Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_25p_100mbps_4k` — `title_v_quality_mp4_25p_100mbps_4k` `[videoquality=mp4_25p_100mbps_4k]` — “MP4 3840x2160 25p 100Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_30p_72mbps_4k_10bit` — `title_v_quality_mp4_30p_72mbps_4k_10bit` `[videoquality=mp4_30p_72mbps_4k_10bit]` — “MP4 3840x2160 30p 72Mbps 10bit AAC”
      - `menu_item_id_v_quality_mp4_25p_72mbps_4k_10bit` — `title_v_quality_mp4_25p_72mbps_4k_10bit` `[videoquality=mp4_25p_72mbps_4k_10bit]` — “MP4 3840x2160 25p 72Mbps 10bit AAC”
      - `menu_item_id_v_quality_mp4_24p_100mbps_4k` — `title_v_quality_mp4_24p_100mbps_4k` `[videoquality=mp4_24p_100mbps_4k]` — “MP4 3840x2160 24p 100Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_24p_72mbps_4k_10bit` — `title_v_quality_mp4_24p_72mbps_4k_10bit` `[videoquality=mp4_24p_72mbps_4k_10bit]` — “MP4 3840x2160 24p 72Mbps 10bit AAC”
      - `menu_item_id_v_quality_mp4_60p_28mbps` — `title_v_quality_mp4_60p_28mbps` `[videoquality=mp4_60p_28mbps]` — “MP4 1920x1080 60p 28Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_50p_28mbps` — `title_v_quality_mp4_50p_28mbps` `[videoquality=mp4_50p_28mbps]` — “MP4 1920x1080 50p 28Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_30p_20mbps` — `title_v_quality_mp4_30p_20mbps` `[videoquality=mp4_30p_20mbps]` — “MP4 1920x1080 30p 20Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_25p_20mbps` — `title_v_quality_mp4_25p_20mbps` `[videoquality=mp4_25p_20mbps]` — “MP4 1920x1080 25p 20Mbps 8bit AAC”
      - `menu_item_id_v_quality_mp4_24p_24mbps` — `title_v_quality_mp4_24p_24mbps` `[videoquality=mp4_24p_24mbps]` — “MP4 1920x1080 24p 24Mbps 8bit AAC”
      - `menu_item_id_v_quality_mov_30p_200mbps_5_9k_10bit` — `title_v_quality_mov_30p_200mbps_5_9k_10bit` `[videoquality=mov_30p_200mbps_5_9k_10bit]` — “MOV 5888x3312 30p 200Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_25p_200mbps_5_9k_10bit` — `title_v_quality_mov_25p_200mbps_5_9k_10bit` `[videoquality=mov_25p_200mbps_5_9k_10bit]` — “MOV 5888x3312 25p 200Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_24p_200mbps_5_9k_10bit` — `title_v_quality_mov_24p_200mbps_5_9k_10bit` `[videoquality=mov_24p_200mbps_5_9k_10bit]` — “MOV 5888x3312 24p 200Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_60p_150mbps_c4k` — `title_v_quality_mov_60p_150mbps_c4k` `[videoquality=mov_60p_150mbps_c4k]` — “MOV 4096x2160 60p 150Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_50p_150mbps_c4k` — `title_v_quality_mov_50p_150mbps_c4k` `[videoquality=mov_50p_150mbps_c4k]` — “MOV 4096x2160 50p 150Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_30p_150mbps_c4k_10bit` — `title_v_quality_mov_30p_150mbps_c4k_10bit` `[videoquality=mov_30p_150mbps_c4k_10bit]` — “MOV 4096x2160 30p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_30p_100mbps_c4k` — `title_v_quality_mov_30p_100mbps_c4k` `[videoquality=mov_30p_100mbps_c4k]` — “MOV 4096x2160 30p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_25p_150mbps_c4k_10bit` — `title_v_quality_mov_25p_150mbps_c4k_10bit` `[videoquality=mov_25p_150mbps_c4k_10bit]` — “MOV 4096x2160 25p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_25p_100mbps_c4k` — `title_v_quality_mov_25p_100mbps_c4k` `[videoquality=mov_25p_100mbps_c4k]` — “MOV 4096x2160 25p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_24p_150mbps_c4k_10bit` — `title_v_quality_mov_24p_150mbps_c4k_10bit` `[videoquality=mov_24p_150mbps_c4k_10bit]` — “MOV 4096x2160 24p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_24p_100mbps_c4k` — `title_v_quality_mov_24p_100mbps_c4k` `[videoquality=mov_24p_100mbps_c4k]` — “MOV 4096x2160 24p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_60p_200mbps_4k_10bit` — `title_v_quality_mov_60p_200mbps_4k_10bit` `[videoquality=mov_60p_200mbps_4k_10bit]` — “MOV 3840x2160 60p 200Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_60p_150mbps_4k` — `title_v_quality_mov_60p_150mbps_4k` `[videoquality=mov_60p_150mbps_4k]` — “MOV 3840x2160 60p 150Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_50p_200mbps_4k_10bit` — `title_v_quality_mov_50p_200mbps_4k_10bit` `[videoquality=mov_50p_200mbps_4k_10bit]` — “MOV 3840x2160 50p 200Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_50p_150mbps_4k` — `title_v_quality_mov_50p_150mbps_4k` `[videoquality=mov_50p_150mbps_4k]` — “MOV 3840x2160 50p 150Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_30p_150mbps_4k_10bit` — `title_v_quality_mov_30p_150mbps_4k_10bit` `[videoquality=mov_30p_150mbps_4k_10bit]` — “MOV 3840x2160 30p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_30p_100mbps_4k` — `title_v_quality_mov_30p_100mbps_4k` `[videoquality=mov_30p_100mbps_4k]` — “MOV 3840x2160 30p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_25p_150mbps_4k_10bit` — `title_v_quality_mov_25p_150mbps_4k_10bit` `[videoquality=mov_25p_150mbps_4k_10bit]` — “MOV 3840x2160 25p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_25p_100mbps_4k` — `title_v_quality_mov_25p_100mbps_4k` `[videoquality=mov_25p_100mbps_4k]` — “MOV 3840x2160 25p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_24p_150mbps_4k_10bit` — `title_v_quality_mov_24p_150mbps_4k_10bit` `[videoquality=mov_24p_150mbps_4k_10bit]` — “MOV 3840x2160 24p 150Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_24p_100mbps_4k` — `title_v_quality_mov_24p_100mbps_4k` `[videoquality=mov_24p_100mbps_4k]` — “MOV 3840x2160 24p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_60p_100mbps_10bit` — `title_v_quality_mov_60p_100mbps_10bit` `[videoquality=mov_60p_100mbps_10bit]` — “MOV 1920x1080 60p 100Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_60p_100mbps` — `title_v_quality_mov_60p_100mbps` `[videoquality=mov_60p_100mbps]` — “MOV 1920x1080 60p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_50p_100mbps_10bit` — `title_v_quality_mov_50p_100mbps_10bit` `[videoquality=mov_50p_100mbps_10bit]` — “MOV 1920x1080 50p 100Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_50p_100mbps` — `title_v_quality_mov_50p_100mbps` `[videoquality=mov_50p_100mbps]` — “MOV 1920x1080 50p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_30p_100mbps_10bit` — `title_v_quality_mov_30p_100mbps_10bit` `[videoquality=mov_30p_100mbps_10bit]` — “MOV 1920x1080 30p 100Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_30p_100mbps` — `title_v_quality_mov_30p_100mbps` `[videoquality=mov_30p_100mbps]` — “MOV 1920x1080 30p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_25p_100mbps_10bit` — `title_v_quality_mov_25p_100mbps_10bit` `[videoquality=mov_25p_100mbps_10bit]` — “MOV 1920x1080 25p 100Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_25p_100mbps` — `title_v_quality_mov_25p_100mbps` `[videoquality=mov_25p_100mbps]` — “MOV 1920x1080 25p 100Mbps 8bit LPCM”
      - `menu_item_id_v_quality_mov_24p_100mbps_10bit` — `title_v_quality_mov_24p_100mbps_10bit` `[videoquality=mov_24p_100mbps_10bit]` — “MOV 1920x1080 24p 100Mbps 10bit LPCM”
      - `menu_item_id_v_quality_mov_24p_100mbps` — `title_v_quality_mov_24p_100mbps` `[videoquality=mov_24p_100mbps]` — “MOV 1920x1080 24p 100Mbps 8bit LPCM”
  - `menu_item_id_slow_quick_settings` — `title_slow_quick_settings` `[select]` — “Slow & Quick Setting”
    - `<group>`
      - `menu_item_id_slow_quick_1` — `title_slow_quick_1` `[slow_quick=1]` — “1fps”
      - `menu_item_id_slow_quick_2` — `title_slow_quick_2` `[slow_quick=2]` — “2fps”
      - `menu_item_id_slow_quick_5` — `title_slow_quick_5` `[slow_quick=5]` — “5fps”
      - `menu_item_id_slow_quick_10` — `title_slow_quick_10` `[slow_quick=10]` — “10fps”
      - `menu_item_id_slow_quick_15` — `title_slow_quick_15` `[slow_quick=15]` — “15fps”
      - `menu_item_id_slow_quick_30` — `title_slow_quick_30` `[slow_quick=30]` — “30fps”
      - `menu_item_id_slow_quick_60` — `title_slow_quick_60` `[slow_quick=60]` — “60fps”
      - `menu_item_id_slow_quick_100` — `title_slow_quick_100` `[slow_quick=100]` — “100fps”
      - `menu_item_id_slow_quick_120` — `title_slow_quick_120` `[slow_quick=120]` — “120fps”
      - `menu_item_id_slow_quick_150` — `title_slow_quick_150` `[slow_quick=150]` — “150fps”
      - `menu_item_id_slow_quick_180` — `title_slow_quick_180` `[slow_quick=180]` — “180fps”
  - `menu_item_id_ntsc_pal` — `title_ntsc_pal` `[select]` — “Switch NTSC/PAL”
    - `<group>`
      - `menu_item_id_ntsc_pal_ntsc` — `title_ntsc_pal_ntsc` `[ntsc_pal=ntsc]` — “NTSC”
      - `menu_item_id_ntsc_pal_pal` — `title_ntsc_pal_pal` `[ntsc_pal=pal]` — “PAL”
  - `menu_item_id_videoformat` — `title_videoformat` `[select]` — “Rec. File Format”
    - `<group>`
      - `menu_item_id_videoformat_mp4` — `title_videoformat_mp4` `[videoformat=mp4]` — “MP4”
      - `menu_item_id_videoformat_mp4hevc` — `title_videoformat_mp4hevc` `[videoformat=mp4hevc]` — “MP4 HEVC”
      - `menu_item_id_videoformat_mov` — `title_videoformat_mov` `[videoformat=mov]` — “MOV”
  - `menu_item_id_recmode` — `title_recmode` `[sp_embeded_recmode]` — “Rec Mode”
    - `<group>`
      - `menu_item_id_recmode_program_ae` — `title_recmode_program_ae` `[recmode=program_ae]` — “P”
      - `menu_item_id_recmode_aperture_ae` — `title_recmode_aperture_ae` `[recmode=aperture_ae]` — “A”
      - `menu_item_id_recmode_shutter_ae` — `title_recmode_shutter_ae` `[recmode=shutter_ae]` — “S”
      - `menu_item_id_recmode_manual_exposure` — `title_recmode_manual_exposure` `[recmode=manual_exposure]` — “M”
      - `menu_item_id_recmode_creative_movie` — `title_recmode_creative_movie` `[select]` — “Creative Video”
        - `<group>`
          - `menu_item_id_recmode_creative_movie_program_ae` — `title_recmode_creative_movie_program_ae` `[recmode=creative_movie/program_ae]` — “P”
          - `menu_item_id_recmode_creative_movie_aperture_ae` — `title_recmode_creative_movie_aperture_ae` `[recmode=creative_movie/aperture_ae]` — “A”
          - `menu_item_id_recmode_creative_movie_shutter_ae` — `title_recmode_creative_movie_shutter_ae` `[recmode=creative_movie/shutter_ae]` — “S”
          - `menu_item_id_recmode_creative_movie_manual_exposure` — `title_recmode_creative_movie_manual_exposure` `[recmode=creative_movie/manual_exposure]` — “M”
      - `menu_item_id_recmode_slow_quick` — `title_recmode_slow_quick` `[select]` — “Slow & Quick”
        - `<group>`
          - `menu_item_id_recmode_slow_quick_program_ae` — `title_recmode_slow_quick_program_ae` `[recmode=slow_quick/program_ae]` — “P”
          - `menu_item_id_recmode_slow_quick_aperture_ae` — `title_recmode_slow_quick_aperture_ae` `[recmode=slow_quick/aperture_ae]` — “A”
          - `menu_item_id_recmode_slow_quick_shutter_ae` — `title_recmode_slow_quick_shutter_ae` `[recmode=slow_quick/shutter_ae]` — “S”
          - `menu_item_id_recmode_slow_quick_manual_exposure` — `title_recmode_slow_quick_manual_exposure` `[recmode=slow_quick/manual_exposure]` — “M”
      - `menu_item_id_recmode_c1` — `title_recmode_c1` `[recmode=c1]` — “C1”
      - `menu_item_id_recmode_c2` — `title_recmode_c2` `[recmode=c2]` — “C2”
      - `menu_item_id_recmode_c3` — `title_recmode_c3` `[select]` — “C3”
        - `<group>`
          - `menu_item_id_recmode_c3_c3_1` — `title_recmode_c3_c3_1` `[recmode=c3/c3_1]` — “C3-1”
          - `menu_item_id_recmode_c3_c3_2` — `title_recmode_c3_c3_2` `[recmode=c3/c3_2]` — “C3-2”
          - `menu_item_id_recmode_c3_c3_3` — `title_recmode_c3_c3_3` `[recmode=c3/c3_3]` — “C3-3”
          - `menu_item_id_recmode_c3_c3_4` — `title_recmode_c3_c3_4` `[recmode=c3/c3_4]` — “C3-4”
          - `menu_item_id_recmode_c3_c3_5` — `title_recmode_c3_c3_5` `[recmode=c3/c3_5]` — “C3-5”
          - `menu_item_id_recmode_c3_c3_6` — `title_recmode_c3_c3_6` `[recmode=c3/c3_6]` — “C3-6”
          - `menu_item_id_recmode_c3_c3_7` — `title_recmode_c3_c3_7` `[recmode=c3/c3_7]` — “C3-7”
          - `menu_item_id_recmode_c3_c3_8` — `title_recmode_c3_c3_8` `[recmode=c3/c3_8]` — “C3-8”
          - `menu_item_id_recmode_c3_c3_9` — `title_recmode_c3_c3_9` `[recmode=c3/c3_9]` — “C3-9”
          - `menu_item_id_recmode_c3_c3_10` — `title_recmode_c3_c3_10` `[recmode=c3/c3_10]` — “C3-10”
      - `menu_item_id_recmode_ia` — `title_recmode_ia` `[recmode=ia]` — “iA”
  - `menu_item_id_self_shot` — `title_self_shot` `[sp_embeded_self_shot]` — “Self shot mode”

### `record_tab`

- `<menu>`
  - `menu_item_id_zoom` — `title_zoom` `[sp_embeded_zoom]` — “Zoom”
  - `menu_item_id_tch_shtr` — `title_tch_shtr` `[sp_embeded_tch_shtr]` — “Touch Shutter”
  - `menu_item_id_tch_ae` — `title_tch_ae` `[sp_embeded_tch_ae]` — “Touch AE”
  - `menu_item_id_peaking` — `title_peaking` `[sp_embeded_peaking]` — “Focus Peaking”
    - `<group>`
      - `menu_item_id_peaking_off` — `title_peaking_off` `[peaking=off]` — “Off”
      - `menu_item_id_peaking_on` — `title_peaking_on` `[peaking=on]` — “On”

### `record_tab2`

- `<menu>`
  - `menu_item_id_af_point_scope` — `title_af_point_scope` `[sp_embeded_af_point_scope]` — “AF-Point Scope”
  - `menu_item_id_overlay` — `title_overlay` `[sp_embeded_overlay]` — “Sheer Overlay”
    - `<group>`
      - `menu_item_id_overlay_off` — `title_overlay_off` `[overlay=off]` — “Off”
      - `menu_item_id_overlay_low` — `title_overlay_low` `[overlay=low]` — “Transparency L”
      - `menu_item_id_overlay_high` — `title_overlay_high` `[overlay=high]` — “Transparency H”

## 三、可设置命令表（按 cmd_type 分组）

> 这些叶子对应 HTTP 命令 `cam.cgi?mode=setsetting&type=<cmd_type>&value=<cmd_value>`。
> 带 `cmd_value2` 的项为二级选项：主值为 `cmd_value`，二级值为 `cmd_value2`（如 `drivemode` 的连拍档位、`photostyle` 的可调参数）。
> `cmd_value` 或 `cmd_value2` 为 `__value__` 表示该值不是固定枚举，而是由客户端在运行时传入（数值/开关等）；若存在 `min_val/max_val/step_val` 会在备注列给出。
> “父级”列给出离该叶子最近的带 `func_type` 的祖先 `<item>` 的 `title_id`。

### 1. `shtrspeed_angle`

- 选项数量：44
- 父级显示标题：`title_f_and_ss_angle`（`menu_item_id_f_and_ss_angle` — “F/SS(Angle)”）、`title_ss_angle`（`menu_item_id_ss_angle` — “SS(Angle)”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `11` | `` | `title_f_and_ss_angle_11` | 11° | `title_f_and_ss_angle` |  |
| 2 | `15` | `` | `title_f_and_ss_angle_15` | 15° | `title_f_and_ss_angle` |  |
| 3 | `23` | `` | `title_f_and_ss_angle_23` | 23° | `title_f_and_ss_angle` |  |
| 4 | `30` | `` | `title_f_and_ss_angle_30` | 30° | `title_f_and_ss_angle` |  |
| 5 | `45` | `` | `title_f_and_ss_angle_45` | 45° | `title_f_and_ss_angle` |  |
| 6 | `60` | `` | `title_f_and_ss_angle_60` | 60° | `title_f_and_ss_angle` |  |
| 7 | `72` | `` | `title_f_and_ss_angle_72` | 72° | `title_f_and_ss_angle` |  |
| 8 | `75` | `` | `title_f_and_ss_angle_75` | 75° | `title_f_and_ss_angle` |  |
| 9 | `86` | `` | `title_f_and_ss_angle_86` | 86° | `title_f_and_ss_angle` |  |
| 10 | `90` | `` | `title_f_and_ss_angle_90` | 90° | `title_f_and_ss_angle` |  |
| 11 | `108` | `` | `title_f_and_ss_angle_108` | 108° | `title_f_and_ss_angle` |  |
| 12 | `120` | `` | `title_f_and_ss_angle_120` | 120° | `title_f_and_ss_angle` |  |
| 13 | `144` | `` | `title_f_and_ss_angle_144` | 144° | `title_f_and_ss_angle` |  |
| 14 | `150` | `` | `title_f_and_ss_angle_150` | 150° | `title_f_and_ss_angle` |  |
| 15 | `172.8` | `` | `title_f_and_ss_angle_172.8` | 172.8° | `title_f_and_ss_angle` |  |
| 16 | `180` | `` | `title_f_and_ss_angle_180` | 180° | `title_f_and_ss_angle` |  |
| 17 | `216` | `` | `title_f_and_ss_angle_216` | 216° | `title_f_and_ss_angle` |  |
| 18 | `240` | `` | `title_f_and_ss_angle_240` | 240° | `title_f_and_ss_angle` |  |
| 19 | `288` | `` | `title_f_and_ss_angle_288` | 288° | `title_f_and_ss_angle` |  |
| 20 | `300` | `` | `title_f_and_ss_angle_300` | 300° | `title_f_and_ss_angle` |  |
| 21 | `346` | `` | `title_f_and_ss_angle_346` | 346° | `title_f_and_ss_angle` |  |
| 22 | `358` | `` | `title_f_and_ss_angle_358` | 358° | `title_f_and_ss_angle` |  |
| 23 | `11` | `` | `title_ss_angle_11` | 11° | `title_ss_angle` |  |
| 24 | `15` | `` | `title_ss_angle_15` | 15° | `title_ss_angle` |  |
| 25 | `23` | `` | `title_ss_angle_23` | 23° | `title_ss_angle` |  |
| 26 | `30` | `` | `title_ss_angle_30` | 30° | `title_ss_angle` |  |
| 27 | `45` | `` | `title_ss_angle_45` | 45° | `title_ss_angle` |  |
| 28 | `60` | `` | `title_ss_angle_60` | 60° | `title_ss_angle` |  |
| 29 | `72` | `` | `title_ss_angle_72` | 72° | `title_ss_angle` |  |
| 30 | `75` | `` | `title_ss_angle_75` | 75° | `title_ss_angle` |  |
| 31 | `86` | `` | `title_ss_angle_86` | 86° | `title_ss_angle` |  |
| 32 | `90` | `` | `title_ss_angle_90` | 90° | `title_ss_angle` |  |
| 33 | `108` | `` | `title_ss_angle_108` | 108° | `title_ss_angle` |  |
| 34 | `120` | `` | `title_ss_angle_120` | 120° | `title_ss_angle` |  |
| 35 | `144` | `` | `title_ss_angle_144` | 144° | `title_ss_angle` |  |
| 36 | `150` | `` | `title_ss_angle_150` | 150° | `title_ss_angle` |  |
| 37 | `172.8` | `` | `title_ss_angle_172.8` | 172.8° | `title_ss_angle` |  |
| 38 | `180` | `` | `title_ss_angle_180` | 180° | `title_ss_angle` |  |
| 39 | `216` | `` | `title_ss_angle_216` | 216° | `title_ss_angle` |  |
| 40 | `240` | `` | `title_ss_angle_240` | 240° | `title_ss_angle` |  |
| 41 | `288` | `` | `title_ss_angle_288` | 288° | `title_ss_angle` |  |
| 42 | `300` | `` | `title_ss_angle_300` | 300° | `title_ss_angle` |  |
| 43 | `346` | `` | `title_ss_angle_346` | 346° | `title_ss_angle` |  |
| 44 | `358` | `` | `title_ss_angle_358` | 358° | `title_ss_angle` |  |

### 2. `exposure`

- 选项数量：31
- 父级显示标题：`title_exposure3`（`menu_item_id_exposure3` — “Exposure Comp.”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `-5` | `` | `title_exposure_m5` | -5 | `title_exposure3` |  |
| 2 | `-14/3` | `` | `title_exposure_m14_3` | -4 2/3 | `title_exposure3` |  |
| 3 | `-13/3` | `` | `title_exposure_m13_3` | -4 1/3 | `title_exposure3` |  |
| 4 | `-4` | `` | `title_exposure_m4` | -4 | `title_exposure3` |  |
| 5 | `-11/3` | `` | `title_exposure_m11_3` | -3 2/3 | `title_exposure3` |  |
| 6 | `-10/3` | `` | `title_exposure_m10_3` | -3 1/3 | `title_exposure3` |  |
| 7 | `-3` | `` | `title_exposure_m3` | -3 | `title_exposure3` |  |
| 8 | `-8/3` | `` | `title_exposure_m8_3` | -2 2/3 | `title_exposure3` |  |
| 9 | `-7/3` | `` | `title_exposure_m7_3` | -2 1/3 | `title_exposure3` |  |
| 10 | `-2` | `` | `title_exposure_m2` | -2 | `title_exposure3` |  |
| 11 | `-5/3` | `` | `title_exposure_m5_3` | -1 2/3 | `title_exposure3` |  |
| 12 | `-4/3` | `` | `title_exposure_m4_3` | -1 1/3 | `title_exposure3` |  |
| 13 | `-1` | `` | `title_exposure_m1` | -1 | `title_exposure3` |  |
| 14 | `-2/3` | `` | `title_exposure_m2_3` | -2/3 | `title_exposure3` |  |
| 15 | `-1/3` | `` | `title_exposure_m1_3` | -1/3 | `title_exposure3` |  |
| 16 | `0` | `` | `title_exposure_0` | 0 | `title_exposure3` |  |
| 17 | `1/3` | `` | `title_exposure_p1_3` | +1/3 | `title_exposure3` |  |
| 18 | `2/3` | `` | `title_exposure_p2_3` | +2/3 | `title_exposure3` |  |
| 19 | `1` | `` | `title_exposure_p1` | +1 | `title_exposure3` |  |
| 20 | `4/3` | `` | `title_exposure_p4_3` | +1 1/3 | `title_exposure3` |  |
| 21 | `5/3` | `` | `title_exposure_p5_3` | +1 2/3 | `title_exposure3` |  |
| 22 | `2` | `` | `title_exposure_p2` | +2 | `title_exposure3` |  |
| 23 | `7/3` | `` | `title_exposure_p7_3` | +2 1/3 | `title_exposure3` |  |
| 24 | `8/3` | `` | `title_exposure_p8_3` | +2 2/3 | `title_exposure3` |  |
| 25 | `3` | `` | `title_exposure_p3` | +3 | `title_exposure3` |  |
| 26 | `10/3` | `` | `title_exposure_p10_3` | +3 1/3 | `title_exposure3` |  |
| 27 | `11/3` | `` | `title_exposure_p11_3` | +3 2/3 | `title_exposure3` |  |
| 28 | `4` | `` | `title_exposure_p12_3` | +4 | `title_exposure3` |  |
| 29 | `13/3` | `` | `title_exposure_p13_3` | +4 1/3 | `title_exposure3` |  |
| 30 | `14/3` | `` | `title_exposure_p14_3` | +4 2/3 | `title_exposure3` |  |
| 31 | `5` | `` | `title_exposure_p15_3` | +5 | `title_exposure3` |  |

### 3. `bracket`

- 选项数量：8
- 父级显示标题：`title_exposure3_step`（`menu_item_id_exposure3_step` — “Step”）、`title_bracket_type`（`menu_item_id_bracket_type` — “Bracketing Type”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `off` | `` | `title_exposure3_step_off` | Off | `title_exposure3_step` |  |
| 2 | `exposure` | `` | `title_bracket_exposure` | Exposure | `title_bracket_type` |  |
| 3 | `focal` | `` | `title_bracket_focal` | Aperture Value | `title_bracket_type` |  |
| 4 | `focus` | `` | `title_bracket_focus` | Focus | `title_bracket_type` |  |
| 5 | `wb` | `` | `title_bracket_wb` | WB (fine-tuning) | `title_bracket_type` |  |
| 6 | `wb_k` | `` | `title_bracket_wb_k` | WB (color temperature) | `title_bracket_type` |  |
| 7 | `aspect` | `` | `title_bracket_aspect` | Aspect Ratio | `title_bracket_type` |  |
| 8 | `off` | `` | `title_bracket_off` | Off | `title_bracket_type` |  |

### 4. `bracket_exposure_step`

- 选项数量：18
- 父级显示标题：`title_exposure3_step`（`menu_item_id_exposure3_step` — “Step”）、`title_bracket_exposure_step`（`menu_item_id_bracket_exposure_step` — “Step”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `3shot_1/3ev` | `` | `title_exposure3_step_3shot_1/3ev` | 3・1/3 | `title_exposure3_step` |  |
| 2 | `3shot_2/3ev` | `` | `title_exposure3_step_3shot_2/3ev` | 3・2/3 | `title_exposure3_step` |  |
| 3 | `3shot_1ev` | `` | `title_exposure3_step_3shot_1ev` | 3・1 | `title_exposure3_step` |  |
| 4 | `5shot_1/3ev` | `` | `title_exposure3_step_5shot_1/3ev` | 5・1/3 | `title_exposure3_step` |  |
| 5 | `5shot_2/3ev` | `` | `title_exposure3_step_5shot_2/3ev` | 5・2/3 | `title_exposure3_step` |  |
| 6 | `5shot_1ev` | `` | `title_exposure3_step_5shot_1ev` | 5・1 | `title_exposure3_step` |  |
| 7 | `7shot_1/3ev` | `` | `title_exposure3_step_7shot_1/3ev` | 7・1/3 | `title_exposure3_step` |  |
| 8 | `7shot_2/3ev` | `` | `title_exposure3_step_7shot_2/3ev` | 7・2/3 | `title_exposure3_step` |  |
| 9 | `7shot_1ev` | `` | `title_exposure3_step_7shot_1ev` | 7・1 | `title_exposure3_step` |  |
| 10 | `3shot_1/3ev` | `` | `title_bracket_exposure_step_3shot_1/3ev` | 3・1/3 | `title_bracket_exposure_step` |  |
| 11 | `3shot_2/3ev` | `` | `title_bracket_exposure_step_3shot_2/3ev` | 3・2/3 | `title_bracket_exposure_step` |  |
| 12 | `3shot_1ev` | `` | `title_bracket_exposure_step_3shot_1ev` | 3・1 | `title_bracket_exposure_step` |  |
| 13 | `5shot_1/3ev` | `` | `title_bracket_exposure_step_5shot_1/3ev` | 5・1/3 | `title_bracket_exposure_step` |  |
| 14 | `5shot_2/3ev` | `` | `title_bracket_exposure_step_5shot_2/3ev` | 5・2/3 | `title_bracket_exposure_step` |  |
| 15 | `5shot_1ev` | `` | `title_bracket_exposure_step_5shot_1ev` | 5・1 | `title_bracket_exposure_step` |  |
| 16 | `7shot_1/3ev` | `` | `title_bracket_exposure_step_7shot_1/3ev` | 7・1/3 | `title_bracket_exposure_step` |  |
| 17 | `7shot_2/3ev` | `` | `title_bracket_exposure_step_7shot_2/3ev` | 7・2/3 | `title_bracket_exposure_step` |  |
| 18 | `7shot_1ev` | `` | `title_bracket_exposure_step_7shot_1ev` | 7・1 | `title_bracket_exposure_step` |  |

### 5. `iso`

- 选项数量：44
- 父级显示标题：`title_sensitivity`（`menu_item_id_sensitivity` — “Sensitivity”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `auto` | `` | `title_sensitivity_auto` | AUTO | `title_sensitivity` |  |
| 2 | `50` | `` | `title_sensitivity_L50` | L.50 | `title_sensitivity` |  |
| 3 | `64` | `` | `title_sensitivity_L64` | L.64 | `title_sensitivity` |  |
| 4 | `80` | `` | `title_sensitivity_L80` | L.80 | `title_sensitivity` |  |
| 5 | `100` | `` | `title_sensitivity_100` | 100 | `title_sensitivity` |  |
| 6 | `100` | `` | `title_sensitivity_L100` | L.100 | `title_sensitivity` |  |
| 7 | `125` | `` | `title_sensitivity_125` | 125 | `title_sensitivity` |  |
| 8 | `125` | `` | `title_sensitivity_L125` | L.125 | `title_sensitivity` |  |
| 9 | `160` | `` | `title_sensitivity_160` | 160 | `title_sensitivity` |  |
| 10 | `160` | `` | `title_sensitivity_L160` | L.160 | `title_sensitivity` |  |
| 11 | `200` | `` | `title_sensitivity_200` | 200 | `title_sensitivity` |  |
| 12 | `250` | `` | `title_sensitivity_250` | 250 | `title_sensitivity` |  |
| 13 | `320` | `` | `title_sensitivity_320` | 320 | `title_sensitivity` |  |
| 14 | `320` | `` | `title_sensitivity_L320` | L.320 | `title_sensitivity` |  |
| 15 | `400` | `` | `title_sensitivity_400` | 400 | `title_sensitivity` |  |
| 16 | `400` | `` | `title_sensitivity_L400` | L.400 | `title_sensitivity` |  |
| 17 | `500` | `` | `title_sensitivity_500` | 500 | `title_sensitivity` |  |
| 18 | `500` | `` | `title_sensitivity_L500` | L.500 | `title_sensitivity` |  |
| 19 | `640` | `` | `title_sensitivity_640` | 640 | `title_sensitivity` |  |
| 20 | `800` | `` | `title_sensitivity_800` | 800 | `title_sensitivity` |  |
| 21 | `1000` | `` | `title_sensitivity_1000` | 1000 | `title_sensitivity` |  |
| 22 | `1250` | `` | `title_sensitivity_1250` | 1250 | `title_sensitivity` |  |
| 23 | `1600` | `` | `title_sensitivity_1600` | 1600 | `title_sensitivity` |  |
| 24 | `2000` | `` | `title_sensitivity_2000` | 2000 | `title_sensitivity` |  |
| 25 | `2500` | `` | `title_sensitivity_2500` | 2500 | `title_sensitivity` |  |
| 26 | `3200` | `` | `title_sensitivity_3200` | 3200 | `title_sensitivity` |  |
| 27 | `4000` | `` | `title_sensitivity_4000` | 4000 | `title_sensitivity` |  |
| 28 | `5000` | `` | `title_sensitivity_5000` | 5000 | `title_sensitivity` |  |
| 29 | `6400` | `` | `title_sensitivity_6400` | 6400 | `title_sensitivity` |  |
| 30 | `8000` | `` | `title_sensitivity_8000` | 8000 | `title_sensitivity` |  |
| 31 | `10000` | `` | `title_sensitivity_10000` | 10000 | `title_sensitivity` |  |
| 32 | `12800` | `` | `title_sensitivity_12800` | 12800 | `title_sensitivity` |  |
| 33 | `16000` | `` | `title_sensitivity_16000` | 16000 | `title_sensitivity` |  |
| 34 | `20000` | `` | `title_sensitivity_20000` | 20000 | `title_sensitivity` |  |
| 35 | `25600` | `` | `title_sensitivity_25600` | 25600 | `title_sensitivity` |  |
| 36 | `32000` | `` | `title_sensitivity_32000` | 32000 | `title_sensitivity` |  |
| 37 | `40000` | `` | `title_sensitivity_40000` | 40000 | `title_sensitivity` |  |
| 38 | `51200` | `` | `title_sensitivity_51200` | 51200 | `title_sensitivity` |  |
| 39 | `64000` | `` | `title_sensitivity_H64000` | H.64000 | `title_sensitivity` |  |
| 40 | `80000` | `` | `title_sensitivity_H80000` | H.80000 | `title_sensitivity` |  |
| 41 | `102400` | `` | `title_sensitivity_H102400` | H.102400 | `title_sensitivity` |  |
| 42 | `128000` | `` | `title_sensitivity_H128000` | H.128000 | `title_sensitivity` |  |
| 43 | `160000` | `` | `title_sensitivity_H160000` | H.160000 | `title_sensitivity` |  |
| 44 | `204800` | `` | `title_sensitivity_H204800` | H.204800 | `title_sensitivity` |  |

### 6. `sensitivity_db`

- 选项数量：44
- 父级显示标题：`title_sensitivity_db`（`menu_item_id_sensitivity_db` — “dB”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `auto` | `` | `title_sensitivity_db_auto` | AUTO | `title_sensitivity_db` |  |
| 2 | `-6` | `` | `title_sensitivity_db_Lm6` | L.-6dB | `title_sensitivity_db` |  |
| 3 | `-4` | `` | `title_sensitivity_db_Lm4` | L.-4dB | `title_sensitivity_db` |  |
| 4 | `-2` | `` | `title_sensitivity_db_Lm2` | L.-2dB | `title_sensitivity_db` |  |
| 5 | `0` | `` | `title_sensitivity_db_0` | 0dB | `title_sensitivity_db` |  |
| 6 | `2` | `` | `title_sensitivity_db_2` | 2dB | `title_sensitivity_db` |  |
| 7 | `4` | `` | `title_sensitivity_db_4` | 4dB | `title_sensitivity_db` |  |
| 8 | `6` | `` | `title_sensitivity_db_6` | 6dB | `title_sensitivity_db` |  |
| 9 | `8` | `` | `title_sensitivity_db_8` | 8dB | `title_sensitivity_db` |  |
| 10 | `10` | `` | `title_sensitivity_db_10` | 10dB | `title_sensitivity_db` |  |
| 11 | `12` | `` | `title_sensitivity_db_12` | 12dB | `title_sensitivity_db` |  |
| 12 | `14` | `` | `title_sensitivity_db_14` | 14dB | `title_sensitivity_db` |  |
| 13 | `16` | `` | `title_sensitivity_db_16` | 16dB | `title_sensitivity_db` |  |
| 14 | `18` | `` | `title_sensitivity_db_18` | 18dB | `title_sensitivity_db` |  |
| 15 | `20` | `` | `title_sensitivity_db_20` | 20dB | `title_sensitivity_db` |  |
| 16 | `22` | `` | `title_sensitivity_db_22` | 22dB | `title_sensitivity_db` |  |
| 17 | `24` | `` | `title_sensitivity_db_24` | 24dB | `title_sensitivity_db` |  |
| 18 | `26` | `` | `title_sensitivity_db_26` | 26dB | `title_sensitivity_db` |  |
| 19 | `28` | `` | `title_sensitivity_db_28` | 28dB | `title_sensitivity_db` |  |
| 20 | `30` | `` | `title_sensitivity_db_30` | 30dB | `title_sensitivity_db` |  |
| 21 | `32` | `` | `title_sensitivity_db_32` | 32dB | `title_sensitivity_db` |  |
| 22 | `34` | `` | `title_sensitivity_db_34` | 34dB | `title_sensitivity_db` |  |
| 23 | `36` | `` | `title_sensitivity_db_36` | 36dB | `title_sensitivity_db` |  |
| 24 | `38` | `` | `title_sensitivity_db_38` | 38dB | `title_sensitivity_db` |  |
| 25 | `40` | `` | `title_sensitivity_db_40` | 40dB | `title_sensitivity_db` |  |
| 26 | `42` | `` | `title_sensitivity_db_42` | 42dB | `title_sensitivity_db` |  |
| 27 | `44` | `` | `title_sensitivity_db_44` | 44dB | `title_sensitivity_db` |  |
| 28 | `44` | `` | `title_sensitivity_db_H44` | H.44dB | `title_sensitivity_db` |  |
| 29 | `46` | `` | `title_sensitivity_db_46` | 46dB | `title_sensitivity_db` |  |
| 30 | `46` | `` | `title_sensitivity_db_H46` | H.46dB | `title_sensitivity_db` |  |
| 31 | `48` | `` | `title_sensitivity_db_48` | 48dB | `title_sensitivity_db` |  |
| 32 | `48` | `` | `title_sensitivity_db_H48` | H.48dB | `title_sensitivity_db` |  |
| 33 | `50` | `` | `title_sensitivity_db_50` | 50dB | `title_sensitivity_db` |  |
| 34 | `50` | `` | `title_sensitivity_db_H50` | H.50dB | `title_sensitivity_db` |  |
| 35 | `52` | `` | `title_sensitivity_db_52` | 52dB | `title_sensitivity_db` |  |
| 36 | `52` | `` | `title_sensitivity_db_H52` | H.52dB | `title_sensitivity_db` |  |
| 37 | `54` | `` | `title_sensitivity_db_54` | 54dB | `title_sensitivity_db` |  |
| 38 | `54` | `` | `title_sensitivity_db_H54` | H.54dB | `title_sensitivity_db` |  |
| 39 | `56` | `` | `title_sensitivity_db_H56` | H.56dB | `title_sensitivity_db` |  |
| 40 | `58` | `` | `title_sensitivity_db_H58` | H.58dB | `title_sensitivity_db` |  |
| 41 | `60` | `` | `title_sensitivity_db_H60` | H.60dB | `title_sensitivity_db` |  |
| 42 | `62` | `` | `title_sensitivity_db_H62` | H.62dB | `title_sensitivity_db` |  |
| 43 | `64` | `` | `title_sensitivity_db_H64` | H.64dB | `title_sensitivity_db` |  |
| 44 | `66` | `` | `title_sensitivity_db_H66` | H.66dB | `title_sensitivity_db` |  |

### 7. `whitebalance`

- 选项数量：32
- 父级显示标题：`title_whitebalance`（`menu_item_id_whitebalance` — “White Balance”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `auto` | `` | `title_whitebalance_auto` | Auto White Balance | `title_whitebalance` |  |
| 2 | `auto_cool` | `` | `title_whitebalance_auto_cool` | AWB(Cool) | `title_whitebalance` |  |
| 3 | `auto_warm` | `` | `title_whitebalance_auto_warm` | AWB(Warm) | `title_whitebalance` |  |
| 4 | `daylight` | `` | `title_whitebalance_daylight` | Daylight | `title_whitebalance` |  |
| 5 | `cloudy` | `` | `title_whitebalance_cloudy` | Cloudy | `title_whitebalance` |  |
| 6 | `shade` | `` | `title_whitebalance_shade` | Shade | `title_whitebalance` |  |
| 7 | `halogen` | `` | `title_whitebalance_halogen` | Incandescent | `title_whitebalance` |  |
| 8 | `flash` | `` | `title_whitebalance_flash` | Flash | `title_whitebalance` |  |
| 9 | `white_set1` | `` | `title_whitebalance_white_set1` | White Set 1 | `title_whitebalance` |  |
| 10 | `white_set2` | `` | `title_whitebalance_white_set2` | White Set 2 | `title_whitebalance` |  |
| 11 | `white_set3` | `` | `title_whitebalance_white_set3` | White Set 3 | `title_whitebalance` |  |
| 12 | `white_set4` | `` | `title_whitebalance_white_set4` | White Set 4 | `title_whitebalance` |  |
| 13 | `color_temp1` | `__value__` | `title_whitebalance_color_temp1` | Color Temperature 1 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 14 | `color_temp2` | `__value__` | `title_whitebalance_color_temp2` | Color Temperature 2 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 15 | `color_temp3` | `__value__` | `title_whitebalance_color_temp3` | Color Temperature 3 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 16 | `color_temp4` | `__value__` | `title_whitebalance_color_temp4` | Color Temperature 4 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 17 | `auto` | `` | `title_whitebalance_auto` | Auto White Balance | `title_whitebalance` |  |
| 18 | `auto_cool` | `` | `title_whitebalance_auto_cool` | AWB(Cool) | `title_whitebalance` |  |
| 19 | `auto_warm` | `` | `title_whitebalance_auto_warm` | AWB(Warm) | `title_whitebalance` |  |
| 20 | `daylight` | `` | `title_whitebalance_daylight` | Daylight | `title_whitebalance` |  |
| 21 | `cloudy` | `` | `title_whitebalance_cloudy` | Cloudy | `title_whitebalance` |  |
| 22 | `shade` | `` | `title_whitebalance_shade` | Shade | `title_whitebalance` |  |
| 23 | `halogen` | `` | `title_whitebalance_halogen` | Incandescent | `title_whitebalance` |  |
| 24 | `flash` | `` | `title_whitebalance_flash` | Flash | `title_whitebalance` |  |
| 25 | `white_set1` | `` | `title_whitebalance_white_set1` | White Set 1 | `title_whitebalance` |  |
| 26 | `white_set2` | `` | `title_whitebalance_white_set2` | White Set 2 | `title_whitebalance` |  |
| 27 | `white_set3` | `` | `title_whitebalance_white_set3` | White Set 3 | `title_whitebalance` |  |
| 28 | `white_set4` | `` | `title_whitebalance_white_set4` | White Set 4 | `title_whitebalance` |  |
| 29 | `color_temp1` | `__value__` | `title_whitebalance_color_temp1` | Color Temperature 1 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 30 | `color_temp2` | `__value__` | `title_whitebalance_color_temp2` | Color Temperature 2 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 31 | `color_temp3` | `__value__` | `title_whitebalance_color_temp3` | Color Temperature 3 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |
| 32 | `color_temp4` | `__value__` | `title_whitebalance_color_temp4` | Color Temperature 4 | `title_whitebalance` | value2=动态值；min=2500 max=10000 step=100 |

### 8. `photostyle`

- 选项数量：74
- 父级显示标题：`title_ph_sty`（`menu_item_id_ph_sty` — “Photo Style”）、`title_ph_sty`（`menu_item_id_ph_sty_customs` — “Photo Style”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `standard` | `__value__` | `title_ph_sty_standard` | Standard | `title_ph_sty` | value2=动态值 |
| 2 | `vivid` | `__value__` | `title_ph_sty_vivid` | Vivid | `title_ph_sty` | value2=动态值 |
| 3 | `natural` | `__value__` | `title_ph_sty_natural` | Natural | `title_ph_sty` | value2=动态值 |
| 4 | `l_cla_neo` | `__value__` | `title_ph_sty_l_cla_neo` | L.ClassicNeo | `title_ph_sty` | value2=动态值 |
| 5 | `flat` | `__value__` | `title_ph_sty_flat` | Flat | `title_ph_sty` | value2=动态值 |
| 6 | `scenery` | `__value__` | `title_ph_sty_scenery` | Landscape | `title_ph_sty` | value2=动态值 |
| 7 | `portrait` | `__value__` | `title_ph_sty_portrait` | Portrait | `title_ph_sty` | value2=动态值 |
| 8 | `bw` | `__value__` | `title_ph_sty_bw` | Monochrome | `title_ph_sty` | value2=动态值 |
| 9 | `l_bw` | `__value__` | `title_ph_sty_l_bw` | L.Monochrome | `title_ph_sty` | value2=动态值 |
| 10 | `l_bw_d` | `__value__` | `title_ph_sty_l_bw_d` | L.Monochrome D | `title_ph_sty` | value2=动态值 |
| 11 | `l_bw_s` | `__value__` | `title_ph_sty_l_bw_s` | L.Monochrome S | `title_ph_sty` | value2=动态值 |
| 12 | `cinelike_d2` | `__value__` | `title_ph_sty_cinelike_d2` | Cinelike D2 | `title_ph_sty` | value2=动态值 |
| 13 | `cinelike_v2` | `__value__` | `title_ph_sty_cinelike_v2` | Cinelike V2 | `title_ph_sty` | value2=动态值 |
| 14 | `709like` | `__value__` | `title_ph_sty_709like` | Like709 | `title_ph_sty` | value2=动态值 |
| 15 | `vlog` | `__value__` | `title_ph_sty_vlog` | V-Log | `title_ph_sty` | value2=动态值 |
| 16 | `hlg_standard` | `__value__` | `title_ph_sty_hlg_standard` | Standard(HLG) | `title_ph_sty` | value2=动态值 |
| 17 | `hlg_bw` | `__value__` | `title_ph_sty_hlg_bw` | Monochrome(HLG) | `title_ph_sty` | value2=动态值 |
| 18 | `hlg` | `__value__` | `title_ph_sty_hlg` | Like2100(HLG) | `title_ph_sty` | value2=动态值 |
| 19 | `custom1` | `__value__` | `title_ph_sty_custom1` | MY PHOTO STYLE 1 | `title_ph_sty` | value2=动态值 |
| 20 | `custom2` | `__value__` | `title_ph_sty_custom2` | MY PHOTO STYLE 2 | `title_ph_sty` | value2=动态值 |
| 21 | `custom3` | `__value__` | `title_ph_sty_custom3` | MY PHOTO STYLE 3 | `title_ph_sty` | value2=动态值 |
| 22 | `custom4` | `__value__` | `title_ph_sty_custom4` | MY PHOTO STYLE 4 | `title_ph_sty` | value2=动态值 |
| 23 | `custom5` | `__value__` | `title_ph_sty_custom5` | MY PHOTO STYLE 5 | `title_ph_sty` | value2=动态值 |
| 24 | `custom6` | `__value__` | `title_ph_sty_custom6` | MY PHOTO STYLE 6 | `title_ph_sty` | value2=动态值 |
| 25 | `custom7` | `__value__` | `title_ph_sty_custom7` | MY PHOTO STYLE 7 | `title_ph_sty` | value2=动态值 |
| 26 | `custom8` | `__value__` | `title_ph_sty_custom8` | MY PHOTO STYLE 8 | `title_ph_sty` | value2=动态值 |
| 27 | `custom9` | `__value__` | `title_ph_sty_custom9` | MY PHOTO STYLE 9 | `title_ph_sty` | value2=动态值 |
| 28 | `custom10` | `__value__` | `title_ph_sty_custom10` | MY PHOTO STYLE 10 | `title_ph_sty` | value2=动态值 |
| 29 | `standard` | `__value__` | `title_ph_sty_standard` | Standard | `title_ph_sty` | value2=动态值 |
| 30 | `vivid` | `__value__` | `title_ph_sty_vivid` | Vivid | `title_ph_sty` | value2=动态值 |
| 31 | `natural` | `__value__` | `title_ph_sty_natural` | Natural | `title_ph_sty` | value2=动态值 |
| 32 | `l_cla_neo` | `__value__` | `title_ph_sty_l_cla_neo` | L.ClassicNeo | `title_ph_sty` | value2=动态值 |
| 33 | `flat` | `__value__` | `title_ph_sty_flat` | Flat | `title_ph_sty` | value2=动态值 |
| 34 | `scenery` | `__value__` | `title_ph_sty_scenery` | Landscape | `title_ph_sty` | value2=动态值 |
| 35 | `portrait` | `__value__` | `title_ph_sty_portrait` | Portrait | `title_ph_sty` | value2=动态值 |
| 36 | `bw` | `__value__` | `title_ph_sty_bw` | Monochrome | `title_ph_sty` | value2=动态值 |
| 37 | `l_bw` | `__value__` | `title_ph_sty_l_bw` | L.Monochrome | `title_ph_sty` | value2=动态值 |
| 38 | `l_bw_d` | `__value__` | `title_ph_sty_l_bw_d` | L.Monochrome D | `title_ph_sty` | value2=动态值 |
| 39 | `l_bw_s` | `__value__` | `title_ph_sty_l_bw_s` | L.Monochrome S | `title_ph_sty` | value2=动态值 |
| 40 | `cinelike_d2` | `__value__` | `title_ph_sty_cinelike_d2` | Cinelike D2 | `title_ph_sty` | value2=动态值 |
| 41 | `cinelike_v2` | `__value__` | `title_ph_sty_cinelike_v2` | Cinelike V2 | `title_ph_sty` | value2=动态值 |
| 42 | `709like` | `__value__` | `title_ph_sty_709like` | Like709 | `title_ph_sty` | value2=动态值 |
| 43 | `vlog` | `__value__` | `title_ph_sty_vlog` | V-Log | `title_ph_sty` | value2=动态值 |
| 44 | `hlg_standard` | `__value__` | `title_ph_sty_hlg_standard` | Standard(HLG) | `title_ph_sty` | value2=动态值 |
| 45 | `hlg_bw` | `__value__` | `title_ph_sty_hlg_bw` | Monochrome(HLG) | `title_ph_sty` | value2=动态值 |
| 46 | `hlg` | `__value__` | `title_ph_sty_hlg` | Like2100(HLG) | `title_ph_sty` | value2=动态值 |
| 47 | `custom1` | `__value__` | `title_ph_sty_custom1` | MY PHOTO STYLE 1 | `title_ph_sty` | value2=动态值 |
| 48 | `custom2` | `__value__` | `title_ph_sty_custom2` | MY PHOTO STYLE 2 | `title_ph_sty` | value2=动态值 |
| 49 | `custom3` | `__value__` | `title_ph_sty_custom3` | MY PHOTO STYLE 3 | `title_ph_sty` | value2=动态值 |
| 50 | `custom4` | `__value__` | `title_ph_sty_custom4` | MY PHOTO STYLE 4 | `title_ph_sty` | value2=动态值 |
| 51 | `custom5` | `__value__` | `title_ph_sty_custom5` | MY PHOTO STYLE 5 | `title_ph_sty` | value2=动态值 |
| 52 | `custom6` | `__value__` | `title_ph_sty_custom6` | MY PHOTO STYLE 6 | `title_ph_sty` | value2=动态值 |
| 53 | `custom7` | `__value__` | `title_ph_sty_custom7` | MY PHOTO STYLE 7 | `title_ph_sty` | value2=动态值 |
| 54 | `custom8` | `__value__` | `title_ph_sty_custom8` | MY PHOTO STYLE 8 | `title_ph_sty` | value2=动态值 |
| 55 | `custom9` | `__value__` | `title_ph_sty_custom9` | MY PHOTO STYLE 9 | `title_ph_sty` | value2=动态值 |
| 56 | `custom10` | `__value__` | `title_ph_sty_custom10` | MY PHOTO STYLE 10 | `title_ph_sty` | value2=动态值 |
| 57 | `__value__` | `standard` | `title_ph_sty_standard` | Standard | `title_ph_sty` | value=动态值 |
| 58 | `__value__` | `vivid` | `title_ph_sty_vivid` | Vivid | `title_ph_sty` | value=动态值 |
| 59 | `__value__` | `natural` | `title_ph_sty_natural` | Natural | `title_ph_sty` | value=动态值 |
| 60 | `__value__` | `l_cla_neo` | `title_ph_sty_l_cla_neo` | L.ClassicNeo | `title_ph_sty` | value=动态值 |
| 61 | `__value__` | `flat` | `title_ph_sty_flat` | Flat | `title_ph_sty` | value=动态值 |
| 62 | `__value__` | `scenery` | `title_ph_sty_scenery` | Landscape | `title_ph_sty` | value=动态值 |
| 63 | `__value__` | `portrait` | `title_ph_sty_portrait` | Portrait | `title_ph_sty` | value=动态值 |
| 64 | `__value__` | `bw` | `title_ph_sty_bw` | Monochrome | `title_ph_sty` | value=动态值 |
| 65 | `__value__` | `l_bw` | `title_ph_sty_l_bw` | L.Monochrome | `title_ph_sty` | value=动态值 |
| 66 | `__value__` | `l_bw_d` | `title_ph_sty_l_bw_d` | L.Monochrome D | `title_ph_sty` | value=动态值 |
| 67 | `__value__` | `l_bw_s` | `title_ph_sty_l_bw_s` | L.Monochrome S | `title_ph_sty` | value=动态值 |
| 68 | `__value__` | `cinelike_d2` | `title_ph_sty_cinelike_d2` | Cinelike D2 | `title_ph_sty` | value=动态值 |
| 69 | `__value__` | `cinelike_v2` | `title_ph_sty_cinelike_v2` | Cinelike V2 | `title_ph_sty` | value=动态值 |
| 70 | `__value__` | `709like` | `title_ph_sty_709like` | Like709 | `title_ph_sty` | value=动态值 |
| 71 | `__value__` | `vlog` | `title_ph_sty_vlog` | V-Log | `title_ph_sty` | value=动态值 |
| 72 | `__value__` | `hlg_standard` | `title_ph_sty_hlg_standard` | Standard(HLG) | `title_ph_sty` | value=动态值 |
| 73 | `__value__` | `hlg_bw` | `title_ph_sty_hlg_bw` | Monochrome(HLG) | `title_ph_sty` | value=动态值 |
| 74 | `__value__` | `hlg` | `title_ph_sty_hlg` | Like2100(HLG) | `title_ph_sty` | value=动态值 |

### 9. `drivemode`

- 选项数量：37
- 父级显示标题：顶层 `<menu>`（无带 `func_type` 的父级）、`title_burst_speed_1`（`menu_item_id_burst_1` — “Burst Shot 1 Setting”）、`title_burst_speed_2`（`menu_item_id_burst_2` — “Burst Shot 2 Setting”）、`title_selftimer`（`menu_item_id_selftimer` — “Self Timer”）、`title_drivemode`（`menu_item_id_drivemode` — “Drive Mode”）、`title_stopmotion_interval_shoot_type`（`menu_item_id_stopmotion_interval_shoot_type` — “Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `normal` | `` | `title_1shoot` | Single | `` |  |
| 2 | `burst_1` | `` | `title_burst_speed_1` | Burst Shot 1 Setting | `` |  |
| 3 | `burst_1` | `6k4k_photo` | `title_burst_6k4k_photo` | 6K/4K PHOTO | `title_burst_speed_1` |  |
| 4 | `burst_1` | `h` | `title_burst_h` | H | `title_burst_speed_1` |  |
| 5 | `burst_1` | `m` | `title_burst_m` | M | `title_burst_speed_1` |  |
| 6 | `burst_1` | `l` | `title_burst_l` | L | `title_burst_speed_1` |  |
| 7 | `burst_2` | `` | `title_burst_speed_2` | Burst Shot 2 Setting | `` |  |
| 8 | `burst_2` | `6k4k_photo` | `title_burst_6k4k_photo` | 6K/4K PHOTO | `title_burst_speed_2` |  |
| 9 | `burst_2` | `h` | `title_burst_h` | H | `title_burst_speed_2` |  |
| 10 | `burst_2` | `m` | `title_burst_m` | M | `title_burst_speed_2` |  |
| 11 | `burst_2` | `l` | `title_burst_l` | L | `title_burst_speed_2` |  |
| 12 | `stopmotion_interval` | `` | `title_stopmotion_interval` | Time Lapse/Animation | `` |  |
| 13 | `selftimer` | `` | `title_selftimer` | Self Timer | `` |  |
| 14 | `selftimer` | `10sec` | `title_selftimer_10sec` | 10sec. | `title_selftimer` |  |
| 15 | `selftimer` | `10sec3shot` | `title_selftimer_10sec3shot` | 10s / 3pictures | `title_selftimer` |  |
| 16 | `selftimer` | `2sec` | `title_selftimer_2sec` | 2sec. | `title_selftimer` |  |
| 17 | `normal` | `` | `title_drivemode_1shoot` | Single | `title_drivemode` |  |
| 18 | `burst_1` | `` | `title_drivemode_burst_1` | Burst Shot 1 | `title_drivemode` |  |
| 19 | `burst_2` | `` | `title_drivemode_burst_2` | Burst Shot 2 | `title_drivemode` |  |
| 20 | `stopmotion_interval` | `` | `title_drivemode_stopmotion_interval` | Time Lapse/Animation | `title_drivemode` |  |
| 21 | `selftimer` | `` | `title_drivemode_selftimer` | Self Timer | `title_drivemode` |  |
| 22 | `burst_1` | `` | `title_burst_speed_1` | Burst Shot 1 Setting | `` |  |
| 23 | `burst_1` | `6k4k_photo` | `title_burst_6k4k_photo` | 6K/4K PHOTO | `title_burst_speed_1` |  |
| 24 | `burst_1` | `h` | `title_burst_h` | H | `title_burst_speed_1` |  |
| 25 | `burst_1` | `m` | `title_burst_m` | M | `title_burst_speed_1` |  |
| 26 | `burst_1` | `l` | `title_burst_l` | L | `title_burst_speed_1` |  |
| 27 | `burst_2` | `` | `title_burst_speed_2` | Burst Shot 2 Setting | `` |  |
| 28 | `burst_2` | `6k4k_photo` | `title_burst_6k4k_photo` | 6K/4K PHOTO | `title_burst_speed_2` |  |
| 29 | `burst_2` | `h` | `title_burst_h` | H | `title_burst_speed_2` |  |
| 30 | `burst_2` | `m` | `title_burst_m` | M | `title_burst_speed_2` |  |
| 31 | `burst_2` | `l` | `title_burst_l` | L | `title_burst_speed_2` |  |
| 32 | `stopmotion_interval` | `interval` | `title_stopmotion_interval_interval` | Time Lapse Shot | `title_stopmotion_interval_shoot_type` |  |
| 33 | `stopmotion_interval` | `stop_motion` | `title_stopmotion_interval_stop_motion` | Animation | `title_stopmotion_interval_shoot_type` |  |
| 34 | `selftimer` | `` | `title_selftimer` | Self Timer | `` |  |
| 35 | `selftimer` | `10sec` | `title_selftimer_10sec` | 10sec. | `title_selftimer` |  |
| 36 | `selftimer` | `10sec3shot` | `title_selftimer_10sec3shot` | 10s / 3pictures | `title_selftimer` |  |
| 37 | `selftimer` | `2sec` | `title_selftimer_2sec` | 2sec. | `title_selftimer` |  |

### 10. `aspectratio`

- 选项数量：12
- 父级显示标题：`title_asprat`（`menu_item_id_asprat` — “Aspect Ratio”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `4:3` | `` | `title_asprat_4:3` | 4:3 | `title_asprat` |  |
| 2 | `3:2` | `` | `title_asprat_3:2` | 3:2 | `title_asprat` |  |
| 3 | `16:9` | `` | `title_asprat_16:9` | 16:9 | `title_asprat` |  |
| 4 | `1:1` | `` | `title_asprat_1:1` | 1:1 | `title_asprat` |  |
| 5 | `65:24` | `` | `title_asprat_65:24` | 65:24 | `title_asprat` |  |
| 6 | `2:1` | `` | `title_asprat_2:1` | 2:1 | `title_asprat` |  |
| 7 | `4:3` | `` | `title_asprat_4:3` | 4:3 | `title_asprat` |  |
| 8 | `3:2` | `` | `title_asprat_3:2` | 3:2 | `title_asprat` |  |
| 9 | `16:9` | `` | `title_asprat_16:9` | 16:9 | `title_asprat` |  |
| 10 | `1:1` | `` | `title_asprat_1:1` | 1:1 | `title_asprat` |  |
| 11 | `65:24` | `` | `title_asprat_65:24` | 65:24 | `title_asprat` |  |
| 12 | `2:1` | `` | `title_asprat_2:1` | 2:1 | `title_asprat` |  |

### 11. `lightmetering`

- 选项数量：8
- 父级显示标题：`title_lightmet`（`menu_item_id_lightmet` — “Metering Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `multi` | `` | `title_lightmet_multi` | Multi Metering | `title_lightmet` |  |
| 2 | `center` | `` | `title_lightmet_center` | Center Weighted | `title_lightmet` |  |
| 3 | `spot` | `` | `title_lightmet_spot` | Spot | `title_lightmet` |  |
| 4 | `highlight` | `` | `title_lightmet_highlight` | Highlight Weighted | `title_lightmet` |  |
| 5 | `multi` | `` | `title_lightmet_multi` | Multi Metering | `title_lightmet` |  |
| 6 | `center` | `` | `title_lightmet_center` | Center Weighted | `title_lightmet` |  |
| 7 | `spot` | `` | `title_lightmet_spot` | Spot | `title_lightmet` |  |
| 8 | `highlight` | `` | `title_lightmet_highlight` | Highlight Weighted | `title_lightmet` |  |

### 12. `videoquality`

- 选项数量：88
- 父级显示标题：`title_v_quality_qmenu`（`menu_item_id_v_quality` — “Motion Pic. Rec Quality”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `mp4_60p_100mbps_4k_10bit` | `` | `title_v_quality_mp4_60p_100mbps_4k_10bit_q` | 3840x2160,60p | `title_v_quality_qmenu` |  |
| 2 | `mp4_50p_100mbps_4k_10bit` | `` | `title_v_quality_mp4_50p_100mbps_4k_10bit_q` | 3840x2160,50p | `title_v_quality_qmenu` |  |
| 3 | `mp4_30p_100mbps_4k` | `` | `title_v_quality_mp4_30p_100mbps_4k_q` | 3840x2160,30p | `title_v_quality_qmenu` |  |
| 4 | `mp4_25p_100mbps_4k` | `` | `title_v_quality_mp4_25p_100mbps_4k_q` | 3840x2160,25p | `title_v_quality_qmenu` |  |
| 5 | `mp4_30p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_30p_72mbps_4k_10bit_q` | 3840x2160,30p | `title_v_quality_qmenu` |  |
| 6 | `mp4_25p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_25p_72mbps_4k_10bit_q` | 3840x2160,25p | `title_v_quality_qmenu` |  |
| 7 | `mp4_24p_100mbps_4k` | `` | `title_v_quality_mp4_24p_100mbps_4k_q` | 3840x2160,24p | `title_v_quality_qmenu` |  |
| 8 | `mp4_24p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_24p_72mbps_4k_10bit_q` | 3840x2160,24p | `title_v_quality_qmenu` |  |
| 9 | `mp4_60p_28mbps` | `` | `title_v_quality_mp4_60p_28mbps_q` | 1920x1080,60p | `title_v_quality_qmenu` |  |
| 10 | `mp4_50p_28mbps` | `` | `title_v_quality_mp4_50p_28mbps_q` | 1920x1080,50p | `title_v_quality_qmenu` |  |
| 11 | `mp4_30p_20mbps` | `` | `title_v_quality_mp4_30p_20mbps_q` | 1920x1080,30p | `title_v_quality_qmenu` |  |
| 12 | `mp4_25p_20mbps` | `` | `title_v_quality_mp4_25p_20mbps_q` | 1920x1080,25p | `title_v_quality_qmenu` |  |
| 13 | `mp4_24p_24mbps` | `` | `title_v_quality_mp4_24p_24mbps_q` | 1920x1080,24p | `title_v_quality_qmenu` |  |
| 14 | `mov_30p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_30p_200mbps_5_9k_10bit_q` | 5888x3312,30p,420/10bit | `title_v_quality_qmenu` |  |
| 15 | `mov_25p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_25p_200mbps_5_9k_10bit_q` | 5888x3312,25p,420/10bit | `title_v_quality_qmenu` |  |
| 16 | `mov_24p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_24p_200mbps_5_9k_10bit_q` | 5888x3312,24p,420/10bit | `title_v_quality_qmenu` |  |
| 17 | `mov_60p_150mbps_c4k` | `` | `title_v_quality_mov_60p_150mbps_c4k_q` | 4096x2160,60p,420/8bit | `title_v_quality_qmenu` |  |
| 18 | `mov_50p_150mbps_c4k` | `` | `title_v_quality_mov_50p_150mbps_c4k_q` | 4096x2160,50p,420/8bit | `title_v_quality_qmenu` |  |
| 19 | `mov_30p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_30p_150mbps_c4k_10bit_q` | 4096x2160,30p,422/10bit | `title_v_quality_qmenu` |  |
| 20 | `mov_30p_100mbps_c4k` | `` | `title_v_quality_mov_30p_100mbps_c4k_q` | 4096x2160,30p,420/8bit | `title_v_quality_qmenu` |  |
| 21 | `mov_25p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_25p_150mbps_c4k_10bit_q` | 4096x2160,25p,422/10bit | `title_v_quality_qmenu` |  |
| 22 | `mov_25p_100mbps_c4k` | `` | `title_v_quality_mov_25p_100mbps_c4k_q` | 4096x2160,25p,420/8bit | `title_v_quality_qmenu` |  |
| 23 | `mov_24p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_24p_150mbps_c4k_10bit_q` | 4096x2160,24p,422/10bit | `title_v_quality_qmenu` |  |
| 24 | `mov_24p_100mbps_c4k` | `` | `title_v_quality_mov_24p_100mbps_c4k_q` | 4096x2160,24p,420/8bit | `title_v_quality_qmenu` |  |
| 25 | `mov_60p_200mbps_4k_10bit` | `` | `title_v_quality_mov_60p_200mbps_4k_10bit_q` | 3840x2160,60p,420/10bit | `title_v_quality_qmenu` |  |
| 26 | `mov_60p_150mbps_4k` | `` | `title_v_quality_mov_60p_150mbps_4k_q` | 3840x2160,60p,420/8bit | `title_v_quality_qmenu` |  |
| 27 | `mov_50p_200mbps_4k_10bit` | `` | `title_v_quality_mov_50p_200mbps_4k_10bit_q` | 3840x2160,50p,420/10bit | `title_v_quality_qmenu` |  |
| 28 | `mov_50p_150mbps_4k` | `` | `title_v_quality_mov_50p_150mbps_4k_q` | 3840x2160,50p,420/8bit | `title_v_quality_qmenu` |  |
| 29 | `mov_30p_150mbps_4k_10bit` | `` | `title_v_quality_mov_30p_150mbps_4k_10bit_q` | 3840x2160,30p,422/10bit | `title_v_quality_qmenu` |  |
| 30 | `mov_30p_100mbps_4k` | `` | `title_v_quality_mov_30p_100mbps_4k_q` | 3840x2160,30p,420/8bit | `title_v_quality_qmenu` |  |
| 31 | `mov_25p_150mbps_4k_10bit` | `` | `title_v_quality_mov_25p_150mbps_4k_10bit_q` | 3840x2160,25p,422/10bit | `title_v_quality_qmenu` |  |
| 32 | `mov_25p_100mbps_4k` | `` | `title_v_quality_mov_25p_100mbps_4k_q` | 3840x2160,25p,420/8bit | `title_v_quality_qmenu` |  |
| 33 | `mov_24p_150mbps_4k_10bit` | `` | `title_v_quality_mov_24p_150mbps_4k_10bit_q` | 3840x2160,24p,422/10bit | `title_v_quality_qmenu` |  |
| 34 | `mov_24p_100mbps_4k` | `` | `title_v_quality_mov_24p_100mbps_4k_q` | 3840x2160,24p,420/8bit | `title_v_quality_qmenu` |  |
| 35 | `mov_60p_100mbps_10bit` | `` | `title_v_quality_mov_60p_100mbps_10bit_q` | 1920x1080,60p,422/10bit | `title_v_quality_qmenu` |  |
| 36 | `mov_60p_100mbps` | `` | `title_v_quality_mov_60p_100mbps_q` | 1920x1080,60p,420/8bit | `title_v_quality_qmenu` |  |
| 37 | `mov_50p_100mbps_10bit` | `` | `title_v_quality_mov_50p_100mbps_10bit_q` | 1920x1080,50p,422/10bit | `title_v_quality_qmenu` |  |
| 38 | `mov_50p_100mbps` | `` | `title_v_quality_mov_50p_100mbps_q` | 1920x1080,50p,420/8bit | `title_v_quality_qmenu` |  |
| 39 | `mov_30p_100mbps_10bit` | `` | `title_v_quality_mov_30p_100mbps_10bit_q` | 1920x1080,30p,422/10bit | `title_v_quality_qmenu` |  |
| 40 | `mov_30p_100mbps` | `` | `title_v_quality_mov_30p_100mbps_q` | 1920x1080,30p,420/8bit | `title_v_quality_qmenu` |  |
| 41 | `mov_25p_100mbps_10bit` | `` | `title_v_quality_mov_25p_100mbps_10bit_q` | 1920x1080,25p,422/10bit | `title_v_quality_qmenu` |  |
| 42 | `mov_25p_100mbps` | `` | `title_v_quality_mov_25p_100mbps_q` | 1920x1080,25p,420/8bit | `title_v_quality_qmenu` |  |
| 43 | `mov_24p_100mbps_10bit` | `` | `title_v_quality_mov_24p_100mbps_10bit_q` | 1920x1080,24p,422/10bit | `title_v_quality_qmenu` |  |
| 44 | `mov_24p_100mbps` | `` | `title_v_quality_mov_24p_100mbps_q` | 1920x1080,24p,420/8bit | `title_v_quality_qmenu` |  |
| 45 | `mp4_60p_100mbps_4k_10bit` | `` | `title_v_quality_mp4_60p_100mbps_4k_10bit` | MP4 3840x2160 60p 100Mbps 10bit AAC | `title_v_quality` |  |
| 46 | `mp4_50p_100mbps_4k_10bit` | `` | `title_v_quality_mp4_50p_100mbps_4k_10bit` | MP4 3840x2160 50p 100Mbps 10bit AAC | `title_v_quality` |  |
| 47 | `mp4_30p_100mbps_4k` | `` | `title_v_quality_mp4_30p_100mbps_4k` | MP4 3840x2160 30p 100Mbps 8bit AAC | `title_v_quality` |  |
| 48 | `mp4_25p_100mbps_4k` | `` | `title_v_quality_mp4_25p_100mbps_4k` | MP4 3840x2160 25p 100Mbps 8bit AAC | `title_v_quality` |  |
| 49 | `mp4_30p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_30p_72mbps_4k_10bit` | MP4 3840x2160 30p 72Mbps 10bit AAC | `title_v_quality` |  |
| 50 | `mp4_25p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_25p_72mbps_4k_10bit` | MP4 3840x2160 25p 72Mbps 10bit AAC | `title_v_quality` |  |
| 51 | `mp4_24p_100mbps_4k` | `` | `title_v_quality_mp4_24p_100mbps_4k` | MP4 3840x2160 24p 100Mbps 8bit AAC | `title_v_quality` |  |
| 52 | `mp4_24p_72mbps_4k_10bit` | `` | `title_v_quality_mp4_24p_72mbps_4k_10bit` | MP4 3840x2160 24p 72Mbps 10bit AAC | `title_v_quality` |  |
| 53 | `mp4_60p_28mbps` | `` | `title_v_quality_mp4_60p_28mbps` | MP4 1920x1080 60p 28Mbps 8bit AAC | `title_v_quality` |  |
| 54 | `mp4_50p_28mbps` | `` | `title_v_quality_mp4_50p_28mbps` | MP4 1920x1080 50p 28Mbps 8bit AAC | `title_v_quality` |  |
| 55 | `mp4_30p_20mbps` | `` | `title_v_quality_mp4_30p_20mbps` | MP4 1920x1080 30p 20Mbps 8bit AAC | `title_v_quality` |  |
| 56 | `mp4_25p_20mbps` | `` | `title_v_quality_mp4_25p_20mbps` | MP4 1920x1080 25p 20Mbps 8bit AAC | `title_v_quality` |  |
| 57 | `mp4_24p_24mbps` | `` | `title_v_quality_mp4_24p_24mbps` | MP4 1920x1080 24p 24Mbps 8bit AAC | `title_v_quality` |  |
| 58 | `mov_30p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_30p_200mbps_5_9k_10bit` | MOV 5888x3312 30p 200Mbps 10bit LPCM | `title_v_quality` |  |
| 59 | `mov_25p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_25p_200mbps_5_9k_10bit` | MOV 5888x3312 25p 200Mbps 10bit LPCM | `title_v_quality` |  |
| 60 | `mov_24p_200mbps_5_9k_10bit` | `` | `title_v_quality_mov_24p_200mbps_5_9k_10bit` | MOV 5888x3312 24p 200Mbps 10bit LPCM | `title_v_quality` |  |
| 61 | `mov_60p_150mbps_c4k` | `` | `title_v_quality_mov_60p_150mbps_c4k` | MOV 4096x2160 60p 150Mbps 8bit LPCM | `title_v_quality` |  |
| 62 | `mov_50p_150mbps_c4k` | `` | `title_v_quality_mov_50p_150mbps_c4k` | MOV 4096x2160 50p 150Mbps 8bit LPCM | `title_v_quality` |  |
| 63 | `mov_30p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_30p_150mbps_c4k_10bit` | MOV 4096x2160 30p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 64 | `mov_30p_100mbps_c4k` | `` | `title_v_quality_mov_30p_100mbps_c4k` | MOV 4096x2160 30p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 65 | `mov_25p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_25p_150mbps_c4k_10bit` | MOV 4096x2160 25p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 66 | `mov_25p_100mbps_c4k` | `` | `title_v_quality_mov_25p_100mbps_c4k` | MOV 4096x2160 25p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 67 | `mov_24p_150mbps_c4k_10bit` | `` | `title_v_quality_mov_24p_150mbps_c4k_10bit` | MOV 4096x2160 24p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 68 | `mov_24p_100mbps_c4k` | `` | `title_v_quality_mov_24p_100mbps_c4k` | MOV 4096x2160 24p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 69 | `mov_60p_200mbps_4k_10bit` | `` | `title_v_quality_mov_60p_200mbps_4k_10bit` | MOV 3840x2160 60p 200Mbps 10bit LPCM | `title_v_quality` |  |
| 70 | `mov_60p_150mbps_4k` | `` | `title_v_quality_mov_60p_150mbps_4k` | MOV 3840x2160 60p 150Mbps 8bit LPCM | `title_v_quality` |  |
| 71 | `mov_50p_200mbps_4k_10bit` | `` | `title_v_quality_mov_50p_200mbps_4k_10bit` | MOV 3840x2160 50p 200Mbps 10bit LPCM | `title_v_quality` |  |
| 72 | `mov_50p_150mbps_4k` | `` | `title_v_quality_mov_50p_150mbps_4k` | MOV 3840x2160 50p 150Mbps 8bit LPCM | `title_v_quality` |  |
| 73 | `mov_30p_150mbps_4k_10bit` | `` | `title_v_quality_mov_30p_150mbps_4k_10bit` | MOV 3840x2160 30p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 74 | `mov_30p_100mbps_4k` | `` | `title_v_quality_mov_30p_100mbps_4k` | MOV 3840x2160 30p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 75 | `mov_25p_150mbps_4k_10bit` | `` | `title_v_quality_mov_25p_150mbps_4k_10bit` | MOV 3840x2160 25p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 76 | `mov_25p_100mbps_4k` | `` | `title_v_quality_mov_25p_100mbps_4k` | MOV 3840x2160 25p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 77 | `mov_24p_150mbps_4k_10bit` | `` | `title_v_quality_mov_24p_150mbps_4k_10bit` | MOV 3840x2160 24p 150Mbps 10bit LPCM | `title_v_quality` |  |
| 78 | `mov_24p_100mbps_4k` | `` | `title_v_quality_mov_24p_100mbps_4k` | MOV 3840x2160 24p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 79 | `mov_60p_100mbps_10bit` | `` | `title_v_quality_mov_60p_100mbps_10bit` | MOV 1920x1080 60p 100Mbps 10bit LPCM | `title_v_quality` |  |
| 80 | `mov_60p_100mbps` | `` | `title_v_quality_mov_60p_100mbps` | MOV 1920x1080 60p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 81 | `mov_50p_100mbps_10bit` | `` | `title_v_quality_mov_50p_100mbps_10bit` | MOV 1920x1080 50p 100Mbps 10bit LPCM | `title_v_quality` |  |
| 82 | `mov_50p_100mbps` | `` | `title_v_quality_mov_50p_100mbps` | MOV 1920x1080 50p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 83 | `mov_30p_100mbps_10bit` | `` | `title_v_quality_mov_30p_100mbps_10bit` | MOV 1920x1080 30p 100Mbps 10bit LPCM | `title_v_quality` |  |
| 84 | `mov_30p_100mbps` | `` | `title_v_quality_mov_30p_100mbps` | MOV 1920x1080 30p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 85 | `mov_25p_100mbps_10bit` | `` | `title_v_quality_mov_25p_100mbps_10bit` | MOV 1920x1080 25p 100Mbps 10bit LPCM | `title_v_quality` |  |
| 86 | `mov_25p_100mbps` | `` | `title_v_quality_mov_25p_100mbps` | MOV 1920x1080 25p 100Mbps 8bit LPCM | `title_v_quality` |  |
| 87 | `mov_24p_100mbps_10bit` | `` | `title_v_quality_mov_24p_100mbps_10bit` | MOV 1920x1080 24p 100Mbps 10bit LPCM | `title_v_quality` |  |
| 88 | `mov_24p_100mbps` | `` | `title_v_quality_mov_24p_100mbps` | MOV 1920x1080 24p 100Mbps 8bit LPCM | `title_v_quality` |  |

### 13. `quality`

- 选项数量：5
- 父级显示标题：`title_quality`（`menu_item_id_quality` — “Picture Quality”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `fine` | `` | `title_quality_fine` | Fine | `title_quality` |  |
| 2 | `standard` | `` | `title_quality_standard` | Standard | `title_quality` |  |
| 3 | `raw_fine` | `` | `title_quality_raw_fine` | RAW+Fine | `title_quality` |  |
| 4 | `raw_standard` | `` | `title_quality_raw_standard` | RAW+Standard | `title_quality` |  |
| 5 | `raw` | `` | `title_quality_raw` | RAW | `title_quality` |  |

### 14. `pictsize`

- 选项数量：40
- 父级显示标题：`title_pctsiz`（`menu_item_id_pctsiz` — “Picture Size”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `21.5m` | `` | `title_pictsize_L21.5m` | L 21.5M | `title_pctsiz` |  |
| 2 | `24m` | `` | `title_pictsize_L24m` | L 24M | `title_pctsiz` |  |
| 3 | `20m` | `` | `title_pictsize_L20m` | L 20M | `title_pctsiz` |  |
| 4 | `16m` | `` | `title_pictsize_L16m` | L 16M | `title_pctsiz` |  |
| 5 | `13m` | `` | `title_pictsize_L13m` | L 13M | `title_pctsiz` |  |
| 6 | `18m` | `` | `title_pictsize_L18m` | L 18M | `title_pctsiz` |  |
| 7 | `9.5m` | `` | `title_pictsize_L9.5m` | L 9.5M | `title_pctsiz` |  |
| 8 | `10.5m` | `` | `title_pictsize_L10.5m` | L 10.5M | `title_pctsiz` |  |
| 9 | `9m` | `` | `title_pictsize_L9m` | L 9M | `title_pctsiz` |  |
| 10 | `7m` | `` | `title_pictsize_L7m` | L 7M | `title_pctsiz` |  |
| 11 | `10.5m` | `` | `title_pictsize_M10.5m` | M 10.5M | `title_pctsiz` |  |
| 12 | `12m` | `` | `title_pictsize_M12m` | M 12M | `title_pctsiz` |  |
| 13 | `10m` | `` | `title_pictsize_M10m` | M 10M | `title_pctsiz` |  |
| 14 | `8m` | `` | `title_pictsize_M8m` | M 8M | `title_pctsiz` |  |
| 15 | `10.5m` | `` | `title_pictsize_exM10.5m` | EX M 10.5M | `title_pctsiz` |  |
| 16 | `12m` | `` | `title_pictsize_exM12m` | EX M 12M | `title_pctsiz` |  |
| 17 | `10m` | `` | `title_pictsize_exM10m` | EX M 10M | `title_pctsiz` |  |
| 18 | `8m` | `` | `title_pictsize_exM8m` | EX M 8M | `title_pctsiz` |  |
| 19 | `5m` | `` | `title_pictsize_M5m` | M 5M | `title_pctsiz` |  |
| 20 | `5.5m` | `` | `title_pictsize_M5.5m` | M 5.5M | `title_pctsiz` |  |
| 21 | `4.5m` | `` | `title_pictsize_M4.5m` | M 4.5M | `title_pctsiz` |  |
| 22 | `3.5m` | `` | `title_pictsize_M3.5m` | M 3.5M | `title_pctsiz` |  |
| 23 | `5m` | `` | `title_pictsize_exM5m` | EX M 5M | `title_pctsiz` |  |
| 24 | `5.5m` | `` | `title_pictsize_exM5.5m` | EX M 5.5M | `title_pctsiz` |  |
| 25 | `4.5m` | `` | `title_pictsize_exM4.5m` | EX M 4.5M | `title_pctsiz` |  |
| 26 | `3.5m` | `` | `title_pictsize_exM3.5m` | EX M 3.5M | `title_pctsiz` |  |
| 27 | `5.5m` | `` | `title_pictsize_S5.5m` | S 5.5M | `title_pctsiz` |  |
| 28 | `6m` | `` | `title_pictsize_S6m` | S 6M | `title_pctsiz` |  |
| 29 | `5m` | `` | `title_pictsize_S5m` | S 5M | `title_pctsiz` |  |
| 30 | `4m` | `` | `title_pictsize_S4m` | S 4M | `title_pctsiz` |  |
| 31 | `5.5m` | `` | `title_pictsize_exS5.5m` | EX S 5.5M | `title_pctsiz` |  |
| 32 | `6m` | `` | `title_pictsize_exS6m` | EX S 6M | `title_pctsiz` |  |
| 33 | `5m` | `` | `title_pictsize_exS5m` | EX S 5M | `title_pctsiz` |  |
| 34 | `4m` | `` | `title_pictsize_exS4m` | EX S 4M | `title_pctsiz` |  |
| 35 | `2.5m` | `` | `title_pictsize_S2.5m` | S 2.5M | `title_pctsiz` |  |
| 36 | `3m` | `` | `title_pictsize_S3m` | S 3M | `title_pctsiz` |  |
| 37 | `2m` | `` | `title_pictsize_S2m` | S 2M | `title_pctsiz` |  |
| 38 | `2.5m` | `` | `title_pictsize_exS2.5m` | EX S 2.5M | `title_pctsiz` |  |
| 39 | `3m` | `` | `title_pictsize_exS3m` | EX S 3M | `title_pctsiz` |  |
| 40 | `2m` | `` | `title_pictsize_exS2m` | EX S 2M | `title_pctsiz` |  |

### 15. `hlg`

- 选项数量：3
- 父级显示标题：`title_hlg_photo`（`menu_item_id_hlg_photo` — “HLG Photo”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `full` | `` | `title_hlg_photo_full` | Full-Res. | `title_hlg_photo` |  |
| 2 | `4k` | `` | `title_hlg_photo_4k` | 4K-Res. | `title_hlg_photo` |  |
| 3 | `off` | `` | `title_hlg_photo_off` | Off | `title_hlg_photo` |  |

### 16. `hrs_pictsize`

- 选项数量：8
- 父级显示标题：`title_hrs_pictsize`（`menu_item_id_hrs_pictsize` — “Picture Size”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `xl` | `` | `title_hrs_pictsize_xl_4_3_85m` | XL 85M | `title_hrs_pictsize` |  |
| 2 | `ll` | `` | `title_hrs_pictsize_ll_4_3_42_5m` | LL 42.5M | `title_hrs_pictsize` |  |
| 3 | `xl` | `` | `title_hrs_pictsize_xl_3_2_96m` | XL 96M | `title_hrs_pictsize` |  |
| 4 | `ll` | `` | `title_hrs_pictsize_ll_3_2_48m` | LL 48M | `title_hrs_pictsize` |  |
| 5 | `xl` | `` | `title_hrs_pictsize_xl_16_9_81m` | XL 81M | `title_hrs_pictsize` |  |
| 6 | `ll` | `` | `title_hrs_pictsize_ll_16_9_40_5m` | LL 40.5M | `title_hrs_pictsize` |  |
| 7 | `xl` | `` | `title_hrs_pictsize_xl_1_1_64m` | XL 64M | `title_hrs_pictsize` |  |
| 8 | `ll` | `` | `title_hrs_pictsize_ll_1_1_32m` | LL 32M | `title_hrs_pictsize` |  |

### 17. `hrs_quality`

- 选项数量：4
- 父级显示标题：`title_hrs_quality`（`menu_item_id_hrs_quality` — “Picture Quality”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `fine` | `` | `title_hrs_quality_fine` | Fine | `title_hrs_quality` |  |
| 2 | `raw_fine` | `` | `title_hrs_quality_raw_fine` | RAW+Fine | `title_hrs_quality` |  |
| 3 | `raw` | `` | `title_hrs_quality_raw` | RAW | `title_hrs_quality` |  |
| 4 | `auto` | `` | `title_hrs_quality_auto` | Combined | `title_hrs_quality` |  |

### 18. `hrs_simul_rec`

- 选项数量：1
- 父级显示标题：`title_hrs`（`menu_item_id_hrs` — “High Resolution Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_hrs_simul_rec` | Simul Record Normal Shot | `title_hrs` | value=动态值 |

### 19. `hrs_wait_time`

- 选项数量：10
- 父级显示标题：`title_hrs_wait_time`（`menu_item_id_hrs_wait_time` — “Shutter Delay”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `30` | `` | `title_hrs_wait_time_30` | 30 SEC | `title_hrs_wait_time` |  |
| 2 | `15` | `` | `title_hrs_wait_time_15` | 15 SEC | `title_hrs_wait_time` |  |
| 3 | `8` | `` | `title_hrs_wait_time_8` | 8 SEC | `title_hrs_wait_time` |  |
| 4 | `4` | `` | `title_hrs_wait_time_4` | 4 SEC | `title_hrs_wait_time` |  |
| 5 | `2` | `` | `title_hrs_wait_time_2` | 2 SEC | `title_hrs_wait_time` |  |
| 6 | `1` | `` | `title_hrs_wait_time_1` | 1 SEC | `title_hrs_wait_time` |  |
| 7 | `1/2` | `` | `title_hrs_wait_time_1/2` | 1/2 SEC | `title_hrs_wait_time` |  |
| 8 | `1/4` | `` | `title_hrs_wait_time_1/4` | 1/4 SEC | `title_hrs_wait_time` |  |
| 9 | `1/8` | `` | `title_hrs_wait_time_1/8` | 1/8 SEC | `title_hrs_wait_time` |  |
| 10 | `off` | `` | `title_hrs_wait_time_off` | Off | `title_hrs_wait_time` |  |

### 20. `hrs_is_mode`

- 选项数量：2
- 父级显示标题：`title_hrs_is_mode`（`menu_item_id_hrs_is_mode` — “Motion Blur Processing”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `mode1` | `` | `title_hrs_is_mode_mode1` | MODE1 | `title_hrs_is_mode` |  |
| 2 | `mode2` | `` | `title_hrs_is_mode_mode2` | MODE2 | `title_hrs_is_mode` |  |

### 21. `filter_setting`

- 选项数量：23
- 父级显示标题：`title_filter_set`（`menu_item_id_filter_set` — “Filter Settings”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `noeffect` | `` | `title_filter_set_noeffect` | No Effect | `title_filter_set` |  |
| 2 | `pop` | `` | `title_crtv_ctrl_pop` | Expressive | `title_filter_set` |  |
| 3 | `retro` | `` | `title_crtv_ctrl_retro` | Retro | `title_filter_set` |  |
| 4 | `old_days` | `` | `title_crtv_ctrl_old_days` | Old Days | `title_filter_set` |  |
| 5 | `high_key` | `` | `title_crtv_ctrl_high_key` | High Key | `title_filter_set` |  |
| 6 | `low_key` | `` | `title_crtv_ctrl_low_key` | Low Key | `title_filter_set` |  |
| 7 | `sepia` | `` | `title_crtv_ctrl_sepia` | Sepia | `title_filter_set` |  |
| 8 | `monochro` | `` | `title_crtv_ctrl_monochro` | Monochrome | `title_filter_set` |  |
| 9 | `dynamic_monochro` | `` | `title_crtv_ctrl_dynamic_monochro` | Dynamic Monochrome | `title_filter_set` |  |
| 10 | `rough_monochro` | `` | `title_crtv_ctrl_rough_monochro` | Rough Monochrome | `title_filter_set` |  |
| 11 | `silky_monochro` | `` | `title_crtv_ctrl_silky_monochro` | Silky Monochrome | `title_filter_set` |  |
| 12 | `impressive_art` | `` | `title_crtv_ctrl_impressive_art` | Impressive Art | `title_filter_set` |  |
| 13 | `high_dynamic` | `` | `title_crtv_ctrl_high_dynamic` | High Dynamic | `title_filter_set` |  |
| 14 | `cross_proc` | `` | `title_crtv_ctrl_cross_proc` | Cross Process | `title_filter_set` |  |
| 15 | `toy_photo` | `` | `title_crtv_ctrl_toy_photo` | Toy Effect | `title_filter_set` |  |
| 16 | `toy_pop` | `` | `title_crtv_ctrl_toy_pop` | Toy Pop | `title_filter_set` |  |
| 17 | `bleach_bypass` | `` | `title_crtv_ctrl_bleach_bypass` | Bleach Bypass | `title_filter_set` |  |
| 18 | `diorama` | `` | `title_crtv_ctrl_diorama` | Miniature Effect | `title_filter_set` |  |
| 19 | `soft_focus` | `` | `title_crtv_ctrl_soft_focus` | Soft Focus | `title_filter_set` |  |
| 20 | `fantasy` | `` | `title_crtv_ctrl_fantasy` | Fantasy | `title_filter_set` |  |
| 21 | `cross_filter` | `` | `title_crtv_ctrl_cross_filter` | Star Filter | `title_filter_set` |  |
| 22 | `one_point_color` | `` | `title_crtv_ctrl_one_point_color` | One Point Color | `title_filter_set` |  |
| 23 | `sunshine` | `` | `title_crtv_ctrl_sunshine` | Sunshine | `title_filter_set` |  |

### 22. `focusmode`

- 选项数量：3
- 父级显示标题：`title_focusmode`（`menu_item_id_focusmode` — “Focus Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `afs` | `` | `title_focusmode_afs` | AFS | `title_focusmode` |  |
| 2 | `afc` | `` | `title_focusmode_afc` | AFC | `title_focusmode` |  |
| 3 | `mf` | `` | `title_focusmode_mf` | MF | `title_focusmode` |  |

### 23. `afmode`

- 选项数量：19
- 父级显示标题：`title_afmode`（`menu_item_id_afmode` — “AF Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `auto_recognize` | `animal_off` | `title_afmode_auto_recognize_animal_off` | Human Detect AF | `title_afmode` |  |
| 2 | `auto_recognize` | `animal_on` | `title_afmode_auto_recognize_animal_on` | Human/Animal Detect AF | `title_afmode` |  |
| 3 | `aftracking` | `` | `title_afmode_aftracking` | Tracking | `title_afmode` |  |
| 4 | `225area_detail` | `225area` | `title_afmode_225area_detail_225area` | 225-Area | `title_afmode` |  |
| 5 | `225area_detail` | `225area_afc` | `title_afmode_225area_detail_225area_afc` | 225-Area (AFC Starting-pt.) | `title_afmode` |  |
| 6 | `v_h` | `horizontal` | `title_afmode_v_h_horizontal` | Zone (Horz.) | `title_afmode` |  |
| 7 | `v_h` | `vertical` | `title_afmode_v_h_vertical` | Zone (Vert.) | `title_afmode` |  |
| 8 | `square` | `` | `title_afmode_square` | Zone (Square) | `title_afmode` |  |
| 9 | `oval` | `` | `title_afmode_oval` | Zone (Oval) | `title_afmode` |  |
| 10 | `1area_asst` | `auto_off` | `title_afmode_1area_asst` | 1-Area+ | `title_afmode` |  |
| 11 | `1area_asst` | `auto` | `title_afmode_1area_asst_auto` | 1-Area+(Human Detection) | `title_afmode` |  |
| 12 | `1area_asst` | `auto_anml` | `title_afmode_1area_asst_auto_anml` | 1-Area+(Human/Animal Detect) | `title_afmode` |  |
| 13 | `1area` | `auto_off` | `title_afmode_1area` | 1-Area | `title_afmode` |  |
| 14 | `1area` | `auto` | `title_afmode_1area_auto` | 1-Area(Human Detection) | `title_afmode` |  |
| 15 | `1area` | `auto_anml` | `title_afmode_1area_auto_anml` | 1-Area(Human/Animal Detect) | `title_afmode` |  |
| 16 | `pinpoint` | `` | `title_afmode_pinpoint` | Pinpoint | `title_afmode` |  |
| 17 | `custom_1` | `` | `title_afmode_custom_1` | Custom1 | `title_afmode` |  |
| 18 | `custom_2` | `` | `title_afmode_custom_2` | Custom2 | `title_afmode` |  |
| 19 | `custom_3` | `` | `title_afmode_custom_3` | Custom3 | `title_afmode` |  |

### 24. `flash`

- 选项数量：6
- 父级显示标题：`title_flash`（`menu_item_id_flash` — “Flash Mode”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `iauto` | `` | `title_flash_iauto` | iAuto | `title_flash` |  |
| 2 | `forcedflashon` | `` | `title_flash_forcedflashon` | Forced Flash On | `title_flash` |  |
| 3 | `forced_on_redeye` | `` | `title_flash_forced_on_redeye` | Forced On/Red-Eye | `title_flash` |  |
| 4 | `slowsync` | `` | `title_flash_slowsync` | Slow Sync. | `title_flash` |  |
| 5 | `slowsyncredeye` | `` | `title_flash_slowsyncredeye` | Slow Sync./Red-Eye | `title_flash` |  |
| 6 | `forcedflashoff` | `` | `title_flash_forcedflashoff` | Forced Flash Off | `title_flash` |  |

### 25. `bracket_exposure_sequence`

- 选项数量：2
- 父级显示标题：`title_bracket_exposure_sequence`（`menu_item_id_bracket_exposure_sequence` — “Sequence”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `center` | `` | `title_bracket_exposure_sequence_center` | 0/-/+ | `title_bracket_exposure_sequence` |  |
| 2 | `asc` | `` | `title_bracket_exposure_sequence_asc` | -/0/+ | `title_bracket_exposure_sequence` |  |

### 26. `bracket_exposure_shoot_type`

- 选项数量：2
- 父级显示标题：`title_bracket_exposure_shoot_type`（`menu_item_id_bracket_exposure_shoot_type` — “Single Shot Setting”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `single` | `` | `title_bracket_exposure_shoot_type_single` | ONE BY ONE | `title_bracket_exposure_shoot_type` |  |
| 2 | `burst` | `` | `title_bracket_exposure_shoot_type_burst` | ONE TAP | `title_bracket_exposure_shoot_type` |  |

### 27. `bracket_focal_shoot_num`

- 选项数量：3
- 父级显示标题：`title_bracket_focal_shoot_num`（`menu_item_id_bracket_focal_shoot_num` — “Shot Count”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `3` | `` | `title_bracket_focal_shoot_num_3` | 3 | `title_bracket_focal_shoot_num` |  |
| 2 | `5` | `` | `title_bracket_focal_shoot_num_5` | 5 | `title_bracket_focal_shoot_num` |  |
| 3 | `all` | `` | `title_bracket_focal_shoot_num_all` | ALL | `title_bracket_focal_shoot_num` |  |

### 28. `bracket_focus_step`

- 选项数量：10
- 父级显示标题：`title_bracket_focus_step`（`menu_item_id_bracket_focus_step` — “Step”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `1` | `` | `title_bracket_focus_step_1` | +1 | `title_bracket_focus_step` |  |
| 2 | `2` | `` | `title_bracket_focus_step_2` | +2 | `title_bracket_focus_step` |  |
| 3 | `3` | `` | `title_bracket_focus_step_3` | +3 | `title_bracket_focus_step` |  |
| 4 | `4` | `` | `title_bracket_focus_step_4` | +4 | `title_bracket_focus_step` |  |
| 5 | `5` | `` | `title_bracket_focus_step_5` | +5 | `title_bracket_focus_step` |  |
| 6 | `6` | `` | `title_bracket_focus_step_6` | +6 | `title_bracket_focus_step` |  |
| 7 | `7` | `` | `title_bracket_focus_step_7` | +7 | `title_bracket_focus_step` |  |
| 8 | `8` | `` | `title_bracket_focus_step_8` | +8 | `title_bracket_focus_step` |  |
| 9 | `9` | `` | `title_bracket_focus_step_9` | +9 | `title_bracket_focus_step` |  |
| 10 | `10` | `` | `title_bracket_focus_step_10` | +10 | `title_bracket_focus_step` |  |

### 29. `bracket_focus_shoot_num`

- 选项数量：1
- 父级显示标题：`title_bracket`（`menu_item_id_bracket` — “Bracketing”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_bracket_focus_shoot_num` | Shot Count | `title_bracket` | value=动态值；min=1 max=999 step=1 |

### 30. `bracket_focus_sequence`

- 选项数量：2
- 父级显示标题：`title_bracket_focus_sequence`（`menu_item_id_bracket_focus_sequence` — “Sequence”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `center` | `` | `title_bracket_focus_sequence_center` | 0/-/+ | `title_bracket_focus_sequence` |  |
| 2 | `asc` | `` | `title_bracket_focus_sequence_asc` | 0/+ | `title_bracket_focus_sequence` |  |

### 31. `interval_set_interval`

- 选项数量：1
- 父级显示标题：`title_stopmotion_interval`（`menu_item_id_stopmotion_interval` — “Time Lapse/Animation”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_interval_set_interval` | Shooting Interval Setting | `title_stopmotion_interval` | value=动态值 |

### 32. `interval_start_time`

- 选项数量：2
- 父级显示标题：`title_interval_start_time`（`menu_item_id_interval_start_time` — “Start Time”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `-1` | `` | `title_interval_start_time_immediate` | Now | `title_interval_start_time` |  |
| 2 | `__value__` | `` | `title_interval_start_time_set` | Start Time Set | `title_interval_start_time` | value=动态值 |

### 33. `interval_shoot_num`

- 选项数量：1
- 父级显示标题：`title_stopmotion_interval`（`menu_item_id_stopmotion_interval` — “Time Lapse/Animation”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_interval_shoot_num` | Image Count | `title_stopmotion_interval` | value=动态值 |

### 34. `interval_shoot_interval`

- 选项数量：1
- 父级显示标题：`title_stopmotion_interval`（`menu_item_id_stopmotion_interval` — “Time Lapse/Animation”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_interval_shoot_interval` | Shooting Interval | `title_stopmotion_interval` | value=动态值 |

### 35. `interval_expo_leveling`

- 选项数量：1
- 父级显示标题：`title_stopmotion_interval`（`menu_item_id_stopmotion_interval` — “Time Lapse/Animation”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_interval_expo_leveling` | Exposure Leveling | `title_stopmotion_interval` | value=动态值 |

### 36. `lc_shut_delay`

- 选项数量：5
- 父级显示标题：`title_lc_shut_delay`（`menu_item_id_lc_shut_delay` — “Shutter Delay”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `8` | `` | `title_lc_shut_delay_8` | 8 SEC | `title_lc_shut_delay` |  |
| 2 | `4` | `` | `title_lc_shut_delay_4` | 4 SEC | `title_lc_shut_delay` |  |
| 3 | `2` | `` | `title_lc_shut_delay_2` | 2 SEC | `title_lc_shut_delay` |  |
| 4 | `1` | `` | `title_lc_shut_delay_1` | 1 SEC | `title_lc_shut_delay` |  |
| 5 | `off` | `` | `title_lc_shut_delay_off` | OFF | `title_lc_shut_delay` |  |

### 37. `pictsize_burstspeed`

- 选项数量：7
- 父级显示标题：`title_6k4k_photo_pictsize_burstspeed`（`menu_item_id_6k4k_photo_pictsize_burstspeed` — “Picture Size / Burst Speed”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `6k_18m_30p` | `` | `title_pictsize_burstspeed_6k_18m_30p` | 6K 18M/30fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 2 | `6k_14m_30p` | `` | `title_pictsize_burstspeed_6k_14m_30p` | 6K 14M/30fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 3 | `6k_15m_30p` | `` | `title_pictsize_burstspeed_6k_15m_30p` | 6K 15M/30fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 4 | `4k_8m_60p` | `` | `title_pictsize_burstspeed_4k_8m_60p` | 4K 8M/60fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 5 | `ex_4k_8m_60p` | `` | `title_pictsize_burstspeed_ex_4k_8m_60p` | EX 4K 8M/60fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 6 | `4k_8m_30p` | `` | `title_pictsize_burstspeed_4k_8m_30p` | 4K 8M/30fps | `title_6k4k_photo_pictsize_burstspeed` |  |
| 7 | `ex_4k_8m_30p` | `` | `title_pictsize_burstspeed_ex_4k_8m_30p` | EX 4K 8M/30fps | `title_6k4k_photo_pictsize_burstspeed` |  |

### 38. `6k4k_photo`

- 选项数量：6
- 父级显示标题：`title_6k4k_photo_6k4k_photo`（`menu_item_id_6k4k_photo_6k4k_photo` — “Rec Method”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `6k_burst` | `` | `title_6k4k_photo_6k_burst` | 6K Burst | `title_6k4k_photo_6k4k_photo` |  |
| 2 | `6k_start_stop` | `` | `title_6k4k_photo_6k_start_stop` | 6K Burst(S/S) | `title_6k4k_photo_6k4k_photo` |  |
| 3 | `6k_pre_burst` | `` | `title_6k4k_photo_6k_pre_burst` | 6K Pre-Burst | `title_6k4k_photo_6k4k_photo` |  |
| 4 | `4k_burst` | `` | `title_6k4k_photo_4k_burst` | 4K Burst | `title_6k4k_photo_6k4k_photo` |  |
| 5 | `4k_start_stop` | `` | `title_6k4k_photo_4k_start_stop` | 4K Burst(S/S) | `title_6k4k_photo_6k4k_photo` |  |
| 6 | `4k_pre_burst` | `` | `title_6k4k_photo_4k_pre_burst` | 4K Pre-Burst | `title_6k4k_photo_6k4k_photo` |  |

### 39. `prerec`

- 选项数量：1
- 父级显示标题：`title_6k4k_photo`（`menu_item_id_6k4k_photo` — “6K/4K PHOTO”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_6k4k_photo_prerec` | Pre-Burst Recording | `title_6k4k_photo` | value=动态值 |

### 40. `focusselect`

- 选项数量：6
- 父级显示标题：`title_focus_select`（`menu_item_id_focus_select` — “Post-Focus”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `6k_18m` | `` | `title_focus_select_6k_18m` | 6K 18M | `title_focus_select` |  |
| 2 | `6k_14m` | `` | `title_focus_select_6k_14m` | 6K 14M | `title_focus_select` |  |
| 3 | `6k_15m` | `` | `title_focus_select_6k_15m` | 6K 15M | `title_focus_select` |  |
| 4 | `4k_8m` | `` | `title_focus_select_4k_8m` | 4K 8M | `title_focus_select` |  |
| 5 | `ex_4k_8m` | `` | `title_focus_select_ex_4k_8m` | EX 4K 8M | `title_focus_select` |  |
| 6 | `off` | `` | `title_focus_select_off` | Off | `title_focus_select` |  |

### 41. `slow_quick`

- 选项数量：11
- 父级显示标题：`title_slow_quick_settings`（`menu_item_id_slow_quick_settings` — “Slow & Quick Setting”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `1` | `` | `title_slow_quick_1` | 1fps | `title_slow_quick_settings` |  |
| 2 | `2` | `` | `title_slow_quick_2` | 2fps | `title_slow_quick_settings` |  |
| 3 | `5` | `` | `title_slow_quick_5` | 5fps | `title_slow_quick_settings` |  |
| 4 | `10` | `` | `title_slow_quick_10` | 10fps | `title_slow_quick_settings` |  |
| 5 | `15` | `` | `title_slow_quick_15` | 15fps | `title_slow_quick_settings` |  |
| 6 | `30` | `` | `title_slow_quick_30` | 30fps | `title_slow_quick_settings` |  |
| 7 | `60` | `` | `title_slow_quick_60` | 60fps | `title_slow_quick_settings` |  |
| 8 | `100` | `` | `title_slow_quick_100` | 100fps | `title_slow_quick_settings` |  |
| 9 | `120` | `` | `title_slow_quick_120` | 120fps | `title_slow_quick_settings` |  |
| 10 | `150` | `` | `title_slow_quick_150` | 150fps | `title_slow_quick_settings` |  |
| 11 | `180` | `` | `title_slow_quick_180` | 180fps | `title_slow_quick_settings` |  |

### 42. `ntsc_pal`

- 选项数量：2
- 父级显示标题：`title_ntsc_pal`（`menu_item_id_ntsc_pal` — “Switch NTSC/PAL”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `ntsc` | `` | `title_ntsc_pal_ntsc` | NTSC | `title_ntsc_pal` |  |
| 2 | `pal` | `` | `title_ntsc_pal_pal` | PAL | `title_ntsc_pal` |  |

### 43. `videoformat`

- 选项数量：3
- 父级显示标题：`title_videoformat`（`menu_item_id_videoformat` — “Rec. File Format”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `mp4` | `` | `title_videoformat_mp4` | MP4 | `title_videoformat` |  |
| 2 | `mp4hevc` | `` | `title_videoformat_mp4hevc` | MP4 HEVC | `title_videoformat` |  |
| 3 | `mov` | `` | `title_videoformat_mov` | MOV | `title_videoformat` |  |

### 44. `recmode`

- 选项数量：28
- 父级显示标题：`title_recmode`（`menu_item_id_recmode` — “Rec Mode”）、`title_recmode_creative_movie`（`menu_item_id_recmode_creative_movie` — “Creative Video”）、`title_recmode_slow_quick`（`menu_item_id_recmode_slow_quick` — “Slow & Quick”）、`title_recmode_c3`（`menu_item_id_recmode_c3` — “C3”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `program_ae` | `` | `title_recmode_program_ae` | P | `title_recmode` |  |
| 2 | `aperture_ae` | `` | `title_recmode_aperture_ae` | A | `title_recmode` |  |
| 3 | `shutter_ae` | `` | `title_recmode_shutter_ae` | S | `title_recmode` |  |
| 4 | `manual_exposure` | `` | `title_recmode_manual_exposure` | M | `title_recmode` |  |
| 5 | `creative_movie` | `` | `title_recmode_creative_movie` | Creative Video | `title_recmode` |  |
| 6 | `creative_movie` | `program_ae` | `title_recmode_creative_movie_program_ae` | P | `title_recmode_creative_movie` |  |
| 7 | `creative_movie` | `aperture_ae` | `title_recmode_creative_movie_aperture_ae` | A | `title_recmode_creative_movie` |  |
| 8 | `creative_movie` | `shutter_ae` | `title_recmode_creative_movie_shutter_ae` | S | `title_recmode_creative_movie` |  |
| 9 | `creative_movie` | `manual_exposure` | `title_recmode_creative_movie_manual_exposure` | M | `title_recmode_creative_movie` |  |
| 10 | `slow_quick` | `` | `title_recmode_slow_quick` | Slow & Quick | `title_recmode` |  |
| 11 | `slow_quick` | `program_ae` | `title_recmode_slow_quick_program_ae` | P | `title_recmode_slow_quick` |  |
| 12 | `slow_quick` | `aperture_ae` | `title_recmode_slow_quick_aperture_ae` | A | `title_recmode_slow_quick` |  |
| 13 | `slow_quick` | `shutter_ae` | `title_recmode_slow_quick_shutter_ae` | S | `title_recmode_slow_quick` |  |
| 14 | `slow_quick` | `manual_exposure` | `title_recmode_slow_quick_manual_exposure` | M | `title_recmode_slow_quick` |  |
| 15 | `c1` | `` | `title_recmode_c1` | C1 | `title_recmode` |  |
| 16 | `c2` | `` | `title_recmode_c2` | C2 | `title_recmode` |  |
| 17 | `c3` | `` | `title_recmode_c3` | C3 | `title_recmode` |  |
| 18 | `c3` | `c3_1` | `title_recmode_c3_c3_1` | C3-1 | `title_recmode_c3` |  |
| 19 | `c3` | `c3_2` | `title_recmode_c3_c3_2` | C3-2 | `title_recmode_c3` |  |
| 20 | `c3` | `c3_3` | `title_recmode_c3_c3_3` | C3-3 | `title_recmode_c3` |  |
| 21 | `c3` | `c3_4` | `title_recmode_c3_c3_4` | C3-4 | `title_recmode_c3` |  |
| 22 | `c3` | `c3_5` | `title_recmode_c3_c3_5` | C3-5 | `title_recmode_c3` |  |
| 23 | `c3` | `c3_6` | `title_recmode_c3_c3_6` | C3-6 | `title_recmode_c3` |  |
| 24 | `c3` | `c3_7` | `title_recmode_c3_c3_7` | C3-7 | `title_recmode_c3` |  |
| 25 | `c3` | `c3_8` | `title_recmode_c3_c3_8` | C3-8 | `title_recmode_c3` |  |
| 26 | `c3` | `c3_9` | `title_recmode_c3_c3_9` | C3-9 | `title_recmode_c3` |  |
| 27 | `c3` | `c3_10` | `title_recmode_c3_c3_10` | C3-10 | `title_recmode_c3` |  |
| 28 | `ia` | `` | `title_recmode_ia` | iA | `title_recmode` |  |

### 45. `touch_type`

- 选项数量：2
- 父级显示标题：顶层 `<menu>`（无带 `func_type` 的父级）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `__value__` | `` | `title_tch_shtr` | Touch Shutter | `` | value=动态值 |
| 2 | `__value__` | `` | `title_tch_ae` | Touch AE | `` | value=动态值 |

### 46. `peaking`

- 选项数量：2
- 父级显示标题：`title_peaking`（`menu_item_id_peaking` — “Focus Peaking”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `off` | `` | `title_peaking_off` | Off | `title_peaking` |  |
| 2 | `on` | `` | `title_peaking_on` | On | `title_peaking` |  |

### 47. `overlay`

- 选项数量：3
- 父级显示标题：`title_overlay`（`menu_item_id_overlay` — “Sheer Overlay”）

| # | cmd_value | cmd_value2 | title_id | 显示标题 (EN) | 父级 title_id | 备注 |
|---|---|---|---|---|---|---|
| 1 | `off` | `` | `title_overlay_off` | Off | `title_overlay` |  |
| 2 | `low` | `` | `title_overlay_low` | Transparency L | `title_overlay` |  |
| 3 | `high` | `` | `title_overlay_high` | Transparency H | `title_overlay` |  |

## 四、非可设置项（无 cmd_mode）

> 共 74 个，均为纯显示/容器控件（带 `func_type`）。

| # | id | title_id | func_type | 显示标题 (EN) |
|---|---|---|---|---|
| 1 | `menu_item_id_f_and_ss` | `title_f_and_ss` | `sp_embeded_f_and_ss` | Aperture/Shutter Speed |
| 2 | `menu_item_id_aperture` | `title_aperture` | `sp_embeded_aperture` | Aperture |
| 3 | `menu_item_id_shutter_speed` | `title_shutter_speed` | `sp_embeded_shutter_speed` | Shutter Speed |
| 4 | `menu_item_id_program_shift` | `title_program_shift` | `sp_embeded_program_shift` | Program Shift |
| 5 | `menu_item_id_f` | `title_f` | `sp_embeded_f` | F |
| 6 | `menu_item_id_ss` | `title_ss` | `sp_embeded_ss` | SS |
| 7 | `menu_item_id_f_and_ss_angle` | `title_f_and_ss_angle` | `sp_embeded_f_and_ss_angle` | F/SS(Angle) |
| 8 | `menu_item_id_ss_angle` | `title_ss_angle` | `sp_embeded_ss_angle` | SS(Angle) |
| 9 | `menu_item_id_f_and_ss_sync` | `title_f_and_ss_sync` | `sp_embeded_f_and_ss_sync` | F/SS(sync) |
| 10 | `menu_item_id_ss_sync` | `title_ss_sync` | `sp_embeded_ss_sync` | SS(sync) |
| 11 | `menu_item_id_f_and_ss_angle_sync` | `title_f_and_ss_angle_sync` | `sp_embeded_f_and_ss_angle_sync` | F/SS(AngleSync) |
| 12 | `menu_item_id_ss_angle_sync` | `title_ss_angle_sync` | `sp_embeded_ss_angle_sync` | SS(AngleSync) |
| 13 | `menu_item_id_exposure3` | `title_exposure3` | `sp_embeded_exposure3` | Exposure Comp. |
| 14 | `menu_item_id_exposure3_step` | `title_exposure3_step` | `sp_embeded_exposure3_step` | Step |
| 15 | `menu_item_id_sensitivity` | `title_sensitivity` | `sp_embeded_sensitivity` | Sensitivity |
| 16 | `menu_item_id_sensitivity_db` | `title_sensitivity_db` | `sp_embeded_sensitivity_db` | dB |
| 17 | `menu_item_id_whitebalance` | `title_whitebalance` | `sp_embeded_whitebalance` | White Balance |
| 18 | `menu_item_id_ph_sty` | `title_ph_sty` | `select` | Photo Style |
| 19 | `menu_item_id_ph_sty_saturation` | `title_ph_sty_saturation` | `sp_embeded_ph_sty_saturation` | Saturation |
| 20 | `menu_item_id_whitebalance` | `title_whitebalance` | `select` | White Balance |
| 21 | `menu_item_id_ph_sty_contrast` | `title_ph_sty_contrast` | `sp_embeded_ph_sty_contrast` | Contrast |
| 22 | `menu_item_id_ph_sty_highlight` | `title_ph_sty_highlight` | `sp_embeded_ph_sty_highlight` | Highlight |
| 23 | `menu_item_id_ph_sty_shadow` | `title_ph_sty_shadow` | `sp_embeded_ph_sty_shadow` | Shadow |
| 24 | `menu_item_id_ph_sty_sharpness` | `title_ph_sty_sharpness` | `sp_embeded_ph_sty_sharpness` | Sharpness |
| 25 | `menu_item_id_ph_sty_noise_reduction` | `title_ph_sty_noise_reduction` | `sp_embeded_ph_sty_noise_reduction` | Noise Reduction |
| 26 | `menu_item_id_asprat` | `title_asprat` | `select` | Aspect Ratio |
| 27 | `menu_item_id_lightmet` | `title_lightmet` | `select` | Metering Mode |
| 28 | `menu_item_id_v_quality` | `title_v_quality_qmenu` | `select` | Motion Pic. Rec Quality |
| 29 | `menu_item_id_ph_sty` | `title_ph_sty` | `sp_embeded_ph_sty11` | Photo Style |
| 30 | `menu_item_id_ph_sty_customs` | `title_ph_sty` | `sp_embeded_ph_sty_customs` | Photo Style |
| 31 | `menu_item_id_lightmet` | `title_lightmet` | `select` | Metering Mode |
| 32 | `menu_item_id_asprat` | `title_asprat` | `select` | Aspect Ratio |
| 33 | `menu_item_id_quality` | `title_quality` | `select` | Picture Quality |
| 34 | `menu_item_id_pctsiz` | `title_pctsiz` | `select` | Picture Size |
| 35 | `menu_item_id_hlg_photo` | `title_hlg_photo` | `select` | HLG Photo |
| 36 | `menu_item_id_hrs` | `title_hrs` | `submenu` | High Resolution Mode |
| 37 | `menu_item_id_hrs_start` | `title_hrs_start` | `sp_embeded_hrs_start` | Start |
| 38 | `menu_item_id_hrs_pictsize` | `title_hrs_pictsize` | `select` | Picture Size |
| 39 | `menu_item_id_hrs_quality` | `title_hrs_quality` | `select` | Picture Quality |
| 40 | `menu_item_id_hrs_wait_time` | `title_hrs_wait_time` | `select` | Shutter Delay |
| 41 | `menu_item_id_hrs_is_mode` | `title_hrs_is_mode` | `select` | Motion Blur Processing |
| 42 | `menu_item_id_filter_set` | `title_filter_set` | `sp_embeded_filter_set` | Filter Settings |
| 43 | `menu_item_id_focusmode` | `title_focusmode` | `select` | Focus Mode |
| 44 | `menu_item_id_afmode` | `title_afmode` | `sp_embeded_afmode` | AF Mode |
| 45 | `menu_item_id_flash` | `title_flash` | `select` | Flash Mode |
| 46 | `menu_item_id_drivemode` | `title_drivemode` | `select` | Drive Mode |
| 47 | `menu_item_id_bracket` | `title_bracket` | `submenu` | Bracketing |
| 48 | `menu_item_id_bracket_type` | `title_bracket_type` | `select` | Bracketing Type |
| 49 | `menu_item_id_bracket_exposure_step` | `title_bracket_exposure_step` | `select` | Step |
| 50 | `menu_item_id_bracket_exposure_sequence` | `title_bracket_exposure_sequence` | `select` | Sequence |
| 51 | `menu_item_id_bracket_exposure_shoot_type` | `title_bracket_exposure_shoot_type` | `select` | Single Shot Setting |
| 52 | `menu_item_id_bracket_focal_shoot_num` | `title_bracket_focal_shoot_num` | `select` | Shot Count |
| 53 | `menu_item_id_bracket_focus_step` | `title_bracket_focus_step` | `select` | Step |
| 54 | `menu_item_id_bracket_focus_sequence` | `title_bracket_focus_sequence` | `select` | Sequence |
| 55 | `menu_item_id_stopmotion_interval` | `title_stopmotion_interval` | `submenu` | Time Lapse/Animation |
| 56 | `menu_item_id_stopmotion_interval_shoot_type` | `title_stopmotion_interval_shoot_type` | `select` | Mode |
| 57 | `menu_item_id_interval_start_time` | `title_interval_start_time` | `submenu` | Start Time |
| 58 | `menu_item_id_lc` | `title_lc` | `submenu` | Live View Composite |
| 59 | `menu_item_id_lc_start` | `title_lc_start` | `sp_embeded_lc_start` | Start |
| 60 | `menu_item_id_lc_shut_delay` | `title_lc_shut_delay` | `select` | Shutter Delay |
| 61 | `menu_item_id_6k4k_photo` | `title_6k4k_photo` | `submenu` | 6K/4K PHOTO |
| 62 | `menu_item_id_6k4k_photo_pictsize_burstspeed` | `title_6k4k_photo_pictsize_burstspeed` | `select` | Picture Size / Burst Speed |
| 63 | `menu_item_id_6k4k_photo_6k4k_photo` | `title_6k4k_photo_6k4k_photo` | `select` | Rec Method |
| 64 | `menu_item_id_focus_select` | `title_focus_select` | `select` | Post-Focus |
| 65 | `menu_item_id_v_quality` | `title_v_quality` | `select` | Rec Quality |
| 66 | `menu_item_id_slow_quick_settings` | `title_slow_quick_settings` | `select` | Slow & Quick Setting |
| 67 | `menu_item_id_ntsc_pal` | `title_ntsc_pal` | `select` | Switch NTSC/PAL |
| 68 | `menu_item_id_videoformat` | `title_videoformat` | `select` | Rec. File Format |
| 69 | `menu_item_id_recmode` | `title_recmode` | `sp_embeded_recmode` | Rec Mode |
| 70 | `menu_item_id_self_shot` | `title_self_shot` | `sp_embeded_self_shot` | Self shot mode |
| 71 | `menu_item_id_zoom` | `title_zoom` | `sp_embeded_zoom` | Zoom |
| 72 | `menu_item_id_peaking` | `title_peaking` | `sp_embeded_peaking` | Focus Peaking |
| 73 | `menu_item_id_af_point_scope` | `title_af_point_scope` | `sp_embeded_af_point_scope` | AF-Point Scope |
| 74 | `menu_item_id_overlay` | `title_overlay` | `sp_embeded_overlay` | Sheer Overlay |


# DC-S5 相机「密钥」获取方法（accctrl 鉴权流程）

结论（实测校正 2026-10-09）：这台 S5（固件 VD4.3）**不发放会话令牌**。明文 `req_acc` 握手返回 `ok,S5-70E253,<mode>,encrypted`（仅 4 字段，没有第 5 字段令牌）；加密握手 `req_acc_g`/`req_acc_e` 本机返回 `err_param`（不支持）。所有读命令实测无需会话即可执行——即本机「密钥」形同虚设。下文保留 app 的令牌机制分析，供支持该机制的其它机型参考。

## 零、实测记录（真机 192.168.1.131）

| 请求 | 响应 |
|---|---|
| `req_acc`（无参数） | `ok_under_research_no_msg,S5-70E253,remote,encrypted` |
| `req_acc&value&value2`（空闲） | `ok_under_research_no_msg,S5-70E253,remote,encrypted` |
| `req_acc&value&value2`（被占用） | `err_others_requesting,S5-70E253,remote,encrypted` |
| `req_acc&value&value2`（成功） | `ok,S5-70E253,upload,encrypted`（4 字段，无令牌） |
| `req_acc_g` / `req_acc_e`（有无参数） | `<camrply><result>err_param</result></camrply>` |
| `req_acc_can` | `<camrply><result>ok</result></camrply>` |

要点：
- 明文 `req_acc` 才是本机握手命令；`err_others_requesting` 表示已有别的客户端（手机 app）在请求会话。
- `req_acc_g`/`req_acc_e`（加密路径）本机返回 `err_param`，即不支持——app 的 Encrypt 路径是给其它机型用的。
- 成功时 `req_acc` 只回 4 字段、结果 `ok`，没有第 5 字段；app 的 `T()` 要求 `ok` + ≥5 字段才存令牌，所以 app 对 S5 也从不存会话。
- `req_acc` 响应字节级确认：`ok_under_research_no_msg,S5-70E253,remote,encrypted\r\n`，4 字段、以 `\r\n` 收尾，确无第 5 字段。
- 写命令实测免鉴权：`camcmd&value=tele-normal` 返回 `<result>ok</result>`，全程无 `X-SESSION_ID` 头——读、写均无需鉴权，本机可直接控制。
- 相机被频繁连接后会主动断开（100% 丢包、端口关闭），需重新唤醒/重进 Wi-Fi 再测。

## 一、鉴权模型

- 访问令牌 = `accctrl` 响应 CSV 的第 5 字段（index 4），app 存下后每次请求带 `X-SESSION_ID: <token>` 头（`p094l5/b.java`）。
- 该固件（VD4.3）的明文握手 `req_acc` 不返回令牌，而是返回 `encrypted` 连接类型，要求走加密握手 `req_acc_e`。
- 加密握手的「加密」是 XOR 混淆（`H5/s.java`），密钥由相机通过 `req_acc_g` 发放。
- 反编译里还有一段 RSA/OAEP（`H5/t.java`，AndroidKeyStore 别名 "LumixSync"），那是另一个功能（app 自建密钥对），与 accctrl 握手无关。

## 二、实测响应与字段含义

实测（相机 IP 192.168.1.131，明文握手）：

    请求: GET /cam.cgi?mode=accctrl&type=req_acc&value=<uuid>&value2=<urlencoded name>
    响应: ok_under_research_no_msg,S5-70E253,remote,encrypted   (text/plain)

解析规则见 `p168v5/a.java` 的 `a0(str, cameraId)`：CSV 按 `,` 切分，若第 2 字段（index 1）等于相机串号则原样返回。字段含义：

| index | 含义 | 实测值 | 依据 |
|---|---|---|---|
| 0 | 结果码 | `ok_under_research_no_msg` | `c.java T()` 要求等于 "ok" 才存令牌 |
| 1 | 相机串号 | `S5-70E253` | 传入 `a0()` 的第 2 参数 `cVar.f24419e` |
| 2 | 模式 | `remote`（另有 transfer/upload/upload_bt） | `c.java o()` 检查此字段 |
| 3 | 连接类型 | `encrypted`（另有 normal） | 实测 |
| 4 | 会话令牌 | 只有结果码为 `ok` 时才有 | `c.java T()` 取 `strArr[4]` |

关键点：`ok_under_research_no_msg` 不是 "ok"，所以 `T()` 直接 return，**明文握手拿不到令牌**。必须走加密握手，让其返回 `ok,...` 才会发出令牌。

## 三、明文握手 req_acc

    请求: /cam.cgi?mode=accctrl&type=req_acc&value=<uuid>&value2=<urlencoded name>
    uuid = 4D454930-0100-1000-8001-<12位十六进制种子>
    name = 偏好项 "LUMIXSync.Network.Name"（默认 Build.MODEL），经 p.e0() 处理

本固件响应 `ok_under_research_no_msg,S5-70E253,remote,encrypted`，无令牌。

## 四、加密握手 req_acc_e（完整步骤）

流程见 `com/panasonic/jp/service/c.java` 的 `m()`（组装参数）和 `o()`（发送），以及 `p168v5/a.java` 的 `U()`（取密钥）。

1. 取混淆密钥（`a.U()` → `req_acc_g`）：

       请求: /cam.cgi?mode=accctrl&type=req_acc_g
       响应: text/plain，形如 ok,0x65e9b9ee
       解析: 按 , 切分，取 index 1，去 \r\n 后按 16 进制转 int（Integer.parseInt(s,16)）

2. XOR 混淆 uuid 和 name（`H5/s.java` 的 `b(str, key)`）：
   - key 为 0 时用默认值 -1875740628（无符号 0x904CB4AC）。
   - 字符串右补 (char)255 到长度是 4 的倍数。
   - 每 4 个字符按大端拼成一个 long，与 key 异或，再做字节旋转移位（(j9>>24&255)|(j9<<24&0xFF000000)|(j9<<8&0xFF0000)|(j9>>8&0xFF00)），按 %08x 十六进制输出每块。
   - 属可逆变换，`a(byte[],long)` 为反向解码。

3. 发送加密请求（`o()` 中 `aVar==Encrypt` 时 type 用 `req_acc_e`）：

       请求: /cam.cgi?mode=accctrl&type=req_acc_e&value=<混淆后uuid>&value2=<混淆后name>

4. 解析响应，取 index 4 为会话令牌；`T()` 存入，之后所有 /cam.cgi 请求加 `X-SESSION_ID: <token>` 头。

## 五、代码引用地图

| 类/方法 | 作用 |
|---|---|
| `p168v5/n.java` c() | URL 拼装 `/cam.cgi?mode=<组>&type=<命令>&value=..&value2=..` |
| `p168v5/a.java` m() (≈981) | 发 accctrl 请求；text/plain 结果写入 StringBuffer，text/xml 走 `o` 解析 |
| `p168v5/a.java` U() (≈890) | `req_acc_g` 取 32 位混淆密钥（16 进制解析） |
| `p168v5/a.java` a0() (≈938) | 响应 CSV 按相机串号重新对齐、去逗号拼接，返回 4~5 字段 |
| `H5/s.java` b()/a() | XOR+字节旋转混淆 / 反向解码（默认密钥 0x904CB4AC） |
| `com/panasonic/jp/service/c.java` m() (≈722) | 组装 uuid/name，Encrypt 模式先取密钥再混淆 |
| `com/panasonic/jp/service/c.java` o() (≈762) | 选择 req_acc_e/req_acc，发请求，解析，决定是否存令牌 |
| `com/panasonic/jp/service/c.java` T() (≈259) | 结果码为 "ok" 时把 index 4 存为会话令牌 |
| `p094l5/b.java` (≈89) | 给后续请求加 `X-SESSION_ID` 头 |
| `com/panasonic/jp/service/d.java` a 枚举 | 连接模式：Normal / ConnectSettingNormal / (…) / Encrypt |
| `p168v5/m.java` (≈56) | 会话令牌存取 |
| `H5/t.java` | AndroidKeyStore RSA/OAEP（另一功能，与 accctrl 无关） |

## 六、安全性评估

- 传输为明文 HTTP，无 TLS。
- 「加密」= XOR 混淆，密钥由相机通过 `req_acc_g` 主动给出，可逆、无秘密可言。
- 会话令牌仅在第 5 字段，明文返回。
- 结论：这套鉴权不构成安全边界，任何同网段设备都能拿到会话令牌并控制相机。

## 七、已证实 vs 待验证

已证实（真机 + 源码双向）：
- 明文 `req_acc` 响应为 `ok_under_research_no_msg,S5-70E253,remote,encrypted`，无令牌。
- 字段 0~3 含义、令牌在字段 4、`T()` 要求结果码 == "ok"。
- `req_acc_g` 返回 16 进制密钥，字段 1；XOR 算法与默认密钥。

待验证（相机当下已休眠/离线，无法实测）：
- `req_acc_e` 的实际响应格式（预测为 `ok,<串号>,<模式>,<连接类型>,<令牌>`，结果码 "ok"）。
- 会话令牌是否真的被控制类命令（setsetting/camctrl/camcmd）强制要求（读接口 getinfo 已证实无需令牌）。
- Encrypt 模式由 app 哪一层触发（d.a 枚举的取值来源，UI/设置层，未完全追到）。

复现建议：唤醒相机后，写脚本实现 `req_acc_g` → XOR 混淆 → `req_acc_e` → 取令牌，即可实锤第 4 步。
